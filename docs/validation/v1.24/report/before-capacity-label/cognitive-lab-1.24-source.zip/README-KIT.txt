Luma Drift 1.24 synthetic study. Zero humans; not Android rendering evidence.
Java17 and Python3. From extracted root:
 bash scripts/test-cognitive-lab-v124.sh
 bash scripts/run-cognitive-lab-v124.sh --profiles 100 --repetitions 20 --seed 2026103102 --days 8 --output /tmp/luma124-new-run
This is a SOURCE-ONLY kit: no raw CSV gzip files are included.
Run the command into a fresh output directory and compare deterministic output hashes against the bundled provenance JSON.
Never overwrite historical data. Open public/lab/clarity-124/index.html offline.
Home and individual public download links require network; report rendering does not.
The 104 oracle controls are separate from 8000 limited-perception trajectories.
GUIDE repeat requests can refresh an existing cue. No human/retention/fun claims.
LumaView.java is an extra uncompiled context required by a historical source-hash helper; it is not one of the 68 executed sources or an Android rendering qualification.

Raw ledgers (download independently and verify SHA256/bytes):
https://luma-drift-production.web.app/lab/clarity-124/raw/attempt-companion-capacities.csv.gz SHA256 d0022bd863b4c4b54a074dae26d060157cea469ab29d3a0ac63737226ecc0236 bytes 1604251
https://luma-drift-production.web.app/lab/clarity-124/raw/blocked-events.csv.gz SHA256 b908067fd9bea06b94403169448dc9b6e55ca1b0f94d60d72bcb9a1b4a817549 bytes 999043
https://luma-drift-production.web.app/lab/clarity-124/raw/companion-progression.csv.gz SHA256 2a340081f37248b154ef1982229249197535ba2288ba203d9e6b351a33011b93 bytes 2003375
https://luma-drift-production.web.app/lab/clarity-124/raw/companion-use-events.csv.gz SHA256 e14b2e943b5fa24bb821e19bc500b87bf2bda9dd106e1f2c7d4af435dfcd8f6a bytes 1775610
https://luma-drift-production.web.app/lab/clarity-124/raw/day-results.csv.gz SHA256 d95a4a60932b2d05058c8bcb014970abf667f4799888699d6aa4efbba0662eb0 bytes 803512
https://luma-drift-production.web.app/lab/clarity-124/raw/learned-rules.csv.gz SHA256 665c60e98ac98ebe5fc48567133746752d91c74093b33fb5cc0fadba4e80a71e bytes 374392
https://luma-drift-production.web.app/lab/clarity-124/raw/level-results.csv.gz SHA256 499a87d3face29b61c48be8a0182ef79212a5b19d2c449ea1a45a6ebe9814569 bytes 7348205
https://luma-drift-production.web.app/lab/clarity-124/raw/manual-assistance-events.csv.gz SHA256 44914eb0ffce7cfe3701b5bca9da60f7bb89158107a285ce6b6b24dae381dd04 bytes 1516828
https://luma-drift-production.web.app/lab/clarity-124/raw/probe-results.csv.gz SHA256 82505e2255df6d48bff327935864f831981fcbf8b5487229fb75dd7a5d713ee0 bytes 251953
https://luma-drift-production.web.app/lab/clarity-124/raw/progression-trajectories.csv.gz SHA256 c33168960853e76044caa4ff892c27c945f44845a46d996c667d4eb3f22ed361 bytes 50330
https://luma-drift-production.web.app/lab/clarity-124/raw/trajectories.csv.gz SHA256 8c16827fdff292737b2ed41cf2a7ea22ce603d9e2dba8672bbb06d03fa556405 bytes 595461
