package com.androidhit.lumadrift;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import com.androidhit.lumadrift.audio.AudioEngine;
import com.androidhit.lumadrift.data.*;
import com.androidhit.lumadrift.engine.*;
import com.androidhit.lumadrift.sharing.ShareComposer;
import com.androidhit.lumadrift.ui.*;
import com.androidhit.lumadrift.onboarding.*;
import com.androidhit.lumadrift.progression.LearningGuide;
import com.androidhit.lumadrift.progression.LearningStrings;
import com.androidhit.lumadrift.identity.*;
import com.androidhit.lumadrift.social.SocialClient;
import java.util.*;

/** Original puzzle presentation, generated environment and adaptive canvas UI. AGPL-3.0. */
// Budget/board/receipt commits deliberately finish before a paid continuation is acknowledged.
@android.annotation.SuppressLint("ApplySharedPref")
public final class LumaView extends View {
    private final android.text.TextPaint p = new android.text.TextPaint(3);
    private final Typeface bold = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final Typeface regular = Typeface.create("sans-serif", Typeface.NORMAL);
    private final GameStore store;
    private final SharedPreferences prefs;
    private final SharedPreferences expeditionPrefs;
    private final SessionEnergyStore sessionEnergy;
    private final com.androidhit.lumadrift.wallet.EnergyPurchaseController energyPurchases;
    private int lastSessionEnergy=-1;
    private final PuzzleReaction puzzleReaction=new PuzzleReaction();
    private final ExpeditionScene expeditionScene=new ExpeditionScene();
    private CompanionBattle.State battleState;
    private final ArrayList<String> squadDraft=new ArrayList<>();
    private int squadEditSlot,squadPage,battleSelected=-1;
    private float squadHeight=1050,battleSkillHeight=830;
    private String battlePreviewState="",battleActor="";
    private int battlePreviewHistory,battleEffectColor;
    private long battleEffectAt;
    private CompanionBattle.Effect battleEffect=CompanionBattle.Effect.GUIDE;
    private boolean battleComboPreview;

    private String expeditionCompanion="nova",expeditionTarget="nova";
    private ExpeditionRun.Goal expeditionGoal=ExpeditionRun.Goal.COPIES;
    private boolean expeditionShowResult;
    private final AudioEngine audio;
    private final WorldBackdrop backdrop;
    private final GoogleAccountController identity;
    private SessionSnapshot profileSnapshot;
    private SocialClient mapSocial;
    private ExperienceLayout layout;
    private float viewportH=840, contentScroll=0, drawingScroll=0, drawingClipBottom=840, scrollAtDown=0;
    private boolean scrolling=false,navigatingBack=false,drawingMapNodes=false;
    private final ArrayDeque<String> menuHistory=new ArrayDeque<>();
    private int inventoryFilter=0, gearSlotFilter=-1, moveStreak=0;
    private int briefingIndex=1,briefingMode=0,briefingEvent=0;
    private Level briefingLevel;
    private String briefingReturn="home";
    private long gatePulseUntil=0,successUntil=0;
    private float successX=195,successY=350;
    private int consequenceGateMask;
    private final HashSet<Integer> newlyFreed=new HashSet<>();
    private long consequenceUntil;

    private final KawaiiArt art=new KawaiiArt();
    private final SweetUi sweet=new SweetUi();
    private final PremiumUi premium=new PremiumUi();
    private final ScenicUi scenic=new ScenicUi();
    private final SceneTransition sceneTransition=new SceneTransition();
    private SceneRootLayout sceneRootLayout;
    private PlaySceneLayout playSceneLayout;
    private final SceneTransition.RootSwipe rootSwipe=new SceneTransition.RootSwipe();
    private SceneTransition.Direction nextSceneDirection=SceneTransition.Direction.FORWARD;
    private final HashMap<String,Bitmap> scenery=new HashMap<>();
    private final Paint sceneBitmapPaint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private Bitmap outgoingScene;
    private boolean drawingScene,sceneInputDiscarded,sceneAnnouncementPending;
    private android.app.Dialog sceneDialog;
    private String sceneConfirmTitle="",sceneConfirmText="";
    private Runnable sceneConfirmAction;
    private float pinchDistance,pinchZoom;
    private final String[] rootPlaces={"adventure","squad","collection_hub","rewards","shop"};
    private float menuHudInset;
    private final LivingWorld121 living121=new LivingWorld121();
    private final RewardMotion121.Counter coinMotion121=new RewardMotion121.Counter(),goldMotion121=new RewardMotion121.Counter(),xpMotion121=new RewardMotion121.Counter();
    private float economyHeight121=1260,evolutionHeight121=1350,summonRevealHeight121=1000,energyHeight121=1100;
    private boolean economyPolicy121;
    private String lastPaidUndo121="";
    private long blockedAt121;
    private int blockedCost121,blockedPiece121=-1;
    private ElementalShell121 elements121;
    private ExitChain121 exitChain121=new ExitChain121();
    private long summonRevealAt121;
    private String summonShown121="";
    private long menuCoinAt,menuGiftAt,menuGiftClosingAt;
    private int menuCoinFrom=-1,menuCoinTarget=-1;
    private String menuGiftTitle="",menuGiftDetail="",menuGiftPower="";
    private float homeSceneScale=1, homeSceneTop=144, homeSceneHeight=440,homeToolbarTop=620;
    private int premiumCollectionTab=0;
    private float homeDragPanX,homeDragPanY;
    private boolean homePanning;
    private final ShopIllustrations shopArt=new ShopIllustrations();
    private final CompanionHeroScene hero121Scene=new CompanionHeroScene();
    private final HomeScene homeScene=new HomeScene();
    private HomeLayout homeLayout,homeDraft;
    private boolean homeDecorating=false,homeInvalidPlacement=false;
    private String homeSelection="",homeDetail="",homeActivity="idle",homePendingActivity="idle",homeUsingItem="";
    private int homeCatalogTab=0,homeCatalogGroup=0,homeDraftX=0,homeDraftY=0,homeDraftRotation=0;
    private float homeWalkStartX=3,homeWalkStartY=3;
    private long homeWalkAt=0,homeActivityUntil=0;
    private java.util.List<HomeLayout.Cell> homePath=java.util.Collections.emptyList();
    private Board firstLight;
    private static final float HOME_TOP=104;
    private Long displayedGold;
    private float shopContentHeight120=Menu120Layout.SHOP_CONTENT_HEIGHT;
    private int summonTab=0,profileBadgeSlot=0;
    private String summonRequest="",summonPreview="";
    private String detailKind="",detailId="",detailMessage="",capsuleRequest="",detailParent="shop";
    private float detailHeight=1100;
    private final AvatarStage avatarStage=new AvatarStage();
    private final CompanionPortrait companionPortrait=new CompanionPortrait();
    private int motionPreviewPose=16,motionPreviewForm;
    private boolean motionPreviewWearables;
    private CompanionMotion.Facing homeFacing=CompanionMotion.Facing.FRONT;
    private final ArrayList<CosmeticCatalog.Item> wornCosmetics=new ArrayList<>();
    private ObjectiveDashboard.Snapshot hubObjectives;
    private CollectionGoal hubGoal;
    private PrismStory.Snapshot hubStory;
    private long hubRefreshAt;
    private int rewardTab=0,wardrobeMode=0,wardrobeGearSlot=0,shopCategory=0,shopLookPage=0,storyChapter=0;
    private GuardianEncounter guardian;private boolean guardianSaveBlocked,localSaveBlocked;private int guardianHint=-1;
    private String avatarStyle="plush_classic";private int gestureGate=-1;private boolean gestureGuardian;
    private int wardrobeSlot=0,wardrobePage=0,questTab=0,activeBiome=-1;
    private int[] guidanceSavedHistory=new int[0];
    private Board guidanceBoard;private long guidanceMask=-1;private int guidanceGates=-1,guidanceBudget=-2,guidanceHistory=0;private Board.Guidance guidance;
    private final MetaProgress meta;
    private final PlayJournal journal;
    private int cachedStars,cachedCompleted,cachedEconomyProgress,journeyTab=0,xpReward=0;
    private String friendCode="";
    private long activeElapsed=0,activeStarted=0;
    private final ArrayList<Hit> hits = new ArrayList<>();
    private final ArrayList<Flight> flights = new ArrayList<>();
    private final Random random = new Random(72);
    private Catalog.SkinItem skin=Catalog.SKINS[0];
    private Catalog.CharacterItem character=Catalog.CHARACTERS[0];
    private String screen = "adventure", toast = "";
    private float scale=1, ox=0, top=0, H=820, bottom=0, bx=37, by=250, cell=55;
    private int safeTop, safeBottom, chapter=0, collectionTab=0, collectionPage=0, eventTab=0;
    private Board board;
    private TutorialSession tutorial;
    private long tutorialChangedAt;
    private final ArrayList<Flight> practiceFlights=new ArrayList<>();
    private String tutorialFeedback="";private long tutorialFeedbackUntil;private boolean tutorialSaveBlocked,tutorialLoadBlocked,tutorialGiftClaimed;private float tutorialBoardLeft=69,tutorialBoardTop=278,tutorialBoardWidth=252;
    private int pendingAction=-1,gesturePiece=-1;
    private Board.ActionPreview actionPreview;
    private final java.util.concurrent.ExecutorService guideWorker=new java.util.concurrent.ThreadPoolExecutor(1,1,0L,java.util.concurrent.TimeUnit.MILLISECONDS,new java.util.concurrent.ArrayBlockingQueue<Runnable>(1),new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    private volatile long guidanceGeneration;private boolean guidancePending;private int[] guidancePlan=new int[0];private final HashSet<Integer> guidanceSafe=new HashSet<>();
    private MoveBudget moveBudget;
    private String runId="", pendingContinuation="", lastAppliedContinuation="";
    private int shieldCharges=0,shopPage=0,gearGrace=0,flowRemaining=0;
    private int contentVersion=5;
    private String lastPowerRequest="",profileName="";
    private boolean profileSignedIn=false,collectionOwnedOnly=false,flowExecuting=false,powerSaveBlocked=false;
    private long effectsPausedAt=0;
    private final PowerUsePolicy powerGate=new PowerUsePolicy();
    private long flowScheduledGeneration=-1;
    private AvatarLoadout loadout;
    private AvatarGearCatalog.Progress gearProgress;
    private long focusUntil=0,trailUntil=0;
    private int[] trail=new int[0];
    private final HashSet<Integer> safeHighlights=new HashSet<>();
    private int levelIndex=1, mode=0, eventIndex=0, hintsUsed=0, undos=0, reward=0, resultStars=0;
    private VictoryReceipt victoryResult;
    private int coachId=-1;
    private int selected=-1, hintId=-1, shakeId=-1, focused=-1, hovered=-1;
    private long toastUntil, hintUntil, visionUntil, shakeUntil, winAt, frameTime;
    private boolean running=true, paused=false, won=false, help=false, reduceMotion=false;
    private Hit pressed;
    private long actionGeneration=0;
    private float downX, downY;
    private final int PEACH=0xffffb398, WHITE=0xfff7f5ff, TEXT=0xff463252, INK=0xff30203f, GOLD=0xffffd992;
    private static class Hit {
        RectF r; String name,semanticId=""; Runnable action; int gate=-1,guardianPiece=-1; boolean selected,homeItem;
        Hit(RectF r,String n,Runnable a){this.r=r;name=n;action=a;}
    }
    private static class Flight {
        Tile tile; long at; float x,y; int color;
        Flight(Tile t,long a,float x,float y,int c){tile=t;at=a;this.x=x;this.y=y;color=c;}
    }
    public LumaView(Context c) {
        super(c); if(CharacterSprites.library()==null)CharacterSprites.install(c.getAssets()); store=new GameStore(c, new GameStore.ExternalOwnership() {
            public boolean ownsCharacter(String id) { return com.androidhit.lumadrift.wallet.ProductionWalletClient.ownsCharacter(c,id); }
            public boolean ownsSkin(String id) { return com.androidhit.lumadrift.wallet.ProductionWalletClient.ownsSkin(c,id); }
            public boolean ownsCosmetic(String id) { return com.androidhit.lumadrift.social.CosmeticVaultClient.ownsCosmetic(c,id); }
        }); prefs=c.getSharedPreferences("luma_session",0);expeditionPrefs=c.getSharedPreferences("luma_expedition_session_v118",0);
        sessionEnergy=new SessionEnergyStore(c.getSharedPreferences("luma_session_energy_v120",0));
        sessionEnergy.recover(prefs.getString("run_id",""),expeditionPrefs.getString("run_id",""),System.currentTimeMillis());
        meta=new MetaProgress(c);journal=new PlayJournal(c);
        audio=new AudioEngine(c);backdrop=new WorldBackdrop(c);
        identity=new GoogleAccountController((Activity)c,snapshot->{if(mapSocial!=null&&(profileSnapshot==null||!profileSnapshot.uid.equals(snapshot.uid))){mapSocial.close();mapSocial=null;}profileSnapshot=snapshot;profileSignedIn=snapshot.signedIn;profileName=snapshot.displayName;displayedGold=com.androidhit.lumadrift.wallet.ProductionWalletClient.cachedBalance(getContext());postInvalidate();});
        profileSnapshot=identity.snapshot();chapter=(store.unlockedLevel()-1)/10;
        energyPurchases=new com.androidhit.lumadrift.wallet.EnergyPurchaseController(c,sessionEnergy,new com.androidhit.lumadrift.wallet.EnergyPurchaseController.Listener(){
            public void onChanged(){int count=sessionEnergyCount();if(lastSessionEnergy==0&&count==10){sfx(AudioEngine.Sound.REVEAL);notice(en20("saved"));}lastSessionEnergy=count;if(BuildConfig.MODE_SANDBOX)displayedGold=(long)energyPurchases.testGoldBalance();else displayedGold=com.androidhit.lumadrift.wallet.ProductionWalletClient.cachedBalance(getContext());postInvalidate();}
            public void onError(String key){notice(energyPurchases.statusLabel(store.resolvedLanguage()));}
        });
        setFocusable(true); setFocusableInTouchMode(true);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        reduceMotion=prefs.getBoolean("reduce_motion",false)||!android.animation.ValueAnimator.areAnimatorsEnabled();
        syncStyle(); restoreSession();try{reconcileUndo121();}catch(IllegalStateException failure){powerSaveBlocked=true;}freezeEffects();
        tutorial=TutorialSession.start();
        try{tutorial=TutorialSession.restore(store.tutorialState());tutorialGiftClaimed=store.tutorialRewardClaimed();
            if(store.shouldStartFirstLight()){firstLight=FirstLight.restore(store.firstLightHistory());screen="firstlight";}
            else if(store.shouldAutoStartTutorial()&&!store.firstLightSeen()){screen="tutorial";if(tutorial.skipped())tutorial.resume();persistTutorial();}
        }catch(IllegalStateException failure){tutorialLoadBlocked=tutorialSaveBlocked=true;screen="tutorial";}
    }
    private String t(String key,Object... args){
        if(key.equals("booster_focus_desc")&&(board==null||board.level.progressionVersion>=4))return n("focus_desc");
        if(key.equals("coins"))return "LumaCoins";if(key.equals("wardrobe")||key.equals("rewards"))return v(key);
        if(!com.androidhit.lumadrift.commerce.CommerceConfig.MODE_SANDBOX&&key.equals("commerce_entry"))key="commerce_title";
        return Strings.get(store.resolvedLanguage(),key,args);
    }
    private String u(String key,Object... args){return UiStrings.get(store.resolvedLanguage(),key,args);}
    private String e(String key,Object...args){return ExperienceStrings.get(store.resolvedLanguage(),key,args);}
    private String v(String key,Object...args){return SagaStrings.get(store.resolvedLanguage(),key,args);}
    private String q(String key,Object...args){return V19Strings.get(store.resolvedLanguage(),key,args);}
    private String a(String key,Object...args){return V110Strings.get(store.resolvedLanguage(),key,args);}
    private String b(String key,Object...args){return V111Strings.get(store.resolvedLanguage(),key,args);}
    private String z(String key,Object...args){return V112Strings.get(store.resolvedLanguage(),key,args);}
    private String r(String key,Object...args){return V115Strings.get(store.resolvedLanguage(),key,args);}
    private String d(String key,Object...args){return V116Strings.get(store.resolvedLanguage(),key,args);}
    private String x(String key,Object...args){return V118Strings.get(store.resolvedLanguage(),key,args);}
    private String v19(String key,Object...args){return V119Strings.get(store.resolvedLanguage(),key,args);}
    private String m20(String key,Object...args){return V120MenuStrings.get(store.resolvedLanguage(),key,args);}
    private String h(String key,Object...args){return HomeStrings.get(store.resolvedLanguage(),key,args);}
    private String hn(String id){return HomeStrings.name(store.resolvedLanguage(),id);}
    private String storyText(String key){return PrismStoryStrings.get(store.resolvedLanguage(),key);}
    private String n(String key,Object...args){return V18Strings.get(store.resolvedLanguage(),key,args);}
    private String tt(String key,Object...args){return TutorialStrings.get(store.resolvedLanguage(),key,args);}
    private String w(String key){return V17Strings.get(store.resolvedLanguage(),key);}
    private String worldName(int level){return v("biome_"+SagaMap.biome(level));}
    private String vr(String key,Object...args){return V120ResultStrings.get(store.resolvedLanguage(),key,args);}
    private void openSocial(){getContext().startActivity(new android.content.Intent(getContext(),com.androidhit.lumadrift.social.SocialActivity.class));}
    private void refreshFriends(){if(!SocialClient.configured()||!profileSignedIn||!SocialClient.hasSavedProfile(getContext()))return;if(mapSocial!=null)mapSocial.close();SocialClient client=new SocialClient(getContext());mapSocial=client;client.refresh(new SocialClient.Listener(){public void onSnapshot(SocialClient.Snapshot value){client.close();if(mapSocial==client)mapSocial=null;postInvalidate();}public void onError(String message){client.close();if(mapSocial==client)mapSocial=null;/* Keep cache or an empty honest map. */}});}
    private void openAccount(){getContext().startActivity(new android.content.Intent(getContext(),com.androidhit.lumadrift.identity.AccountActivity.class));}
    private void syncStyle(){
        try{syncStyleUnsafe();}catch(GameStore.LocalSaveException failure){blockLocalSave();}
    }
    private void syncStyleUnsafe(){
        // Keep unknown production Gold nullable; a primitive/boxed ternary
        // would unbox the guest's null cache before the first frame.
        if(BuildConfig.MODE_SANDBOX&&energyPurchases!=null)displayedGold=Long.valueOf(energyPurchases.testGoldBalance());
        else displayedGold=com.androidhit.lumadrift.wallet.ProductionWalletClient.cachedBalance(getContext());
        skin=Catalog.skin(store.equippedSkin()); if(skin==null)skin=Catalog.SKINS[0];
        ExpeditionRun activeExpedition=mode==5?store.expeditionRun():null;
        character=Catalog.character(activeExpedition!=null?activeExpedition.companionId:store.equippedCharacter());if(character==null)character=Catalog.CHARACTERS[0];
        try{store.claimAvatarGearUnlocks();store.claimCosmeticUnlocks();}catch(IllegalStateException failed){/* Keep the last durable wardrobe. */}
        loadout=store.avatarLoadout();gearProgress=store.avatarGearProgress();avatarStyle=store.avatarStyle();
        wornCosmetics.clear();for(CosmeticCatalog.Slot slot:CosmeticCatalog.Slot.values()){CosmeticCatalog.Item item=CosmeticCatalog.find(store.equippedCosmetic(slot));if(item!=null)wornCosmetics.add(item);}
        hubRefreshAt=0;
        profileSignedIn=profileSnapshot!=null&&profileSnapshot.signedIn;
        profileName=profileSignedIn?profileSnapshot.displayName:"";
        audio.setSfxEnabled(store.soundEnabled());audio.setMusicEnabled(store.musicEnabled());cachedStars=store.totalStars();cachedCompleted=store.completedLevels();cachedEconomyProgress=store.economyProgress();
    }
    private List<CosmeticCatalog.Item> presentedCosmetics(){return store.usesOriginalCompanionCostume()?Collections.emptyList():wornCosmetics;}
    public void setSafeInsets(int a,int b){safeTop=a;safeBottom=b;invalidate();}
    public void resumeApp(){
        try{resumeAppUnsafe();}catch(GameStore.LocalSaveException failure){blockLocalSave();}
    }
    private void resumeAppUnsafe(){energyPurchases.onForeground();running=true;reduceMotion=prefs.getBoolean("reduce_motion",false)||!android.animation.ValueAnimator.areAnimatorsEnabled();finishScenePresentation();identity.onResume();thawEffects();if(powerSaveBlocked){powerSaveBlocked=!saveSession();if(!powerSaveBlocked)reconcilePowerReservation();}if(board!=null&&board.isSolved()&&!won)finishLevel();resumeFlow();meta.recordVisit();if(screen.equals("play")&&!paused&&!help&&!won&&!outOfMoves()&&activeStarted==0)activeStarted=SystemClock.uptimeMillis();applyPendingContinuation();if(prefs.getBoolean("session_migration_notice",false)){notice(t("moves_migration"));prefs.edit().putBoolean("session_migration_notice",false).commit();}log("session_start","version",BuildConfig.VERSION_NAME,"language",store.resolvedLanguage());syncStyle();audio.resume();refreshFriends();invalidate();}
    public void pauseApp(){finishScenePresentation();if(guardian!=null)persistGuardian();identity.onPause();actionGeneration++;freezeEffects();stopTimer();saveSession();running=false;audio.pause();}
    public void release(){energyPurchases.close();finishScenePresentation();for(Bitmap bitmap:scenery.values())if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();scenery.clear();if(sceneDialog!=null)sceneDialog.dismiss();if(mapSocial!=null){mapSocial.close();mapSocial=null;}identity.close();actionGeneration++;running=false;audio.release();backdrop.close();guideWorker.shutdownNow();}
    public String screenName(){return screen;}
    public void saveUiState(Bundle out){
        out.putStringArrayList("squad_draft_v119",new ArrayList<>(squadDraft));out.putInt("squad_slot_v119",squadEditSlot);out.putInt("squad_page_v119",squadPage);
        out.putInt("battle_selected_v119",battleSelected);out.putString("battle_preview_v119",battlePreviewState);out.putInt("battle_history_v119",battlePreviewHistory);out.putBoolean("battle_combo_preview_v119",battleComboPreview);
        out.putInt("motion_pose_v118",motionPreviewPose);out.putInt("motion_form_v118",motionPreviewForm);
        out.putBoolean("motion_wearables_v118",motionPreviewWearables);
        out.putString("expedition_target_v118",expeditionTarget);out.putBoolean("expedition_show_result_v118",expeditionShowResult);out.putBoolean("expedition_play_v118",mode==5&&board!=null);out.putString("expedition_companion_v118",expeditionCompanion);out.putString("expedition_goal_v118",expeditionGoal.name());
        out.putInt("summon_tab_v116",summonTab);out.putString("summon_request_v116",summonRequest);out.putString("summon_preview_v116",summonPreview);out.putInt("badge_slot_v116",profileBadgeSlot);
        out.putInt("home_catalog_group_v115",homeCatalogGroup);out.putFloat("home_viewport_height_v116",homeScene.viewportHeight());out.putFloat("home_zoom_v116",homeScene.cameraZoom());out.putFloat("home_pan_x_v115",homeScene.cameraPanX());out.putFloat("home_pan_y_v115",homeScene.cameraPanY());out.putBoolean("home_decorating_v113",homeDecorating);out.putString("home_selection_v113",homeSelection);out.putString("home_detail_v113",homeDetail);out.putInt("home_catalog_tab_v113",homeCatalogTab);out.putInt("home_draft_x_v113",homeDraftX);out.putInt("home_draft_y_v113",homeDraftY);out.putInt("home_draft_rotation_v113",homeDraftRotation);
        out.putFloat("detail_height_v112",detailHeight);out.putString("detail_kind_v112",detailKind);out.putString("detail_id_v112",detailId);out.putString("detail_message_v112",detailMessage);out.putString("capsule_request_v112",capsuleRequest);out.putString("detail_parent_v112",detailParent);
        out.putInt("reward_tab_v110",rewardTab);out.putInt("wardrobe_mode_v110",wardrobeMode);out.putInt("wardrobe_gear_v110",wardrobeGearSlot);out.putInt("shop_category_v110",shopCategory);out.putInt("shop_look_page_v110",shopLookPage);out.putInt("story_chapter_v110",storyChapter);
        out.putString("screen",screen);out.putBoolean("ui_paused",paused);out.putBoolean("ui_help",help);out.putBoolean("ui_restart",restartConfirm);out.putInt("wardrobe_slot",wardrobeSlot);out.putInt("wardrobe_page",wardrobePage);out.putInt("quest_tab",questTab);out.putInt("chapter",chapter);out.putInt("journey_tab",journeyTab);out.putInt("collection_tab",collectionTab);out.putInt("collection_page",collectionPage);out.putInt("inventory_filter",inventoryFilter);out.putInt("gear_slot",gearSlotFilter);out.putInt("event_tab",eventTab);out.putInt("shop_page",shopPage);out.putFloat("content_scroll",contentScroll);out.putStringArrayList("menu_history",new ArrayList<>(menuHistory));
        if(guardian!=null){out.putString("guardian_ui_attempt",guardian.encode());out.putBoolean("guardian_ui_save_blocked",guardianSaveBlocked);}
        if(briefingLevel!=null){out.putInt("preview_index",briefingIndex);out.putInt("preview_mode",briefingMode);out.putInt("preview_event",briefingEvent);out.putString("preview_return",briefingReturn);}
    }
    public void restoreUiState(Bundle state){finishScenePresentation();
        motionPreviewPose=Math.max(0,Math.min(19,state.getInt("motion_pose_v118",16)));motionPreviewForm=Math.max(0,Math.min(3,state.getInt("motion_form_v118",0)));
        motionPreviewWearables=state.getBoolean("motion_wearables_v118",false);
        ArrayList<String> draft=state.getStringArrayList("squad_draft_v119");squadDraft.clear();if(draft!=null)for(String id:draft)if(store.ownsCharacter(id)&&!squadDraft.contains(id)&&squadDraft.size()<3)squadDraft.add(id);
        squadEditSlot=Math.max(0,Math.min(2,state.getInt("squad_slot_v119",0)));squadPage=Math.max(0,Math.min(6,state.getInt("squad_page_v119",0)));
        battleSelected=state.getInt("battle_selected_v119",-1);battlePreviewState=state.getString("battle_preview_v119","");battlePreviewHistory=state.getInt("battle_history_v119",0);battleComboPreview=state.getBoolean("battle_combo_preview_v119",false);
        expeditionTarget=state.getString("expedition_target_v118","nova");expeditionCompanion=state.getString("expedition_companion_v118","nova");try{expeditionGoal=ExpeditionRun.Goal.valueOf(state.getString("expedition_goal_v118","COPIES"));}catch(IllegalArgumentException ignored){expeditionGoal=ExpeditionRun.Goal.COPIES;}
        expeditionShowResult=state.getBoolean("expedition_show_result_v118",false);boolean wantedExpedition=state.getBoolean("expedition_play_v118",false);boolean restoredExpedition=wantedExpedition&&restoreSessionFrom(expeditionPrefs);
        summonTab=Math.max(0,Math.min(1,state.getInt("summon_tab_v116",0)));summonRequest=state.getString("summon_request_v116","");summonPreview=state.getString("summon_preview_v116","");profileBadgeSlot=Math.max(0,Math.min(2,state.getInt("badge_slot_v116",0)));
        homeCatalogGroup=Math.max(0,Math.min(3,state.getInt("home_catalog_group_v115",0)));homeScene.setViewport(390,state.getFloat("home_viewport_height_v116",440));homeScene.setCamera(state.getFloat("home_zoom_v116",HomeScene.DETAIL_ZOOM),state.getFloat("home_pan_x_v115",0),state.getFloat("home_pan_y_v115",0));homeDecorating=state.getBoolean("home_decorating_v113",false);homeSelection=state.getString("home_selection_v113","");homeDetail=state.getString("home_detail_v113","");homeCatalogTab=Math.max(0,Math.min(2,state.getInt("home_catalog_tab_v113",0)));homeDraftX=state.getInt("home_draft_x_v113",0);homeDraftY=state.getInt("home_draft_y_v113",0);homeDraftRotation=state.getInt("home_draft_rotation_v113",0);if(!homeSelection.isEmpty())refreshHomeDraft();
        rewardTab=Math.max(0,Math.min(3,state.getInt("reward_tab_v110",0)));wardrobeMode=Math.max(0,Math.min(1,state.getInt("wardrobe_mode_v110",0)));wardrobeGearSlot=Math.max(0,Math.min(2,state.getInt("wardrobe_gear_v110",0)));shopCategory=Math.max(0,Math.min(2,state.getInt("shop_category_v110",0)));shopLookPage=Math.max(0,Math.min(2,state.getInt("shop_look_page_v110",0)));storyChapter=Math.max(0,Math.min(10,state.getInt("story_chapter_v110",0)));
        wardrobeSlot=Math.max(0,Math.min(3,state.getInt("wardrobe_slot",0)));wardrobePage=Math.max(0,Math.min(1,state.getInt("wardrobe_page",0)));questTab=state.getInt("quest_tab",0)==1?1:0;chapter=Math.max(0,state.getInt("chapter",chapter));journeyTab=state.getInt("journey_tab",0)==1?1:0;collectionTab=Math.max(0,Math.min(3,state.getInt("collection_tab",0)));collectionPage=Math.max(0,state.getInt("collection_page",0));inventoryFilter=Math.max(0,Math.min(3,state.getInt("inventory_filter",0)));gearSlotFilter=Math.max(-1,Math.min(2,state.getInt("gear_slot",-1)));eventTab=Math.max(0,Math.min(2,state.getInt("event_tab",0)));shopPage=Math.max(0,Math.min(1,state.getInt("shop_page",0)));
        if(state.containsKey("preview_index")){briefingMode=Math.max(0,Math.min(3,state.getInt("preview_mode",0)));briefingIndex=Math.max(1,Math.min(briefingMode==3?BalancedCatalog.REMIX_COUNT:BalancedCatalog.LEVEL_COUNT,state.getInt("preview_index",1)));briefingEvent=Math.max(0,Math.min(briefingMode==1?2:6,state.getInt("preview_event",0)));briefingReturn=state.getString("preview_return","home");briefingLevel=briefingMode==0?RelayCatalog.get(briefingIndex):briefingMode==3?StrategyCatalog.remix(briefingIndex):StrategyCatalog.event(briefingMode==1?store.dailySeed(briefingEvent):store.weeklySeed(briefingEvent));}
        GuardianEncounter restoredGuardian=GuardianEncounter.restore(state.getString("guardian_ui_attempt",""));
        if(restoredGuardian!=null&&store.guardianUnlocked(restoredGuardian.definition.number)){guardian=restoredGuardian;guardianSaveBlocked=state.getBoolean("guardian_ui_save_blocked",false);}
        detailHeight=state.getFloat("detail_height_v112",1100);if(!Float.isFinite(detailHeight)||detailHeight<840||detailHeight>10000)detailHeight=1100;
        detailKind=state.getString("detail_kind_v112","");detailId=state.getString("detail_id_v112","");detailMessage=state.getString("detail_message_v112","");capsuleRequest=state.getString("capsule_request_v112","");detailParent=state.getString("detail_parent_v112","shop");
        restoreScreen(wantedExpedition&&!restoredExpedition?"expedition":state.getString("screen"));if(screen.equals("play")){paused=state.getBoolean("ui_paused",false);help=state.getBoolean("ui_help",false);restartConfirm=paused&&state.getBoolean("ui_restart",false);if(paused||help){actionGeneration++;stopTimer();freezeEffects();}}menuHistory.clear();ArrayList<String> history=state.getStringArrayList("menu_history");if(history!=null)for(String item:history)if(isMenu(item)||item.equals("play")&&board!=null)menuHistory.addLast(item);contentScroll=Math.max(0,state.getFloat("content_scroll",0));finishScenePresentation();
    }
    private boolean isMenu(String value){return Arrays.asList("economy","evolution","session_energy","squad","battle_skill","companion_motion","expedition","expedition_odds","profile","badges","summon","summon_pool","summon_reveal","adventure","rules","collection_hub","atelier","home","home_catalog","home_item","firstlight","journey","collection","events","shop","settings","briefing","missions","journal","wardrobe","rewards","tutorial","styles","guardians","story","item").contains(value);}
    public void restoreScreen(String name){
        if("guardian".equals(name)){
            if(guardian==null)guardian=GuardianEncounter.restore(prefs.getString("guardian_v19_session",""));
            guardianHint=-1;
            go(guardian!=null&&store.guardianUnlocked(guardian.definition.number)?"guardian":"guardians");
        }else if(name!=null&&(isMenu(name)||name.equals("play")&&board!=null))go(name);
    }
    public void back(){finishScenePresentation();actionGeneration++;if(menuGiftAt>0){closeMenuGift();return;}if(sceneConfirmAction!=null){sceneConfirmAction=null;invalidate();return;}
        if(localSaveBlocked){retryLocalSave();return;}
        if(screen.equals("guardian")){leaveGuardian();return;}
        if(screen.equals("tutorial")){leaveTutorial();return;}
        if(pendingAction>=0){pendingAction=-1;actionPreview=null;invalidate();return;}
        if(powerTrayOpen){powerTrayOpen=false;invalidate();return;}if(!powerConfirmation.isEmpty()){powerConfirmation="";invalidate();return;}if(deadEndOpen){deadEndOpen=false;invalidate();return;}if(help){setHelp(false);invalidate();return;}
        if(screen.equals("play")){
            if(won){leaveVictory(()->goRoot(mode==5?"expedition":"adventure"));return;}
            setPaused(!paused);restartConfirm=false;saveSession();invalidate();return;
        }
        if(!screen.equals("adventure")){if(screen.equals("home")||screen.equals("collection_hub")||screen.equals("atelier")){goRoot("adventure");return;}backMenu();return;}
        ((Activity)getContext()).moveTaskToBack(true);
    }
    private void sfx(AudioEngine.Sound s){audio.play(s);}
    private void haptic(){if(store.hapticsEnabled())performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);}
    private void go(String s){
        if(!screen.equals(s)){menuGiftAt=0;menuGiftClosingAt=0;}
        boolean leavingExpedition=mode==5&&board!=null&&!Arrays.asList("play","battle_skill","squad","item","companion_motion").contains(s);
        boolean changing=!screen.equals(s);if(changing){beginScenePresentation();sfx(s.equals("summon_reveal")?AudioEngine.Sound.REVEAL:s.equals("wardrobe")?AudioEngine.Sound.FABRIC:AudioEngine.Sound.SCENE);}
        if(!s.equals("home")){homePath=Collections.emptyList();homeActivity="idle";homeUsingItem="";}
        if(!navigatingBack&&!screen.equals(s)&&!screen.equals("play"))menuHistory.push(screen);
        contentScroll=s.equals("journey")?SagaMap.scrollTo(journeyTab==1?store.remixUnlockedLevel():store.unlockedLevel(),viewportH,journeyTab==1?BalancedCatalog.REMIX_COUNT:BalancedCatalog.LEVEL_COUNT):0;scrolling=false;
        if(screen.equals("play")&&!s.equals("play")&&board!=null&&!won)log("level_exit","mode",""+mode,"level",""+levelIndex,"remaining",""+board.remainingCount(),"event_index",""+eventIndex,"period",eventPeriod);
        stopTimer();if(leavingExpedition){saveSession();board=null;mode=0;won=false;restoreSession();}actionGeneration++;pendingAction=-1;actionPreview=null;powerConfirmation="";deadEndOpen=false;powerTrayOpen=false;gesturePiece=-1;screen=s;paused=false;restartConfirm=false;help=false;selected=-1;pressed=null;focused=hovered=-1;hits.clear();syncStyle();
        if(s.equals("play")&&!won&&running&&!outOfMoves()){thawEffects();activeStarted=SystemClock.uptimeMillis();resumeFlow();}else freezeEffects();
        invalidate();if(Build.VERSION.SDK_INT>=28)setAccessibilityPaneTitle(screenTitle(s));
        sceneAnnouncementPending=changing&&sceneTransition.blocksInput(SystemClock.uptimeMillis());if(!sceneAnnouncementPending)sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);
    }
    private void goRoot(String destination){menuHistory.clear();go(destination);menuHistory.clear();}
    private void backMenu(){nextSceneDirection=SceneTransition.Direction.BACK;String destination=menuHistory.isEmpty()?"adventure":menuHistory.pop();navigatingBack=true;try{go(destination);}finally{navigatingBack=false;}}
    private void log(String event,String... fields){Map<String,String> values=new HashMap<>();for(int i=0;i+1<fields.length;i+=2)values.put(fields[i],fields[i+1]);journal.record(event,values);}
    private void stopTimer(){if(activeStarted>0){activeElapsed+=Math.max(0,SystemClock.uptimeMillis()-activeStarted);activeStarted=0;}}
    private long elapsed(){return activeElapsed+(activeStarted>0?Math.max(0,SystemClock.uptimeMillis()-activeStarted):0);}
    private void setPaused(boolean value){actionGeneration++;if(value){stopTimer();freezeEffects();}paused=value;if(!value){thawEffects();resumeFlow();}if(!value&&running&&!help&&!won&&!outOfMoves()&&activeStarted==0)activeStarted=SystemClock.uptimeMillis();}
    private void setHelp(boolean value){actionGeneration++;if(value){stopTimer();freezeEffects();}help=value;if(!value){thawEffects();resumeFlow();}pressed=null;focused=hovered=-1;hits.clear();if(!value&&screen.equals("play")&&running&&!paused&&!won&&!outOfMoves()&&activeStarted==0)activeStarted=SystemClock.uptimeMillis();invalidate();}

    private void notice(String s){toast=s;toastUntil=SystemClock.uptimeMillis()+2700;announceForAccessibility(s);invalidate();}
    private String l(String key,Object...args){return LearningStrings.get(store.resolvedLanguage(),key,args);}
    private LearningGuide.Context lesson(Board current){return LearningGuide.context(current,current.level.progressionVersion==6?RelayCatalog.lesson(current.level.number):current.level.progressionVersion==5?LearningCatalog.lesson(current.level.number):null);}
    private boolean hasReturn(){return board!=null&&moveBudget!=null&&board.canUndo()&&moveBudget.undoRemaining(undos)>0;}
    private String returnLabel(){if(economyPolicy121&&arcadeEnabled121())return undos<EconomyCurve121.freeUndos()?a21("undo_free",EconomyCurve121.freeUndos()-undos):a21("undo_price",EconomyCurve121.undoPrice(levelIndex,undos-EconomyCurve121.freeUndos()+1));return moveBudget!=null&&moveBudget.policyVersion()==MoveBudget.DELIBERATE_POLICY_VERSION?l("undo_remaining",moveBudget.undoRemaining(undos)):t("undo");}
    private String en20(String key,Object...args){return SessionEnergyStrings.get(store.resolvedLanguage(),key,args);}
    private int sessionEnergyCount(){return sessionEnergy.snapshot(System.currentTimeMillis()).count;}
    private String sessionEnergyLabel(){return a21("energy_label",sessionEnergyCount(),sessionEnergy.maximum());}
    private void openSessionEnergy(){go("session_energy");}
    private String restartLabel120(){return SessionEnergyStore.costsEnergy(mode,levelIndex)?t("restart")+" · 1 "+en20("title"):t("restart_free");}
    private String reserveSessionEnergy(int newMode,int newLevel){
        String next=UUID.randomUUID().toString();
        if((newMode==0||newMode==5)&&newLevel>=1&&newLevel<=1000)sessionEnergy.setCapacity(EconomyCurve121.energyCapacity(newLevel),System.currentTimeMillis());
        if(!SessionEnergyStore.costsEnergy(newMode,newLevel))return next;
        if(!sessionEnergy.reserve(next,System.currentTimeMillis())){openSessionEnergy();return null;}
        return next;
    }
    private void confirmSessionEnergyRun(){sessionEnergy.confirm(runId,System.currentTimeMillis());}
    private String a21(String key,Object...args){return Arcade121Strings.get(store.resolvedLanguage(),key,args);}
    private boolean arcadeEnabled121(){return board!=null&&board.level.progressionVersion==6&&(mode==0||mode==5);}
    private String elementLabel121(int id){return a21(elements121.kind(id).name().toLowerCase(Locale.ROOT),elements121.layers(id));}
    private void tapElement121(int id){
        if(elements121==null||board==null||!board.isPresent(id)||paused||help||won||powerSaveBlocked)return;
        ElementalShell121.Kind kind=elements121.kind(id);if(kind==ElementalShell121.Kind.NONE)return;
        ElementalShell121.TapResult result=elements121.tap(id);actionGeneration++;
        Tile tile=board.level.tile(id);successX=bx+(tile.col+.5f)*cell;successY=by+(tile.row+.5f)*cell;successUntil=SystemClock.uptimeMillis()+450;
        puzzleReaction.success(SystemClock.uptimeMillis());gatePulseUntil=SystemClock.uptimeMillis()+500;
        sfx(result==ElementalShell121.TapResult.CLEARED?AudioEngine.Sound.GATE:AudioEngine.Sound.TAP);haptic();
        if(!persistMove())return;
        notice(result==ElementalShell121.TapResult.CLEARED?a21("shell_clear"):a21(kind.name().toLowerCase(Locale.ROOT),elements121.layers(id)));
    }
    private float arcadeRailHeight121(){return Math.max(48,battleMinimumTouch())+8;}
    private void drawFocus121(Canvas c,float y){
        String caption=exitChain121.ready()?a21("focus_ready"):exitChain121.spent()?a21("focus_used"):a21("chain",exitChain121.progress());
        modernAction(c,new RectF(24,y,366,y+arcadeRailHeight121()-8),"✦  "+caption,exitChain121.ready()?0xffa2e2d8:0xffe8e1f7,"arcade_focus",()->{
            if(!exitChain121.ready()){notice(a21("focus_rule"));return;}
            ensureGuidance();if(guidancePending){notice(n("thinking"));return;}
            if(guidance==null||!guidance.canUseHint()||guidance.hintTileId<0){notice(t("no_safe_move"));return;}
            if(!exitChain121.use())return;
            hintId=guidance.hintTileId;hintUntil=SystemClock.uptimeMillis()+8000;hintsUsed++;
            if(!persistMove())return;sfx(AudioEngine.Sound.HINT);haptic();announceForAccessibility(a21("focus_used"));
        },true);
    }
    private void drawWalletGain121(Canvas c,RewardMotion121.Counter motion,int index){
        long gain=motion.gain(frameTime);if(gain<=0)return;
        Menu120Layout.Rect r=Menu120Layout.wallet(index,battleMinimumTouch());float age=motion.age(frameTime);
        for(int i=0;i<4;i++){float u=Math.max(0,Math.min(1,(age-i*.10f)/.65f));if(u<=0||u>=1)continue;
            float xx=r.left+18+(float)Math.sin((i+1)*1.8)*23*(1-u),yy=r.top+52-u*24;
            int save=c.saveLayerAlpha(r.left,r.top,r.right,r.bottom,Math.round(210*(1-u)));
            if(index==0)shopArt.coin(c,xx,yy,6,frameTime,true);else shopArt.gold(c,xx,yy,6,frameTime,true);c.restoreToCount(save);
        }
        if(age<.85f)fit(c,"+"+gain,r.right-8,r.top+63-age*12,11,65,index==0?0xff9d681e:0xff7252a8,true,true);
    }
    private void drawEconomy121(Canvas c){
        header(c,a21("loop"),a21("loop_intro"));float y=126;
        String[] titles={a21("coins"),a21("xp"),a21("evolution"),a21("gold"),en20("title")};
        String[] copy={a21("coins_detail"),a21("xp_detail"),a21("evolution_detail"),a21("gold_detail"),a21("energy_detail")};
        int[] colors={0xffffefd0,0xffe9e1ff,0xffdcf3eb,0xffeee3fb,0xffffe4ec};
        for(int i=0;i<titles.length;i++){
            float h=Math.max(166,twoLineLayout(copy[i],306,14,PremiumUi.MUTED).getHeight()+115);
            round(c,24,y,342,h,26,colors[i]);fit(c,titles[i],44,y+34,19,300,TEXT,true,false);
            wrap(c,copy[i],44,y+64,300,14,PremiumUi.MUTED,false,21);
            label(24,y,342,h,titles[i]+". "+copy[i]);y+=h+16;
        }
        y=prose(c,a21("economy_curve"),y+8,PremiumUi.MUTED)+18;
        y=prose(c,a21("undo_rule"),y,PremiumUi.MUTED)+18;
        modernAction(c,new RectF(24,y,366,y+56),m20("shop"),0xffd7c5f6,"economy_shop",()->goRoot("shop"),true);y+=72;
        modernAction(c,new RectF(24,y,366,y+56),a21("evolution"),0xffbfebdc,"economy_evolution",()->go("evolution"),true);economyHeight121=y+90;H=Math.max(viewportH,economyHeight121);
    }
    private void drawEvolution121(Canvas c){
        header(c,a21("evolution"),t(character.nameKey));CompanionProgression.Stats stats=store.companionStats(character.id);
        float y=prose(c,a21("evolution_detail"),112,PremiumUi.MUTED)+14;
        round(c,24,y,342,116,25,0xffe8e1f8);fit(c,Menu121Strings.get(store.resolvedLanguage(),"companion_level",Math.max(1,stats.level)),44,y+32,22,300,TEXT,true,false);
        fit(c,stats.maxed()?"Lv. 10":Menu121Strings.get(store.resolvedLanguage(),"copies_progress",stats.copies,stats.nextThreshold),44,y+60,15,300,TEXT,true,false);
        round(c,44,y+79,302,9,5,0xffd3c6e7);round(c,44,y+79,302f*Math.min(1,stats.copies/(float)Math.max(1,stats.nextThreshold)),9,5,0xff9276c9);y+=137;
        float rowHeight=Math.max(234,198+minimumTextSize()*3);
        for(int i=0;i<4;i++){
            int milestone=CompanionMotion.formLevel(i);float left=24+(i%2)*177,yy=y+(i/2)*rowHeight;boolean owned=stats.level>=milestone;
            round(c,left,yy,165,rowHeight-14,25,owned?0xffe1f3ec:0xffeee9f6);
            CompanionMotion.Frame frame=CompanionMotion.sample(character.id,milestone,CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,CompanionMotion.Stance.CALM,frameTime,reduceMotion);
            companionPortrait.draw(c,character,left+82.5f,yy+83,43,AvatarStyles.find(avatarStyle),AvatarStage.Pose.IDLE,frameTime,reduceMotion,null,Collections.emptyList(),frame);
            fit(c,a21("form",milestone),left+82.5f,yy+167,15,149,TEXT,true,true);
            fit(c,owned?r("owned"):a21("form_preview",CompanionProgression.threshold(milestone)),left+82.5f,yy+193,12,149,PremiumUi.MUTED,false,true);
            label(left,yy,165,rowHeight-14,a21("form",milestone)+". "+(owned?r("owned"):a21("form_preview",CompanionProgression.threshold(milestone))));
        }
        y+=rowHeight*2+10;fit(c,battleFamily(character.id),24,y+26,22,342,TEXT,true,false);y=prose(c,battleDetail(character.id),y+45,PremiumUi.MUTED)+14;
        modernAction(c,new RectF(24,y,366,y+56),v19("squad"),0xffc3eadd,"evolution_squad",()->openSquad(),true);y+=71;
        modernAction(c,new RectF(24,y,366,y+56),a21("earned_path"),0xffd8ccf2,"evolution_expedition",()->{expeditionTarget=character.id;go("expedition");},true);y+=71;
        modernAction(c,new RectF(24,y,366,y+56),a21("loop"),0xffffe9c4,"evolution_economy",()->go("economy"),true);evolutionHeight121=y+86;H=Math.max(viewportH,evolutionHeight121);
    }
    private void drawSessionEnergy(Canvas c){
        modernAction(c,new RectF(20,16,124,66),"‹ "+en20("back"),0xffece8f8,"energy_back",()->backMenu(),true);
        center(c,en20("title"),195,111,28,TEXT,true);
        float pulse=reduceMotion?0:(float)Math.sin(frameTime*.002)*3;
        p.setColor(0xffe9e2fd);c.drawCircle(195,214,70+pulse,p);
        icon(c,"star",195,210,45,0xffa08ae7);
        center(c,sessionEnergyCount()+" / "+sessionEnergy.maximum(),195,318,34,TEXT,true);
        SessionEnergyStore.Snapshot energy=sessionEnergy.snapshot(System.currentTimeMillis());
        String countdown=String.format(Locale.ROOT,"%02d:%02d",(energy.nextInMs+999)/60000,((energy.nextInMs+999)/1000)%60);
        fit(c,energy.count==sessionEnergy.maximum()?en20("full"):en20("next",countdown),195,356,17,342,TEXT,true,true);
        float y=prose(c,en20("rule"),400,PremiumUi.MUTED);y=prose(c,a21("energy_refill",sessionEnergy.maximum()),y+9,PremiumUi.MUTED);
        modernAction(c,new RectF(24,y+18,366,y+76),energyPurchases.ownedRefills()>0?en20("use"):en20("buy"),0xffffc9b8,"energy_buy",this::buySessionEnergy,energy.count==0&&energyPurchases.available()&&!energyPurchases.isBusy());
        y=prose(c,energyPurchases.statusLabel(store.resolvedLanguage()),y+106,TEXT);y=prose(c,en20("buy_note"),y+8,PremiumUi.MUTED);y=prose(c,en20("free"),y+12,PremiumUi.MUTED);
        modernAction(c,new RectF(24,y+18,366,y+74),n("learn"),0xffc3eddd,"energy_practice",()->openTutorial(true),true);energyHeight121=y+100;H=Math.max(viewportH,energyHeight121);
    }
    private void buySessionEnergy(){
        if(energyPurchases.isBusy())return;
        if(energyPurchases.ownedRefills()>0){energyPurchases.useStoredRefill();return;}
        if(!energyPurchases.available()){notice(energyPurchases.statusLabel(store.resolvedLanguage()));return;}
        confirmInScene(en20("title"),en20("buy")+"\n"+energyPurchases.statusLabel(store.resolvedLanguage()),()->energyPurchases.buyRefill());
    }
    private void start(int index,int m,int e){savedAction(()->start121(index,m,e));}
    private void start121(int index,int m,int e){
        if(m==3&&(!store.remixAvailable()||index>store.remixUnlockedLevel())){notice(t("remix_unlock"));return;}
        if(!prepareAbandon())return;
        String energyRun=reserveSessionEnergy(m,index);if(energyRun==null)return;
        stopTimer();activeElapsed=0;activeStarted=0;friendCode="";
        levelIndex=Math.max(1,Math.min(m==3?BalancedCatalog.REMIX_COUNT:BalancedCatalog.LEVEL_COUNT,index));contentVersion=m==0?7:5;moveStreak=0;mode=m;eventIndex=e;eventPeriod=m==1?store.dailyId():m==2?store.weeklyId():m==3?"remix-v1":"";
        Level l=m==0?RelayCatalog.get(levelIndex):m==3?StrategyCatalog.remix(levelIndex):StrategyCatalog.event(m==1?store.dailySeed(e):store.weeklySeed(e));
        board=new Board(l);resetMoveRun();runId=energyRun;puzzleReaction.reset();coachId=m==0&&levelIndex==1?board.hint():-1;hintsUsed=undos=xpReward=0;won=paused=false;flights.clear();hintId=-1;visionUntil=0;winAt=0;
        goRoot("play");log("level_start","mode",""+m,"level",""+levelIndex,"event_index",""+eventIndex,"period",eventPeriod);if(!saveSession())powerSaveBlocked=true;
    }
    public void openJournal(){go("journal");}
    private void openCommerce(){getContext().startActivity(new android.content.Intent(getContext(),com.androidhit.lumadrift.commerce.CommerceActivity.class));}
    public void openChallenge(String input){
        String raw=input==null?"":input.trim();
        try{if(raw.startsWith("lumadrift://")){android.net.Uri uri=android.net.Uri.parse(raw);if(!"challenge".equals(uri.getHost())||uri.getPathSegments().size()!=1||uri.getQuery()!=null||uri.getFragment()!=null){notice(t("challenge_invalid"));return;}raw=uri.getLastPathSegment();}}
        catch(RuntimeException invalid){notice(t("challenge_invalid"));return;}
        ChallengeCode code=ChallengeCode.parse(raw);if(code==null){notice(t("challenge_invalid"));return;}
        if(!prepareAbandon())return;
        stopTimer();activeElapsed=activeStarted=0;friendCode=raw;mode=4;eventIndex=0;eventPeriod="";levelIndex=code.kind==ChallengeCode.Kind.EVENT?1:(int)code.value;
        coachId=-1;contentVersion=4;moveStreak=0;board=new Board(challengeLevel(code));resetMoveRun();
        hintsUsed=undos=xpReward=0;won=paused=false;flights.clear();hintId=-1;visionUntil=0;winAt=0;goRoot("play");log("challenge_open","kind",code.kind.name());saveSession();
    }
    private String currentCode(){
        if(mode==4&&!friendCode.isEmpty())return friendCode;
        if(board==null)return ChallengeCode.encodeRelay(Math.min(BalancedCatalog.LEVEL_COUNT,store.unlockedLevel()));
        if(mode==5)return ChallengeCode.encodeRelay(levelIndex);
        if(mode==0)return contentVersion==7?ChallengeCode.encodeRelay(levelIndex):contentVersion==6?ChallengeCode.encodeLearning(levelIndex):contentVersion==2?ChallengeCode.encodeBalanced(levelIndex):contentVersion==3?ChallengeCode.encodeBalancedV2(levelIndex):contentVersion==4?ChallengeCode.encodeBalancedV3(levelIndex):ChallengeCode.encodeStrategy(levelIndex);
        if(mode==3)return contentVersion==2?ChallengeCode.encodeBalancedRemix(levelIndex):contentVersion==3?ChallengeCode.encodeBalancedRemixV2(levelIndex):contentVersion==4?ChallengeCode.encodeBalancedRemixV3(levelIndex):ChallengeCode.encodeStrategyRemix(levelIndex);
        return board.level.progressionVersion>=4?ChallengeCode.encodeStrategyEvent(board.level.seed):ChallengeCode.encodeEvent(board.level.seed);
    }
    private void shareBoard(){
        try{Level level=board==null?RelayCatalog.get(Math.min(BalancedCatalog.LEVEL_COUNT,store.unlockedLevel())):board.level;ShareComposer.shareChallenge((Activity)getContext(),level,currentCode(),store.resolvedLanguage(),won?resultStars:0,character.color);log("share_handoff","kind",mode==4?"friend":""+mode);}
        catch(java.io.IOException|android.content.ActivityNotFoundException failure){notice(t("share_error"));}
    }
    private void importCode(){showTextSheet(t("import_challenge"),t("import_hint"),"",android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,100,value->{openChallenge(value);return null;});}
    private void continueGame(){if(board!=null&&!won&&!board.isSolved()){goRoot("play");return;}start(Math.min(BalancedCatalog.LEVEL_COUNT,store.unlockedLevel()),0,0);}
    private boolean saveSession(){
        if(board!=null&&elements121!=null)for(Tile tile:board.level.tiles)if(!board.isPresent(tile.id))elements121.clear(tile.id);
        SharedPreferences.Editor e=(mode==5?expeditionPrefs:prefs).edit().putString("last_power_request",lastPowerRequest);
        if(board==null||won){boolean saved=e.putBoolean("active",false).commit();if(saved)confirmSessionEnergyRun();return saved;}
        StringBuilder history=new StringBuilder();for(int id:board.history()){if(history.length()>0)history.append(',');history.append(id);}
        e.putBoolean("active",true).putInt("level",levelIndex).putInt("mode",mode).putInt("event",eventIndex)
            .putString("event_id",eventPeriod)
            .putString("history",history.toString()).putString("challenge_code",friendCode).putLong("elapsed_ms",elapsed()).putInt("hints",hintsUsed).putInt("undos",undos)
            .putInt("content_version",contentVersion).putLong("level_seed_v120",board.level.seed).putInt("budget_policy",moveBudget.policyVersion()).putString("run_id",runId)
            .putInt("budget_used",moveBudget.used()).putInt("budget_extensions",moveBudget.extensions()).putInt("budget_extra",moveBudget.extraActions())
            .putString("pending_continuation",pendingContinuation).putString("last_continuation",lastAppliedContinuation).putInt("shield_charges",shieldCharges).putInt("gear_grace",gearGrace)
            .putInt("flow_remaining",flowRemaining).putInt("hint_id",hintId)
            .putLong("hint_ms",effectRemaining(hintUntil)).putLong("vision_ms",effectRemaining(visionUntil))
            .putLong("focus_ms",effectRemaining(focusUntil)).putLong("trail_ms",effectRemaining(trailUntil))
            .putString("trail_ids",joinIds(trail)).putString("focus_ids",joinIds(safeHighlights))
            .putString("battle_v119",battleState==null?"":battleState.encode())
            .putString("elements_v121",elements121==null?"":elements121.encode()).putString("exit_chain_v121",exitChain121.encode()).putBoolean("economy_policy_v121",economyPolicy121).putString("last_paid_undo_v121",lastPaidUndo121);
        boolean saved=e.commit();if(saved)confirmSessionEnergyRun();return saved;
    }
    private SharedPreferences victoryPreferences(){return getContext().getSharedPreferences("luma_victory_v120",0);}
    private VictoryReceipt readVictory(){return VictoryReceipt.decode(victoryPreferences().getString("receipt",""));}
    private void restoreSession(){
        VictoryReceipt result=readVictory();
        if(result!=null&&restoreSessionFrom(result.mode==5?expeditionPrefs:prefs))return;
        restoreSessionFrom(prefs);
    }
    private boolean restoreSessionFrom(SharedPreferences source){
        SharedPreferences prefs=source;
        String savedLastPower=prefs.getString("last_power_request","");
        if(source!=expeditionPrefs){lastPowerRequest=savedLastPower;reconcilePowerReservation();}
        VictoryReceipt savedVictory=readVictory();
        boolean matchingVictory=savedVictory!=null&&savedVictory.matches(prefs.getString("run_id",""),prefs.getInt("mode",0),prefs.getInt("level",1),prefs.getInt("event",0),prefs.getString("event_id",""));
        if(!prefs.getBoolean("active",false)&&!matchingVictory)return false;
        if(prefs.getInt("content_version",0)!=2&&prefs.getInt("content_version",0)!=3&&prefs.getInt("content_version",0)!=4&&prefs.getInt("content_version",0)!=5&&prefs.getInt("content_version",0)!=6&&prefs.getInt("content_version",0)!=7){prefs.edit().putBoolean("active",false).putBoolean("session_migration_notice",true).commit();return false;}
        try{
            int contentVersion=prefs.getInt("content_version",2);
            int m=prefs.getInt("mode",0), e=prefs.getInt("event",0), l=prefs.getInt("level",1);
            String id=prefs.getString("event_id","");
            if(!matchingVictory&&(m==1&&!id.equals(store.dailyId())||m==2&&!id.equals(store.weeklyId())))return false;
            if(m<0||m>5||m==0&&!store.isLevelUnlocked(l)||m==1&&(e<0||e>2)||m==2&&(e<0||e>6)||m==3&&(!store.remixAvailable()||l<1||l>store.remixUnlockedLevel()))return false;
            String savedCode=prefs.getString("challenge_code","");ChallengeCode friend=m==4?ChallengeCode.parse(savedCode):null;if(m==4&&friend==null)return false;
            ExpeditionRun expedition=m==5?store.expeditionRun():null;
            boolean completedExpeditionVictory=false;
            if(m==5&&matchingVictory&&expedition!=null&&expedition.id.equals(id))for(ExpeditionRun.StageResult stage:expedition.results())
                if(stage.victoryId.equals(savedVictory.runId)&&stage.boardNumber==l&&stage.stars==savedVictory.stars)completedExpeditionVictory=true;
            if(m==5&&(source!=expeditionPrefs||expedition==null||!expedition.id.equals(id)||!completedExpeditionVictory&&(expedition.finished()||expedition.selectedOption()==null||expedition.stage()!=e||expedition.selectedOption().boardNumber!=l)))return false;
            Level lev=m==5?RelayCatalog.get(l):m==0?(contentVersion==7?RelayCatalog.get(l):contentVersion==6?LearningCatalog.get(l):contentVersion==2?BalancedCatalog.legacyGet(l):contentVersion==3?BalancedCatalog.getV2(l):contentVersion==4?BalancedCatalog.get(l):StrategyCatalog.get(l)):m==3?(contentVersion==2?BalancedCatalog.legacyRemix(l):contentVersion==3?BalancedCatalog.remixV2(l):contentVersion==4?BalancedCatalog.remix(l):StrategyCatalog.remix(l)):m==4?challengeLevel(friend):contentVersion>=5?StrategyCatalog.event(m==1?store.dailySeed(e):store.weeklySeed(e)):LevelCatalog.event(m==1?store.dailySeed(e):store.weeklySeed(e));
            if(matchingVictory&&(m==1||m==2)&&prefs.contains("level_seed_v120"))lev=contentVersion>=5?StrategyCatalog.event(prefs.getLong("level_seed_v120",0)):LevelCatalog.event(prefs.getLong("level_seed_v120",0));
            Board b=new Board(lev);String raw=prefs.getString("history","");String[] parts=raw.isEmpty()?new String[0]:raw.split(",");int[] moves=new int[parts.length];
            for(int i=0;i<moves.length;i++)moves[i]=Integer.parseInt(parts[i]);
            if(b.restoreHistory(moves)){
                int policy=prefs.getInt("budget_policy",0);
                MoveBudget restored=MoveBudget.restoreVersion(policy,m==5?0:m,lev,prefs.getInt("budget_used",-1),prefs.getInt("budget_extensions",-1),prefs.getInt("budget_extra",-1),b.moves(),prefs.getInt("undos",0));
                String restoredRun=prefs.getString("run_id","");
                if(policy==2&&restored!=null)restored=MoveBudget.toReversible(m,lev,prefs.getInt("budget_used",-1),prefs.getInt("budget_extensions",-1),prefs.getInt("budget_extra",-1),b.moves(),prefs.getInt("undos",0));
                boolean ledgerUpgraded=false;
                if(restored!=null&&policy<MoveBudget.DELIBERATE_POLICY_VERSION){
                    MoveBudget deliberate=MoveBudget.toDeliberate(m,lev,restored,b.moves(),prefs.getInt("undos",0));
                    if(deliberate!=null){restored=deliberate;ledgerUpgraded=true;}
                }
                if(restored==null||!restoredRun.matches("[a-f0-9-]{36}"))return false;
                this.contentVersion=contentVersion;lastPowerRequest=savedLastPower;moveBudget=restored;runId=restoredRun;pendingContinuation=prefs.getString("pending_continuation","");lastAppliedContinuation=prefs.getString("last_continuation","");
                if(!pendingContinuation.isEmpty()&&!pendingContinuation.matches("[ag]:"+runId+":\\d{1,2}"))pendingContinuation="";
                shieldCharges=Math.max(0,Math.min(3,prefs.getInt("shield_charges",0)));board=b;mode=m;eventIndex=e;levelIndex=l;eventPeriod=id;friendCode=savedCode;activeElapsed=Math.max(0,prefs.getLong("elapsed_ms",0));hintsUsed=prefs.getInt("hints",0);undos=prefs.getInt("undos",0);
                gearGrace=Math.max(0,Math.min(1,prefs.getInt("gear_grace",0)));flowRemaining=Math.max(0,Math.min(2,prefs.getInt("flow_remaining",0)));
                effectsPausedAt=0;long now=SystemClock.uptimeMillis();hintId=prefs.getInt("hint_id",-1);hintUntil=now+Math.min(8000,Math.max(0,prefs.getLong("hint_ms",0)));
                visionUntil=now+Math.min(8000,Math.max(0,prefs.getLong("vision_ms",0)));focusUntil=now+Math.min(10000,Math.max(0,prefs.getLong("focus_ms",0)));trailUntil=now+Math.min(12000,Math.max(0,prefs.getLong("trail_ms",0)));
                trail=parseIds(prefs.getString("trail_ids",""),5);for(int safe:parseIds(prefs.getString("focus_ids",""),68))if(board.isPresent(safe)||Board.isGateAction(safe)&&board.canPerformAction(safe))safeHighlights.add(safe);
                economyPolicy121=prefs.getBoolean("economy_policy_v121",false);lastPaidUndo121=prefs.getString("last_paid_undo_v121","");
                elements121=ElementalShell121.decode(board.level,prefs.getString("elements_v121",""));if(elements121==null)elements121=ElementalShell121.empty(board.level);
                exitChain121=ExitChain121.decode(prefs.getString("exit_chain_v121",""),board.level);if(exitChain121==null)exitChain121=new ExitChain121();
                for(Tile tile:board.level.tiles)if(!board.isPresent(tile.id))elements121.clear(tile.id);
                String encodedBattle=prefs.getString("battle_v119",null);
                battleState=encodedBattle==null?CompanionBattle.State.start(store.companionSquad()):CompanionBattle.State.decode(encodedBattle);
                if(battleState!=null)for(String member:battleState.team())if(!store.ownsCharacter(member)){battleState=null;break;}
                if(flowRemaining>0)powerGate.tryBegin("flow",false,now);
                if(matchingVictory&&savedVictory.ready&&board.isSolved()){publishVictory(savedVictory,true);screen="play";contentScroll=0;}
                if((policy==2||ledgerUpgraded)&&!saveSession())powerSaveBlocked=true;
                return true;
            }
        }catch(GameStore.LocalSaveException failure){throw failure;}catch(RuntimeException ignored){prefs.edit().putBoolean("active",false).apply();}
        return false;
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);int checkpoint=c.save();
        SceneTransition.Frame transition=sceneTransition.frame(SystemClock.uptimeMillis());drawingScene=true;
        try{
            if(localSaveBlocked)drawLocalSaveRetry(c);
            else if(transition.active&&outgoingScene!=null&&!outgoingScene.isRecycled()){
                c.drawColor(skin.bg);sceneBitmapPaint.setAlpha(transition.outgoingAlpha255());
                c.drawBitmap(outgoingScene,transition.outgoingOffsetX*getWidth(),0,sceneBitmapPaint);sceneBitmapPaint.setAlpha(255);
                int incoming=c.saveLayerAlpha(0,0,getWidth(),getHeight(),transition.incomingAlpha255());
                c.translate(transition.incomingOffsetX*getWidth(),0);drawFrame(c);c.restoreToCount(incoming);
            }else drawFrame(c);
        }catch(GameStore.LocalSaveException failure){c.restoreToCount(checkpoint);checkpoint=c.save();blockLocalSave();drawLocalSaveRetry(c);}
        finally{drawingScene=false;c.restoreToCount(checkpoint);}
        if(transition.active&&running)postInvalidateDelayed(16);
        else if(sceneAnnouncementPending){sceneAnnouncementPending=false;sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);}
    }
    private void beginScenePresentation(){
        rootSwipe.cancel();sceneInputDiscarded=false;
        if(!drawingScene&&running&&!reduceMotion&&getWidth()>0&&getHeight()>0){
            try{
                if(outgoingScene==null||outgoingScene.getWidth()!=getWidth()||outgoingScene.getHeight()!=getHeight()){
                    if(outgoingScene!=null)outgoingScene.recycle();outgoingScene=Bitmap.createBitmap(getWidth(),getHeight(),Bitmap.Config.ARGB_8888);
                }
                drawingScene=true;drawFrame(new Canvas(outgoingScene));drawingScene=false;
                sceneTransition.begin(SystemClock.uptimeMillis(),false,nextSceneDirection);
            }catch(OutOfMemoryError failure){drawingScene=false;finishScenePresentation();}
            finally{drawingScene=false;}
        }else sceneTransition.begin(SystemClock.uptimeMillis(),true,nextSceneDirection);
        nextSceneDirection=SceneTransition.Direction.FORWARD;
    }
    private void finishScenePresentation(){
        sceneTransition.finish();rootSwipe.cancel();sceneAnnouncementPending=false;sceneInputDiscarded=false;
        if(outgoingScene!=null){outgoingScene.recycle();outgoingScene=null;}
    }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);if(w!=oldw||h!=oldh)finishScenePresentation();}
    private boolean sceneActionsBlocked(){return sceneTransition.blocksInput(SystemClock.uptimeMillis());}
    private int rootIndex(){for(int i=0;i<rootPlaces.length;i++)if(rootPlaces[i].equals(screen))return i;return -1;}
    private void changeRoot(SceneTransition.RootSwipe.Result direction){
        int current=rootIndex();if(current<0||direction==SceneTransition.RootSwipe.Result.NONE)return;
        int next=current+(direction==SceneTransition.RootSwipe.Result.LEFT?1:-1);
        if(next<0||next>=rootPlaces.length)return;
        nextSceneDirection=direction==SceneTransition.RootSwipe.Result.LEFT?SceneTransition.Direction.LEFT:SceneTransition.Direction.RIGHT;if(rootPlaces[next].equals("squad"))openSquad();else goRoot(rootPlaces[next]);
    }
    private void blockLocalSave(){finishScenePresentation();
        localSaveBlocked=true;actionGeneration++;stopTimer();freezeEffects();pressed=null;gesturePiece=gestureGate=-1;gestureGuardian=false;hits.clear();invalidate();
    }
    private void retryLocalSave(){
        try{store.retryPendingLocalSave();localSaveBlocked=false;syncStyle();if(!localSaveBlocked)resumeApp();}
        catch(GameStore.LocalSaveException failure){blockLocalSave();}
        invalidate();
    }
    private void drawLocalSaveRetry(Canvas c){
        menuHudInset=0;
        frameTime=SystemClock.uptimeMillis();layout=new ExperienceLayout(getWidth(),getHeight(),safeTop,safeBottom,getResources().getDisplayMetrics().density,getResources().getConfiguration().fontScale);
        premium.setMinimumTextSize(layout.minimumTextSize);scenic.setMinimumTextSize(layout.minimumTextSize);scale=layout.scale;ox=layout.offsetX;top=safeTop;viewportH=layout.viewportHeight;drawingScroll=0;drawingClipBottom=viewportH;hits.clear();
        c.drawColor(skin.bg);c.save();c.translate(ox,top);c.scale(scale,scale);float y=Math.max(16,viewportH/2-130);
        scenePaper(c,new RectF(24,y,366,y+260),SweetUi.CREAM,true);
        wrap(c,t("commerce_save_error"),195,y+58,290,18,TEXT,true,25);label(44,y+25,302,103,t("commerce_save_error"));
        objectAction(c,t("retry"),44,y+151,302,52,PEACH,()->retryLocalSave());c.restore();if(running)postInvalidateDelayed(500);
    }
    private void drawFrame(Canvas c){
        frameTime=SystemClock.uptimeMillis();
        layout=new ExperienceLayout(getWidth(),getHeight(),safeTop,safeBottom,getResources().getDisplayMetrics().density,getResources().getConfiguration().fontScale);
        premium.setMinimumTextSize(layout.minimumTextSize);scenic.setMinimumTextSize(layout.minimumTextSize);scale=layout.scale;ox=layout.offsetX;top=safeTop;viewportH=layout.viewportHeight;H=screen.equals("journey")&&!(journeyTab==1&&!store.remixAvailable())?SagaMap.height(journeyTab==1?BalancedCatalog.REMIX_COUNT:BalancedCatalog.LEVEL_COUNT):Math.max(layout.contentHeight,screen.equals("guardians")?4570:screen.equals("guardian")?900:screen.equals("styles")?1140:screen.equals("rewards")?rewardContentHeight():screen.equals("wardrobe")?1020:screen.equals("item")?detailHeight:screen.equals("shop")?shopContentHeight120:screen.equals("story")?1080:screen.equals("home")?(homeDecorating&&!homeSelection.isEmpty()?1433:1253):screen.equals("briefing")?950:screen.equals("tutorial")?viewportH<480&&!tutorial.complete()?433:820:840);
        menuHudInset=menuHudVisible()?Menu120Layout.hudHeight(battleMinimumTouch()):0;
        viewportH=Math.max(180,layout.viewportHeight-menuHudInset);
        if(screen.equals("tutorial")&&viewportH<480&&!tutorial.complete())H=Math.max(viewportH,433);
        if(screen.equals("home_catalog"))H=Math.max(viewportH,246+(float)Math.ceil(homeCatalogIds().size()/2.0)*196+110);
        if(Arrays.asList("adventure","home","collection_hub","atelier","play","briefing").contains(screen))H=Math.max(viewportH,screen.equals("atelier")?910:screen.equals("collection_hub")?820:screen.equals("home")?550:screen.equals("adventure")?610:screen.equals("play")?550:600);
        if(screen.equals("expedition"))H=Math.max(viewportH,ExpeditionScene.requiredHeight(expeditionSnapshot(),layout.minimumTextSize));
        if(screen.equals("expedition_odds"))H=Math.max(viewportH,250+SummonCatalog.items(SummonCatalog.Banner.AVATARS).size()*85);
        if(screen.equals("companion_motion"))H=Math.max(viewportH,1000);
        if(screen.equals("wardrobe"))H=Math.max(viewportH,1120);
        if(screen.equals("profile"))H=Math.max(viewportH,1160);
        if(screen.equals("economy"))H=Math.max(viewportH,economyHeight121);
        if(screen.equals("evolution"))H=Math.max(viewportH,evolutionHeight121);
        if(screen.equals("badges"))H=Math.max(viewportH,1015);
        if(screen.equals("summon"))H=Math.max(viewportH,940);
        if(screen.equals("summon_pool"))H=Math.max(viewportH,248+(float)Math.ceil(SummonCatalog.items(summonBanner()).size()/2f)*248+110);
        if(screen.equals("summon_reveal"))H=Math.max(viewportH,summonRevealHeight121);
        if(screen.equals("session_energy"))H=Math.max(viewportH,energyHeight121);
        if(screen.equals("collection"))H=Math.max(viewportH,905);
        if(screen.equals("squad"))H=Math.max(viewportH,squadHeight);
        if(screen.equals("battle_skill"))H=Math.max(viewportH,battleSkillHeight);
        if(screen.equals("settings"))H=Math.max(viewportH,1110);
        if(screen.equals("home_item"))H=Math.max(layout.contentHeight,920);
        if(screen.equals("firstlight"))H=Math.max(layout.contentHeight,790);
        if(screen.equals("adventure"))H=new Menu121Layout(viewportH,battleMinimumTouch()).contentHeight;
        if(Arrays.asList("collection_hub","atelier").contains(screen))H=viewportH;
        // Measure the real play content before clamping: short windows may scroll
        // the actions without shrinking either the board or the physical targets.
        if(screen.equals("play")&&board!=null){
            playSceneLayout=new PlaySceneLayout(viewportH,board.level.progressionVersion==6,
                    48*getResources().getDisplayMetrics().density/Math.max(.01f,scale),
                    Math.max(42,twoLineLayout("Mg\nMg",338,12,PremiumUi.MUTED).getHeight()),minimumTextSize(),42+(battleEnabled()?battleRailHeight():0)+(arcadeEnabled121()?arcadeRailHeight121():0));
            H=won?viewportH:Math.max(viewportH,playSceneLayout.contentHeight);
        }
        contentScroll=clampScroll(contentScroll);
        c.drawColor(skin.bg);c.save();c.translate(ox,top);c.scale(scale,scale);hits.clear();
        background(c);c.save();drawingScroll=contentScroll;drawingClipBottom=viewportH+menuHudInset;
        c.clipRect(0,menuHudInset,390,drawingClipBottom);c.translate(0,menuHudInset-contentScroll);
        switch(screen){
            case "economy":drawEconomy121(c);break;case "evolution":drawEvolution121(c);break;case "session_energy":drawSessionEnergy(c);break;case "squad":drawSquad(c);break;case "battle_skill":drawBattleSkillPage(c);break;
            case "expedition":drawExpedition(c);break;case "expedition_odds":drawExpeditionOdds(c);break;case "profile":drawPlayerProfile(c);break;case "badges":drawBadges(c);break;case "summon":drawSummon(c);break;case "summon_pool":drawSummonPool(c);break;case "summon_reveal":drawSummonReveal(c);break;case "rules":drawRelayRules(c);break;case "adventure":drawAdventure(c);break;case "collection_hub":drawCollectionHub(c);break;case "atelier":drawAtelier(c);break;case "firstlight":drawFirstLight(c);break;case "home_catalog":drawHomeCatalog(c);break;case "home_item":drawHomeItem(c);break;
            case "story":drawPrismStory(c);break;case "guardians":drawGuardians(c);break;case "guardian":drawGuardian(c);break;case "styles":drawStyles(c);break;case "tutorial":drawTutorial(c);break;case "play":drawPlay(c);break;case "journey":drawJourney(c);break;
            case "companion_motion":drawCompanionMotion(c);break;case "item":drawItemDetail(c);break;case "briefing":drawBriefing(c);break;case "shop":drawShop(c);break;case "collection":drawCollection(c);break;
            case "wardrobe":drawWardrobe(c);break;case "rewards":drawRewards(c);break;case "events":drawEvents(c);break;case "settings":drawSettings(c);break;case "missions":drawMissions(c);break;case "journal":drawJournal(c);break;
            default:drawPremiumHome(c);
        }
        if(help){
            if(screen.equals("play")){c.save();c.translate(0,contentScroll);float old=drawingScroll,oldHeight=H;drawingScroll=0;H=viewportH;drawHelp(c);H=oldHeight;drawingScroll=old;c.restore();}
            else drawHelp(c);
        }c.restore();drawingScroll=0;drawingClipBottom=viewportH+menuHudInset;
        if(menuHudInset>0)drawMenuWalletHud(c);
        if(sceneConfirmAction!=null){c.save();c.translate(0,menuHudInset);drawSceneConfirmation(c);c.restore();}
        if(menuGiftAt>0)drawMenuGiftReveal(c);
        if(frameTime<toastUntil&&!screen.equals("play")&&menuGiftAt==0){float y=menuHudInset+Math.max(8,viewportH-90);round(c,24,y,342,65,20,0xfff6e9ff);wrap(c,toast,195,y+25,302,14,TEXT,true,19);}
        if(focused>=0&&focused<hits.size()){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(WHITE);c.drawRoundRect(hits.get(focused).r,15,15,p);p.setStyle(Paint.Style.FILL);}
        if(maximumScroll()>0){float track=viewportH-24,thumb=Math.max(25,track*viewportH/H),yy=menuHudInset+12+(track-thumb)*contentScroll/maximumScroll();round(c,384,yy,3,thumb,2,0x556f598d);}
        c.restore();if(running){
            if(!reduceMotion&&(screen.equals("play")||rootIndex()>=0||menuGiftAt>0||sceneTransition.blocksInput(frameTime)))postInvalidateOnAnimation();
            else postInvalidateDelayed(reduceMotion?250:32);
        }
    }
    private float maximumScroll(){return localSaveBlocked?0:Math.max(0,H-viewportH);}
    private float clampScroll(float amount){return Math.max(0,Math.min(maximumScroll(),amount));}
    private void background(Canvas c){
        if(Arrays.asList("play","guardian","briefing","tutorial","firstlight").contains(screen))audio.setScene(AudioEngine.Scene.PUZZLE);
        else if(screen.equals("home"))audio.setScene(AudioEngine.Scene.HOME);
        else if(Arrays.asList("atelier","home_catalog","home_item").contains(screen))audio.setScene(AudioEngine.Scene.ATELIER);
        else if(Arrays.asList("collection_hub","collection","wardrobe","profile","badges","styles","summon","summon_pool","summon_reveal").contains(screen))audio.setScene(AudioEngine.Scene.COLLECTION);
        else if(Arrays.asList("adventure","journey","events","guardians","story").contains(screen))audio.setScene(AudioEngine.Scene.ADVENTURE);
        int visibleLevel=screen.equals("play")?levelIndex:store.unlockedLevel();int biome=SagaMap.biome(visibleLevel);
        if(biome!=activeBiome){activeBiome=biome;audio.setBiome(biome);}backdrop.setBiome(biome);
        p.setColor(WHITE);p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,390,viewportH,new int[]{0xfff4f1ff,0xfffaf8ff,0xfffff5ee},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,390,viewportH+menuHudInset,p);p.setShader(null);
        if(screen.equals("play")&&board!=null)living121.draw(c,viewportH,levelIndex,paused||help?effectsPausedAt:frameTime,reduceMotion||paused||help,1f-board.remainingCount()/(float)board.level.tiles.size());
        if(screen.equals("home")){p.setColor(0x18b7d7ce);c.drawCircle(330,260,185,p);}
    }
    private static int alpha(int c,int a){return (c&0x00ffffff)|((Math.max(0,Math.min(255,a)))<<24);}
    private void round(Canvas c,float x,float y,float w,float h,float r,int color){p.setColor(color);p.setShader(null);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x,y,x+w,y+h,r,r,p);}
    private void stroke(Canvas c,RectF r,float radius,int color,float width){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);c.drawRoundRect(r,radius,radius,p);p.setStyle(Paint.Style.FILL);}
    private float minimumTextSize(){return layout==null?12:layout.minimumTextSize;}
    /** Preserve hue while keeping UI text readable on the new light surfaces. */
    private int readableText(int color){
        int opaque=color|0xff000000;double luminance=Color.luminance(opaque);
        if(luminance>.22)opaque=blend(opaque,INK,.60f);
        return opaque;
    }
    private void text(Canvas c,String str,float x,float y,float size,int color,boolean heavy){
        p.setShader(null);p.setTypeface(heavy?bold:regular);p.setTextSize(Math.max(minimumTextSize(),size));p.setColor(readableText(color));p.setTextAlign(Paint.Align.LEFT);c.drawText(str,x,y,p);
    }
    private void center(Canvas c,String str,float x,float y,float size,int color,boolean heavy){size=Math.max(minimumTextSize(),size);p.setTypeface(heavy?bold:regular);p.setTextSize(size);text(c,str,x-p.measureText(str)/2,y,size,color,heavy);}
    private void fit(Canvas c,String str,float x,float y,float size,float max,int color,boolean heavy,boolean centered){
        size=Math.max(minimumTextSize(),size);float minimum=minimumTextSize();p.setTypeface(heavy?bold:regular);p.setTextSize(size);float sw=p.measureText(str);
        if(sw>max)size=Math.max(minimum,size*max/sw);
        p.setTextSize(size);String visible=android.text.TextUtils.ellipsize(str,p,max,android.text.TextUtils.TruncateAt.END).toString();
        if(centered)center(c,visible,x,y,size,color,heavy);else text(c,visible,x,y,size,color,heavy);
    }
    private void wrap(Canvas c,String str,float x,float y,float max,float size,int color,boolean centered,float line){
        size=Math.max(minimumTextSize(),size);line=Math.max(line,size*1.3f);p.setTypeface(regular);p.setTextSize(size);StringBuilder row=new StringBuilder();float yy=y;
        for(String paragraph:str.split("\n",-1)){
            row.setLength(0);
            for(String word:paragraph.split(" ")){
                if(row.length()>0&&p.measureText(row+" "+word)>max){if(centered)center(c,row.toString(),x,yy,size,color,false);else text(c,row.toString(),x,yy,size,color,false);yy+=line;row.setLength(0);}
                if(row.length()>0)row.append(' ');row.append(word);
            }
            if(row.length()>0){if(centered)center(c,row.toString(),x,yy,size,color,false);else text(c,row.toString(),x,yy,size,color,false);}yy+=line;
        }
    }
    /** Fixed-height copy preserves the physical font floor without spilling into the next control. */
    private void twoLines(Canvas c,String value,float x,float y,float width,float size,int color){
        android.text.StaticLayout lines=twoLineLayout(value,width,size,color);
        c.save();c.translate(x,y);lines.draw(c);c.restore();
    }
    private android.text.StaticLayout twoLineLayout(String value,float width,float size,int color){
        return twoLineLayout(value,width,size,color,false);
    }
    private android.text.StaticLayout twoLineLayout(String value,float width,float size,int color,boolean centered){
        android.text.TextPaint copy=new android.text.TextPaint(p);copy.setTypeface(regular);copy.setTextSize(Math.max(minimumTextSize(),size));copy.setColor(readableText(color));copy.setShader(null);
        return android.text.StaticLayout.Builder.obtain(value,0,value.length(),copy,(int)width)
                .setIncludePad(false).setAlignment(centered?android.text.Layout.Alignment.ALIGN_CENTER:android.text.Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(2).setEllipsize(android.text.TextUtils.TruncateAt.END).build();
    }
    private void hit(float x,float y,float w,float h,String name,Runnable action){
        RectF r=new RectF(x,Menu120Layout.viewY(y,drawingScroll,menuHudInset),x+w,Menu120Layout.viewY(y+h,drawingScroll,menuHudInset));
        float clipTop=(drawingMapNodes?SagaMap.header(viewportH):0)+menuHudInset;
        if(!r.intersect(0,clipTop,390,drawingClipBottom))return;
        // Fully visible menu objects keep a real 48dp touch target at every display width.
        // Puzzle pieces retain their exact geometric hit regions.
        if(action!=null&&!Arrays.asList("play","guardian","tutorial","firstlight").contains(screen)){
            float cx=x+w/2,cy=Menu120Layout.viewY(y+h/2,drawingScroll,menuHudInset);
            // A clipped next row must never move onto the previous visible row.
            if(cx<0||cx>=390||cy<clipTop||cy>=drawingClipBottom)return;
            float target=48*getResources().getDisplayMetrics().density/Math.max(.01f,scale);
            float rw=Math.max(w,target),rh=Math.max(h,target);
            r.set(cx-rw/2,cy-rh/2,cx+rw/2,cy+rh/2);
            r.intersect(0,clipTop,390,drawingClipBottom);
        }
        hits.add(new Hit(r,name,action));
    }
    private void gateHit(float x,float y,Direction direction,String name,Runnable action){
        int before=hits.size();hit(x-25,y-25,50,50,name,action);if(hits.size()>before)hits.get(before).gate=direction.ordinal();
    }
    private void guardianHit(float x,float y,float size,int piece,String name,Runnable action){
        int before=hits.size();hit(x,y,size,size,name,action);if(hits.size()>before)hits.get(before).guardianPiece=piece;
    }
    private void label(float x,float y,float w,float h,String name){hit(x,y,w,h,name,null);}
    private void objectAction(Canvas c,String label,float x,float y,float w,float h,int color,Runnable action){
        String caption=actionCaption(label);scenic.objectAction(c,new RectF(x,y,x+w,y+Math.max(48,h)),caption,color,pressed!=null&&pressed.name.equals(label),actionKind(label));
        hit(x,y,w,Math.max(48,h),label,action);
    }
    private void sceneAction(Canvas c,String label,float x,float y,float w,Runnable action){
        objectAction(c,label,x,y,w,48,0xff7876bb,action);
    }
    private String actionCaption(String label){return label.replace("  →","").replace("  ›","").replace("‹  ","").replace("‹ ","").replace("↶  ","").replace("↻  ","");}
    private ScenicUi.Kind actionKind(String label){
        String clean=actionCaption(label);
        if(label.equals("‹")||clean.equals(t("back"))||clean.equals(t("close"))||clean.equals(d("back_banner")))return ScenicUi.Kind.RETURN;
        if(label.equals("›")||clean.equals(t("next"))||clean.equals(t("play"))||clean.equals(t("resume"))||clean.equals(t("continue")))return ScenicUi.Kind.PORTAL;
        if(clean.equals(t("cancel"))||clean.equals(n("cancel_preview"))||clean.equals("×"))return ScenicUi.Kind.CANCEL;
        if(clean.equals(t("retry"))||clean.equals(t("restart"))||clean.equals(t("restart_free")))return ScenicUi.Kind.RETRY;
        if(clean.equals(returnLabel())||clean.equals(t("undo_free")))return ScenicUi.Kind.UNDO;
        if(clean.equals(h("decorate"))||clean.equals(h("furniture")))return ScenicUi.Kind.BLUEPRINT;
        if(clean.equals(d("equip"))||clean.equals(e("action_equip"))||clean.equals(r("wardrobe")))return ScenicUi.Kind.MIRROR;
        if(clean.equals(d("odds"))||clean.equals(t("how_to_play"))||clean.equals(t("got_it")))return ScenicUi.Kind.BOOK;
        if(clean.equals(t("claim"))||clean.equals(a("claim_reward"))||clean.equals(a("claim_daily")))return ScenicUi.Kind.CHEST;
        if(clean.equals(d("edit_nickname")))return ScenicUi.Kind.FEATHER;
        if(clean.equals(d("badges")))return ScenicUi.Kind.MEDAL;
        if(clean.equals(t("exit"))||clean.equals(r("back_adventure"))||clean.equals(d("remove_badge")))return ScenicUi.Kind.RETURN;
        if(clean.equals(h("rotate")))return ScenicUi.Kind.ROTATE;
        if(clean.equals(h("place"))||clean.equals(h("done"))||clean.equals(t("yes")))return ScenicUi.Kind.CONFIRM;
        if(clean.equals(h("remove"))||clean.equals(t("clear_journal")))return ScenicUi.Kind.SATCHEL;
        if(clean.equals(t("account"))||clean.equals(t("export_journal"))||clean.equals(t("share_challenge")))return ScenicUi.Kind.MAIL;
        if(clean.equals(a("objectives"))||clean.equals(r("rewards"))||clean.equals(n("tutorial_claim")))return ScenicUi.Kind.CHEST;
        if(clean.equals(d("last_reveal"))||clean.equals(v("open_capsule")))return ScenicUi.Kind.CAPSULE;
        if(clean.equals(r("companions"))||clean.equals(d("my_companions")))return ScenicUi.Kind.PROFILE;
        if(clean.equals(a("visual_styles"))||clean.equals(d("look_book")))return ScenicUi.Kind.MIRROR;
        if(clean.equals(t("credits"))||clean.equals(t("local_journal"))||clean.equals(a("view_source"))||clean.equals(r("relay_rule")))return ScenicUi.Kind.BOOK;
        if(clean.equals(r("powers")))return ScenicUi.Kind.SATCHEL;
        if(clean.equals(h("play"))||clean.equals(n("start_adventure"))||clean.equals(n("continue_lesson")))return ScenicUi.Kind.PORTAL;
        if(clean.equals(a("play_journey"))||clean.equals(a("back_journey")))return ScenicUi.Kind.COMPASS;
        if(clean.equals(a("play_daily"))||clean.equals(a("play_weekly")))return ScenicUi.Kind.LANTERN;
        if(clean.equals(h("cuddle")))return ScenicUi.Kind.HEART;
        return ScenicUi.kindFor(clean);
    }



    private void sceneShelf(Canvas c,RectF bounds,int color,boolean raised){scenic.shelf(c,bounds,color);}
    private void scenePaper(Canvas c,RectF bounds,int color,boolean raised){scenic.windowModal(c,bounds,color);}
    private void sceneWindow(Canvas c,RectF bounds,int color){scenic.windowModal(c,bounds,color);}
    private void sceneStage(Canvas c,RectF bounds,int color){sceneAura(c,bounds,color,frameTime,reduceMotion);}
    private void sceneAura(Canvas c,RectF bounds,int color,long time,boolean still){
        float x=bounds.centerX(),y=bounds.centerY();p.setColor(WHITE);p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(x,y,Math.max(1,bounds.width()*.63f),new int[]{alpha(color,65),alpha(color,20),alpha(color,0)},null,Shader.TileMode.CLAMP));
        c.drawOval(bounds.left-20,bounds.top-5,bounds.right+20,bounds.bottom+5,p);p.setShader(null);
    }
    private boolean drawScenery(Canvas c,String place){
        Bitmap image=scenery.get(place);
        if(!scenery.containsKey(place)){
            try(java.io.InputStream input=getContext().getAssets().open("art/v117/world-"+place+".png")){
                BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;options.inSampleSize=2;image=BitmapFactory.decodeStream(input,null,options);
            }catch(java.io.IOException failure){image=null;}scenery.put(place,image);
        }
        if(image==null)return false;
        float scale=Math.max(390f/image.getWidth(),viewportH/image.getHeight()),w=image.getWidth()*scale,h=image.getHeight()*scale;
        sceneBitmapPaint.setAlpha(255);c.drawBitmap(image,null,new RectF((390-w)/2,(viewportH-h)/2,(390+w)/2,(viewportH+h)/2),sceneBitmapPaint);return true;
    }
    private void sceneDestination(Canvas c,ScenicUi.Kind kind,String name,float x,float y,float size,int accent,Runnable action){
        RectF bounds=new RectF(x-size/2,y-size*.52f,x+size/2,y+size*.48f);
        scenic.object(c,bounds,accent,pressed!=null&&pressed.name.equals(name),kind);
        sceneCaption(c,name,x,y+size*.57f,Math.max(76,size+30),15);hit(bounds.left-6,bounds.top-5,bounds.width()+12,bounds.height()+29,name,action);
    }
    private SceneRootLayout rootLayout(){
        float minimumText=minimumTextSize(),minimumTouch=48*getResources().getDisplayMetrics().density/Math.max(.01f,scale);
        if(sceneRootLayout==null||sceneRootLayout.height!=viewportH||sceneRootLayout.minimumText!=minimumText||sceneRootLayout.minimumTouch!=minimumTouch)sceneRootLayout=new SceneRootLayout(viewportH,minimumText,minimumTouch);
        return sceneRootLayout;
    }
    private void sceneDestination(Canvas c,ScenicUi.Kind kind,String name,SceneRootLayout.Destination place,int accent,Runnable action){
        sceneDestination(c,kind,name,place.x,place.y,place.size,accent,action);
    }
    private RectF sceneRect(SceneRootLayout.Rect rect){return new RectF(rect.left,rect.top,rect.right,rect.bottom);}
    private void sceneHit(SceneRootLayout.Rect rect,String name,Runnable action){hit(rect.left,rect.top,rect.width(),rect.height(),name,action);}
    private void sceneCaption(Canvas c,String name,float x,float baseline,float width,float size){
        p.setTypeface(bold);p.setTextSize(Math.max(minimumTextSize(),size));p.setColor(0xff45315e);p.setShadowLayer(5,0,1,0xfffaf5ff);
        String value=android.text.TextUtils.ellipsize(name,p,width,android.text.TextUtils.TruncateAt.END).toString();c.drawText(value,x-p.measureText(value)/2,baseline,p);p.clearShadowLayer();
    }
    private void sceneHeading(Canvas c,String title,String subtitle){
        p.setColor(WHITE);p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,0,115,new int[]{0xfffaf6ff,0xeefaf6ff,0x00faf6ff},new float[]{0,.64f,1},Shader.TileMode.CLAMP));c.drawRect(0,0,390,116,p);p.setShader(null);
        fit(c,title,23,46,29,menuHudInset>0?342:258,TEXT,true,false);if(subtitle!=null)fit(c,subtitle,24,70,12,326,TEXT,false,false);if(menuHudInset==0)wallet(c,282,15);
    }
    private void sceneSiblings(Canvas c){
        String[] destinations=rootPlaces;
        String[] names={m20("home"),v19("squad"),r("collection"),m20("gifts"),m20("shop")};
        String[] glyphs={"⌂","◉","◇","♡","⌑"};float y=viewportH-77;
        round(c,10,y,370,68,27,0xfffbfaff);
        for(int i=0;i<5;i++){final String destination=destinations[i];float x=i*78f;boolean chosen=destination.equals(screen);
            if(chosen)round(c,x+5,y+6,68,55,21,0xffe3d8fb);
            if(i==4)icon(c,"shop",x+39,y+22,23,chosen?0xff7252b7:0xff747184);else if(i==3)drawGiftIcon(c,x+39,y+24,24,chosen?0xffba99d7:0xffcbbbd9,false);else center(c,glyphs[i],x+39,y+30,23,chosen?0xff7252b7:0xff747184,true);
            fit(c,names[i],x+39,y+52,11,70,chosen?0xff513780:0xff666173,chosen,true);
            motionHit(menuRect(Menu120Layout.navigation(i,viewportH,battleMinimumTouch())),names[i],"root_nav_"+destination,()->{if(destination.equals("squad"))openSquad();else if(destination.equals("rewards")){rewardTab=0;goRoot(destination);}else goRoot(destination);});
        }
    }
    private void drawFixedNavigation(Canvas c){
        float top=viewportH-84+menuHudInset;
        for(Iterator<Hit> it=hits.iterator();it.hasNext();){Hit h=it.next();if(h.r.top>=top)it.remove();else if(h.r.bottom>top)h.r.bottom=top;}
        c.save();c.translate(0,contentScroll);float oldScroll=drawingScroll,oldClip=drawingClipBottom;drawingScroll=0;drawingClipBottom=viewportH+menuHudInset;sceneSiblings(c);drawingScroll=oldScroll;drawingClipBottom=oldClip;c.restore();
    }
    private void drawNamedWallet(Canvas c){
        for(int i=0;i<2;i++){float left=157+i*85;int color=i==0?0xffffe6a8:0xffe6d9fb;round(c,left,12,78,55,17,color);
            String name=i==0?"LumaCoins":"LumaGold",amount=i==0?String.valueOf(store.coins()):displayedGold==null?"—":String.valueOf(displayedGold);
            fit(c,name,left+39,32,11,70,TEXT,true,true);fit(c,amount,left+39,55,17,68,TEXT,true,true);
            final int category=i==0?0:2;motionHit(new RectF(left,12,left+78,67),name+": "+amount,"wallet_"+name.toLowerCase(Locale.ROOT),()->{shopCategory=category;go("shop");});}
    }
    private boolean menuHudVisible(){return !Arrays.asList("play","guardian","tutorial","firstlight").contains(screen);}
    /** Fixed above the scroll container; all values and touch bounds use the same transform. */
    private void drawMenuWalletHud(Canvas c){
        float inset=menuHudInset,oldClip=drawingClipBottom,oldScroll=drawingScroll;
        menuHudInset=0;drawingScroll=0;drawingClipBottom=viewportH+inset;
        round(c,0,0,390,inset,0,0xfffbfaff);
        int actual=store.coins();
        if(menuCoinTarget<0){menuCoinFrom=menuCoinTarget=actual;menuCoinAt=frameTime;}
        else if(actual!=menuCoinTarget){menuCoinFrom=menuCoinTarget;menuCoinTarget=actual;menuCoinAt=frameTime;}
        float progress=reduceMotion?1:Math.min(1,Math.max(0,(frameTime-menuCoinAt)/360f));
        int shown=(int)coinMotion121.sample(actual,frameTime,reduceMotion);
        String shownGold=displayedGold==null?"—":String.valueOf(goldMotion121.sample(displayedGold,frameTime,reduceMotion));if(displayedGold==null)goldMotion121.unavailable();
        String[] names={"LumaCoins","LumaGold",m20("energy")};
        String[] values={String.valueOf(shown),shownGold,sessionEnergyCount()+" / "+sessionEnergy.maximum()};
        int[] colors={0xffffedb8,0xffefe1ff,0xffffe4ec};
        for(int i=0;i<3;i++){
            Menu120Layout.Rect r=Menu120Layout.wallet(i,battleMinimumTouch());
            round(c,r.left,r.top,r.width(),r.height(),21,colors[i]);
            float bounce=reduceMotion?0:(float)Math.sin(frameTime*.002+i)*1.25f;
            if(i==0)shopArt.coin(c,r.left+18,r.top+38+bounce,10,frameTime,reduceMotion);
            else if(i==1)shopArt.gold(c,r.left+18,r.top+38+bounce,11,frameTime,reduceMotion);
            else center(c,"♡",r.left+18,r.top+43+bounce,23,0xffb85478,true);
            fit(c,names[i],r.centerX(),r.top+20,11,r.width()-12,TEXT,true,true);
            fit(c,values[i],r.left+35,r.top+45,19,r.width()-44,TEXT,true,false);
            final int wallet=i;String status=i==0?m20("earned"):i==1?(displayedGold==null?m20("wallet_unknown"):m20("gold")):sessionEnergyLabel();
            motionHit(menuRect(r),names[i]+": "+(i==0?actual:values[i])+". "+status,"menu_wallet_"+i,()->{if(wallet==2)openSessionEnergy();else{shopCategory=wallet==0?0:2;goRoot("shop");}});
        }
        if(!reduceMotion){drawWalletGain121(c,coinMotion121,0);if(displayedGold!=null)drawWalletGain121(c,goldMotion121,1);}
        menuHudInset=inset;drawingClipBottom=oldClip;drawingScroll=oldScroll;
    }
    private RectF menuRect(Menu120Layout.Rect r){return new RectF(r.left,r.top,r.right,r.bottom);}
    /** Read-only puzzle wallet strip; the play owner reserves its 42-unit band. */
    private void drawPlayWalletHud120(Canvas c){drawPlayWalletHud120(c,store.coins());}
    private void drawPlayWalletHud120(Canvas c,int displayedCoins){
        round(c,12,3,366,37,16,0xfffbf7ff);
        String gold=displayedGold==null?"—":String.valueOf(displayedGold);
        String[] names={"LumaCoins","LumaGold",m20("energy")},values={String.valueOf(displayedCoins),gold,"♡ "+sessionEnergyCount()+"/"+sessionEnergy.maximum()};
        for(int i=0;i<3;i++){fit(c,names[i],73+i*122,17,11,112,PremiumUi.MUTED,false,true);fit(c,values[i],73+i*122,35,16,112,TEXT,true,true);}
        label(12,3,366,37,"LumaCoins: "+store.coins()+". LumaGold: "+gold+(displayedGold==null?". "+m20("wallet_unknown"):"")+". "+sessionEnergyLabel());
    }
    private void showMenuGift(String title,String detail,String power){
        menuGiftTitle=title;menuGiftDetail=detail;menuGiftPower=power==null?"":power;menuGiftAt=SystemClock.uptimeMillis();menuGiftClosingAt=0;
        hubRefreshAt=0;hits.clear();pressed=null;actionGeneration++;sfx(AudioEngine.Sound.REVEAL);announceForAccessibility(title+". "+detail);invalidate();
    }
    private void closeMenuGift(){
        if(reduceMotion){menuGiftAt=menuGiftClosingAt=0;hits.clear();}
        else if(menuGiftClosingAt==0)menuGiftClosingAt=SystemClock.uptimeMillis();
        invalidate();
    }
    private void drawGiftIcon(Canvas c,float x,float y,float size,int color,boolean opened){
        float bob=reduceMotion?0:(float)Math.sin(frameTime*.003)*2;
        c.save();c.translate(x,y+bob);float s=size/60f;c.scale(s,s);
        round(c,-28,-13,56,40,13,color);round(c,-31,opened?-27:-19,62,14,7,blend(color,0xffffffff,.2f));
        round(c,-5,-19,10,46,4,0xfffcf5ff);p.setColor(0xfffbf5ff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);
        c.drawOval(-21,-36,1,-17,p);c.drawOval(-1,-36,21,-17,p);p.setStyle(Paint.Style.FILL);
        if(opened){star(c,-35,-36,6,GOLD);star(c,34,-42,5,0xff9ed9c5);}
        c.restore();
    }
    private void drawMenuGiftReveal(Canvas c){
        long elapsed=frameTime-menuGiftAt,closing=menuGiftClosingAt==0?-1:frameTime-menuGiftClosingAt;float fade=Menu120Layout.revealAlpha(elapsed,closing,reduceMotion);
        if(Menu120Layout.revealFinished(closing,reduceMotion)){menuGiftAt=menuGiftClosingAt=0;return;}
        hits.clear();c.save();c.translate(0,menuHudInset);
        int layer=c.saveLayerAlpha(0,0,390,viewportH,Math.round(255*fade));
        round(c,0,0,390,viewportH,0,0xf6fcf8ff);Menu120Layout.Reveal reveal=new Menu120Layout.Reveal(viewportH);float cy=reveal.centerY;
        p.setColor(0xfff1e6ff);c.drawCircle(195,cy,reveal.haloRadius,p);
        drawGiftIcon(c,195,cy-8,reveal.illustrationSize,0xffd8b8f1,true);
        if(!menuGiftPower.isEmpty())shopArt.power(c,menuGiftPower,195,cy-20,reveal.compact?17:25,frameTime,reduceMotion);
        fit(c,m20("gift_for_you"),195,reveal.titleY,reveal.compact?19:24,340,TEXT,true,true);
        fit(c,menuGiftTitle,195,reveal.giftY,reveal.compact?16:19,330,TEXT,true,true);
        fit(c,menuGiftDetail,195,reveal.detailY,reveal.compact?18:22,324,0xff80612e,true,true);
        fit(c,m20("tap_continue"),195,reveal.continueY,13,330,PremiumUi.MUTED,false,true);
        c.restoreToCount(layer);c.restore();
        motionHit(new RectF(0,0,390,viewportH),m20("tap_continue"),"gift_reveal_continue",this::closeMenuGift);
    }
    private void confirmInScene(String title,String message,Runnable action){sceneConfirmTitle=title;sceneConfirmText=message;sceneConfirmAction=action;pressed=null;hits.clear();invalidate();}
    private void drawSceneConfirmation(Canvas c){
        scrim(c);float y=Math.max(18,(viewportH-330)/2);scenic.windowModal(c,new RectF(20,y,370,y+330),0xfff8f2ff);
        fit(c,sceneConfirmTitle,195,y+53,22,312,TEXT,true,true);wrap(c,sceneConfirmText,195,y+95,300,15,TEXT,true,23);
        sceneDestination(c,ScenicUi.Kind.CONFIRM,t("yes"),122,y+240,76,0xff79b7a8,()->{Runnable action=sceneConfirmAction;sceneConfirmAction=null;if(action!=null)action.run();});
        sceneDestination(c,ScenicUi.Kind.CANCEL,t("cancel"),270,y+240,76,0xffbc94bc,()->{sceneConfirmAction=null;invalidate();});
    }
    private void header(Canvas c,String title,String subtitle){
        fit(c,title,24,54,30,menuHudInset>0?342:242,TEXT,true,false);if(subtitle!=null)fit(c,subtitle,25,80,12,330,skin.muted,false,false);if(menuHudInset==0)wallet(c,282,15);
    }
    private void wallet(Canvas c,float x,float y){
        hit(x-5,y-6,89,48,t("coins")+": "+store.coins(),()->{if(!screen.equals("shop"))go("shop");});
        scenic.object(c,new RectF(x-3,y-1,x+30,y+34),GOLD,false,ScenicUi.Kind.SATCHEL);fit(c,""+store.coins(),x+31,y+23,14,55,TEXT,true,false);
    }
    private void coin(Canvas c,float x,float y,float r){p.setColor(GOLD);c.drawCircle(x,y,r,p);p.setColor(0xffdfac61);p.setStrokeWidth(1.5f);p.setStyle(Paint.Style.STROKE);c.drawCircle(x,y,r*.7f,p);p.setStyle(Paint.Style.FILL);text(c,"•",x-r*.25f,y+r*.38f,r,GOLD,true);}
    private void icon(Canvas c,String name,float x,float y,float size,int color){
        p.setColor(color);p.setStrokeWidth(2.2f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);float s=size/20;
        c.save();c.translate(x,y);c.scale(s,s);Path q=new Path();
        switch(name){
            case "profile":c.drawCircle(0,-5,4,p);q.moveTo(-8,9);q.cubicTo(-8,0,8,0,8,9);break;
            case "home":q.moveTo(-9,-1);q.lineTo(0,-9);q.lineTo(9,-1);q.moveTo(-6,-2);q.lineTo(-6,8);q.lineTo(6,8);q.lineTo(6,-2);break;
            case "journey":q.moveTo(-7,8);q.cubicTo(12,8,-12,-8,7,-8);c.drawCircle(-7,8,2,p);c.drawCircle(7,-8,2,p);break;
            case "events":q.moveTo(1,-10);q.lineTo(-7,2);q.lineTo(0,2);q.lineTo(-1,10);q.lineTo(8,-2);q.lineTo(1,-2);q.close();break;
            case "collection":q.moveTo(-9,7);q.lineTo(-9,-5);q.lineTo(-3,0);q.lineTo(0,-8);q.lineTo(4,0);q.lineTo(9,-5);q.lineTo(9,7);q.close();break;
            case "shop":c.drawRoundRect(-8,-3,8,9,2,2,p);q.moveTo(-4,-3);q.lineTo(-4,-7);q.quadTo(0,-12,4,-7);q.lineTo(4,-3);break;
            case "settings":c.drawCircle(0,0,7,p);c.drawCircle(0,0,2,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;c.drawLine((float)Math.cos(a)*7,(float)Math.sin(a)*7,(float)Math.cos(a)*10,(float)Math.sin(a)*10,p);}break;
            case "back":q.moveTo(4,-7);q.lineTo(-4,0);q.lineTo(4,7);break;
            case "next":q.moveTo(-4,-7);q.lineTo(4,0);q.lineTo(-4,7);break;
            case "pause":c.drawLine(-4,-7,-4,7,p);c.drawLine(4,-7,4,7,p);break;
            case "undo":q.moveTo(-8,0);q.cubicTo(-3,-10,10,-8,8,2);q.cubicTo(7,7,3,9,-2,7);q.moveTo(-8,-6);q.lineTo(-8,0);q.lineTo(-2,0);break;
            case "retry":q.moveTo(7,-3);q.cubicTo(3,-11,-9,-7,-8,1);q.cubicTo(-7,9,4,11,8,3);q.moveTo(7,-9);q.lineTo(7,-3);q.lineTo(1,-3);break;
            case "hint":c.drawCircle(0,-3,6,p);q.moveTo(-3,4);q.lineTo(-3,7);q.lineTo(3,7);q.lineTo(3,4);q.moveTo(-2,10);q.lineTo(2,10);break;
            case "vision":q.moveTo(-10,0);q.quadTo(0,-12,10,0);q.quadTo(0,12,-10,0);c.drawCircle(0,0,3,p);break;
            case "flow":for(int i=-1;i<=1;i++){q.moveTo(i*6-2,-6);q.lineTo(i*6+3,0);q.lineTo(i*6-2,6);}break;
            case "shield":q.moveTo(0,-10);q.lineTo(8,-6);q.lineTo(6,4);q.quadTo(3,8,0,10);q.quadTo(-3,8,-6,4);q.lineTo(-8,-6);q.close();break;
            case "focus":c.drawCircle(0,0,6,p);c.drawCircle(0,0,2,p);c.drawLine(-10,0,-7,0,p);c.drawLine(7,0,10,0,p);c.drawLine(0,-10,0,-7,p);c.drawLine(0,7,0,10,p);break;
            case "trail":q.moveTo(-8,7);q.lineTo(-2,0);q.lineTo(2,3);q.lineTo(8,-7);q.moveTo(1,-7);q.lineTo(8,-7);q.lineTo(8,0);break;
            case "lock":c.drawRoundRect(-6,-1,6,9,2,2,p);q.moveTo(-4,-1);q.lineTo(-4,-5);q.cubicTo(-4,-11,4,-11,4,-5);q.lineTo(4,-1);break;
            case "check":q.moveTo(-7,0);q.lineTo(-2,5);q.lineTo(8,-6);break;
            case "sound":q.moveTo(-8,-3);q.lineTo(-4,-3);q.lineTo(1,-8);q.lineTo(1,8);q.lineTo(-4,3);q.lineTo(-8,3);q.close();q.moveTo(5,-5);q.quadTo(11,0,5,5);break;
            case "music":q.moveTo(-3,5);q.lineTo(-3,-7);q.lineTo(7,-9);q.lineTo(7,3);c.drawOval(-8,3,-1,8,p);c.drawOval(2,1,9,6,p);break;
            case "heart":q.moveTo(0,8);q.cubicTo(-18,-3,-7,-13,0,-5);q.cubicTo(7,-13,18,-3,0,8);break;
            case "help":c.drawCircle(0,0,10,p);q.moveTo(-3,-4);q.cubicTo(-1,-8,7,-5,2,0);q.lineTo(1,2);c.drawPoint(1,6,p);break;
            default:c.drawCircle(0,0,7,p);
        }c.drawPath(q,p);c.restore();p.setStyle(Paint.Style.FILL);
    }
    private void star(Canvas c,float x,float y,float r,int color){Path q=new Path();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float rr=i%2==0?r:r*.47f;float xx=x+(float)Math.cos(a)*rr,yy=y+(float)Math.sin(a)*rr;if(i==0)q.moveTo(xx,yy);else q.lineTo(xx,yy);}q.close();p.setColor(color);c.drawPath(q,p);}
    private void mascot(Canvas c,float x,float y,float r,Catalog.CharacterItem who,boolean happy){
        c.save();c.translate(x,y);float bob=reduceMotion?0:(float)Math.sin(frameTime*.0018)*r*.035f;c.translate(0,bob);
        p.setAlpha(255);p.setShader(new RadialGradient(0,r*.9f,r*.9f,new int[]{alpha(who.color,60),0},null,Shader.TileMode.CLAMP));c.drawOval(-r*1.3f,r*.7f,r*1.3f,r*1.25f,p);p.setShader(null);
        if(who.shape>=6)drawCompanionBody(c,r,who);else{
        if(who.shape==1){Path ears=new Path();ears.moveTo(-r*.8f,-r*.3f);ears.lineTo(-r*.75f,-r*1.13f);ears.lineTo(-r*.15f,-r*.6f);ears.moveTo(r*.8f,-r*.3f);ears.lineTo(r*.75f,-r*1.13f);ears.lineTo(r*.15f,-r*.6f);p.setColor(who.color);c.drawPath(ears,p);}
        if(who.shape==3){round(c,-r*.7f,-r*1.65f,r*.44f,r*1.25f,r*.23f,who.color);round(c,r*.25f,-r*1.65f,r*.44f,r*1.25f,r*.23f,who.color);}
        if(who.shape==4){Path tail=new Path();tail.moveTo(-r*.5f,r*.3f);tail.lineTo(-r*1.6f,-r*.75f);tail.lineTo(-r*.2f,-r*.65f);p.setColor(alpha(who.color,110));c.drawPath(tail,p);}
        p.setAlpha(255);p.setShader(new LinearGradient(-r,-r,r,r,new int[]{blend(who.color,WHITE,.28f),who.color,blend(who.color,INK,.14f)},null,Shader.TileMode.CLAMP));
        if(who.shape==0){Path blob=new Path();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float rr=i%2==0?r*1.12f:r*.81f;float xx=(float)Math.cos(a)*rr,yy=(float)Math.sin(a)*rr;if(i==0)blob.moveTo(xx,yy);else blob.lineTo(xx,yy);}blob.close();c.drawPath(blob,p);c.drawCircle(0,0,r*.83f,p);}
        else if(who.shape==2)c.drawRoundRect(-r,-r*.82f,r,r*.85f,r*.4f,r*.4f,p);
        else c.drawOval(-r,-r,r,r,p);p.setShader(null);
        if(who.shape==2){p.setColor(skin.card);c.drawRoundRect(-r*.75f,-r*.42f,r*.75f,r*.3f,r*.25f,r*.25f,p);p.setColor(who.color);c.drawCircle(0,-r*1.05f,r*.12f,p);}
        if(who.shape==5){for(int i=0;i<3;i++){p.setColor(who.color);c.drawCircle((i-1)*r*.55f,r*.78f,r*.27f,p);}}
        }
        if(who.shape==6)c.translate(-r*.28f,0);
        p.setColor(who.shape==2||who.shape==22?WHITE:INK);float ey=-r*.12f;boolean blink=!reduceMotion&&(frameTime/120)%43==0;
        if(happy||blink){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(r*.065f);c.drawArc(-r*.48f,ey-r*.12f,-r*.18f,ey+r*.16f,190,160,false,p);c.drawArc(r*.18f,ey-r*.12f,r*.48f,ey+r*.16f,190,160,false,p);p.setStyle(Paint.Style.FILL);}
        else{c.drawOval(-r*.43f,ey-r*.19f,-r*.24f,ey+r*.12f,p);c.drawOval(r*.24f,ey-r*.19f,r*.43f,ey+r*.12f,p);p.setColor(WHITE);c.drawCircle(-r*.31f,ey-r*.1f,r*.04f,p);c.drawCircle(r*.36f,ey-r*.1f,r*.04f,p);}
        p.setColor(alpha(0xffee6f92,100));c.drawOval(-r*.65f,r*.17f,-r*.37f,r*.3f,p);c.drawOval(r*.37f,r*.17f,r*.65f,r*.3f,p);
        p.setColor(INK);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(r*.045f);c.drawArc(-r*.17f,r*.15f,r*.17f,r*.42f,5,170,false,p);p.setStyle(Paint.Style.FILL);
        p.setColor(alpha(WHITE,120));c.drawOval(-r*.55f,-r*.75f,-r*.03f,-r*.52f,p);if(meta.badgeEquipped()&&who.id.equals(character.id))star(c,r*.75f,r*.67f,r*.25f,GOLD);if(who.id.equals(character.id)&&loadout!=null)drawLoadout(c,r,who.shape);c.restore();
    }
    /** Original silhouettes drawn in unit coordinates; no downloaded or licensed character art. */
    private void drawCompanionBody(Canvas c,float r,Catalog.CharacterItem who){
        c.save();c.scale(r,r);int color=who.color,light=blend(color,WHITE,.42f),dark=blend(color,INK,.35f);
        switch(who.shape){
            case 6: { // Crescent moon: the inner curve belongs to the silhouette, not a background cutout.
                Path q=new Path();q.moveTo(.55f,-.96f);q.cubicTo(-.05f,-1.3f,-1.12f,-.67f,-1.05f,.13f);q.cubicTo(-.99f,1.06f,.25f,1.25f,.85f,.54f);q.cubicTo(.12f,.72f,.04f,-.22f,.55f,-.96f);q.close();p.setColor(color);c.drawPath(q,p);star(c,.68f,-.57f,.22f,light);break;
            }
            case 7: // Fox, pointed ears and two cream cheek patches.
                companionPolygon(c,color,-.96f,.24f,-.97f,-1.04f,-.35f,-.65f,0,-.81f,.35f,-.65f,.97f,-1.04f,.96f,.24f,0,1.02f);
                companionPolygon(c,light,-.93f,.2f,-.12f,.13f,0,.83f);companionPolygon(c,light,.93f,.2f,.12f,.13f,0,.83f);break;
            case 8: // Owl, tufted outline and eye discs.
                companionPolygon(c,color,-.84f,-.22f,-.74f,-1.02f,-.25f,-.65f,.25f,-.65f,.74f,-1.02f,.84f,-.22f);
                companionOval(c,-.94f,-.79f,.94f,1.02f,color);companionOval(c,-.79f,-.59f,.04f,.38f,light);companionOval(c,-.04f,-.59f,.79f,.38f,light);
                companionPolygon(c,GOLD,-.11f,.23f,.11f,.23f,0,.43f);break;
            case 9: // Bee, translucent wings and striped abdomen.
                companionOval(c,-1.24f,-.98f,-.25f,.01f,alpha(WHITE,175));companionOval(c,.25f,-.98f,1.24f,.01f,alpha(WHITE,175));
                companionOval(c,-.88f,-.81f,.88f,.94f,color);round(c,-.69f,.45f,1.38f,.16f,.08f,dark);round(c,-.48f,.74f,.96f,.13f,.06f,dark);
                companionLine(c,-.3f,-.74f,-.42f,-1.1f,dark,.07f);companionLine(c,.3f,-.74f,.42f,-1.1f,dark,.07f);break;
            case 10: // Turtle, shell flippers and a scalloped ridge.
                for(int i=0;i<4;i++){float x=i%2==0?-1.01f:.59f,y=i<2?-.52f:.38f;companionOval(c,x,y,x+.42f,y+.61f,dark);}
                companionOval(c,-.76f,-1.07f,.76f,.8f,color);companionOval(c,-.68f,-.81f,.68f,.91f,light);
                companionLine(c,-.5f,.66f,0,.43f,dark,.055f);companionLine(c,0,.43f,.5f,.66f,dark,.055f);break;
            case 11: // Jellyfish, dome with five rounded tentacles.
                for(int i=0;i<5;i++)round(c,-.87f+i*.34f,.37f,.24f,.85f+(i%2)*.15f,.12f,i%2==0?color:light);
                companionOval(c,-1,-.98f,1,.75f,color);round(c,-1,.27f,2,.42f,.2f,light);break;
            case 12: // Moth, four broad wing lobes and antennae.
                companionOval(c,-1.35f,-1.04f,-.09f,.35f,color);companionOval(c,.09f,-1.04f,1.35f,.35f,color);
                companionOval(c,-1.06f,-.01f,-.09f,.94f,light);companionOval(c,.09f,-.01f,1.06f,.94f,light);
                companionOval(c,-.63f,-.76f,.63f,.86f,color);companionLine(c,-.2f,-.76f,-.53f,-1.17f,light,.07f);companionLine(c,.2f,-.76f,.53f,-1.17f,light,.07f);break;
            case 13: // Cloud: five rounded lobes, flat soft lower edge.
                companionOval(c,-1.16f,-.4f,-.1f,.71f,color);companionOval(c,-.77f,-.99f,.48f,.55f,light);companionOval(c,.03f,-.69f,1.07f,.64f,color);
                round(c,-1.07f,-.15f,2.18f,.93f,.42f,color);break;
            case 14: // Sun, twelve rays and a warm center.
                for(int i=0;i<12;i++){double a=i*Math.PI/6;float x=(float)Math.cos(a),y=(float)Math.sin(a);companionPolygon(c,color,x*1.29f,y*1.29f,x*.88f-y*.16f,y*.88f+x*.16f,x*.88f+y*.16f,y*.88f-x*.16f);}
                companionOval(c,-.88f,-.88f,.88f,.88f,light);break;
            case 15: // Snail, lower foot, shell, and rounded antenna tips.
                round(c,-1.04f,.53f,2.24f,.42f,.2f,dark);companionOval(c,.4f,-.05f,1.24f,.88f,color);
                companionLine(c,.72f,.12f,.65f,-.47f,color,.09f);companionLine(c,1.04f,.12f,1.17f,-.42f,color,.09f);
                companionOval(c,-.98f,-.98f,.88f,.83f,color);p.setColor(alpha(light,180));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.075f);c.drawArc(-.67f,-.74f,.61f,.53f,40,290,false,p);p.setStyle(Paint.Style.FILL);break;
            case 16: // Axolotl, three external gills on each side.
                for(int i=0;i<3;i++){float yy=-.61f+i*.43f;companionLine(c,-.79f,yy,-1.29f,yy+(i-1)*.19f,dark,.15f);companionLine(c,.79f,yy,1.29f,yy+(i-1)*.19f,dark,.15f);}
                companionOval(c,-1,-.85f,1,.94f,color);break;
            case 17: // Cactus with raised arms, blossom, and discreet spines.
                round(c,-.65f,-1.03f,1.3f,2,.56f,color);round(c,-1.1f,-.39f,.63f,.98f,.26f,dark);round(c,.47f,-.72f,.63f,1.1f,.26f,dark);
                companionLine(c,-.34f,.54f,-.34f,.74f,light,.045f);companionLine(c,.31f,.57f,.31f,.8f,light,.045f);star(c,.39f,-.99f,.23f,PEACH);break;
            case 18: { // Hedgehog, explicit spike outline and a soft inner face.
                Path q=new Path();for(int i=0;i<28;i++){double a=-Math.PI/2+i*Math.PI/14;float rr=i%2==0?1.14f:.91f;float xx=(float)Math.cos(a)*rr,yy=(float)Math.sin(a)*rr;if(i==0)q.moveTo(xx,yy);else q.lineTo(xx,yy);}q.close();p.setColor(dark);c.drawPath(q,p);companionOval(c,-.84f,-.76f,.84f,.97f,color);break;
            }
            case 19: // Penguin, flippers, cream face, and small feet.
                companionOval(c,-1.05f,-.08f,-.5f,.83f,dark);companionOval(c,.5f,-.08f,1.05f,.83f,dark);companionOval(c,-.88f,-1,.88f,.99f,color);
                companionOval(c,-.69f,-.72f,.69f,.86f,blend(WHITE,color,.13f));round(c,-.69f,.86f,.5f,.19f,.09f,GOLD);round(c,.19f,.86f,.5f,.19f,.09f,GOLD);break;
            case 20: // Ringed planet: back ring, round body, foreground arc.
                p.setColor(light);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.2f);c.save();c.rotate(-23);c.drawOval(-1.35f,-.35f,1.35f,.35f,p);c.restore();p.setStyle(Paint.Style.FILL);
                companionOval(c,-.87f,-.87f,.87f,.87f,color);p.setColor(light);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.18f);c.save();c.rotate(-23);c.drawArc(-1.35f,-.35f,1.35f,.35f,0,180,false,p);c.restore();p.setStyle(Paint.Style.FILL);break;
            case 21: // Dragon, wings, horns, and a rounded snout.
                companionPolygon(c,dark,-.65f,-.18f,-1.35f,-.65f,-1.1f,.49f,-.51f,.68f);companionPolygon(c,dark,.65f,-.18f,1.35f,-.65f,1.1f,.49f,.51f,.68f);
                companionPolygon(c,GOLD,-.63f,-.6f,-.62f,-1.17f,-.18f,-.79f);companionPolygon(c,GOLD,.63f,-.6f,.62f,-1.17f,.18f,-.79f);
                companionOval(c,-.9f,-.94f,.9f,.95f,color);companionOval(c,-.5f,.3f,.5f,.86f,light);break;
            case 22: // Panda, rounded ears and dark eye patches.
                companionOval(c,-1.02f,-1.09f,-.26f,-.36f,dark);companionOval(c,.26f,-1.09f,1.02f,-.36f,dark);companionOval(c,-.98f,-.91f,.98f,1,color);
                companionOval(c,-.65f,-.48f,-.12f,.31f,dark);companionOval(c,.12f,-.48f,.65f,.31f,dark);break;
            case 23: // Squid, tapered head and eight curling arms.
                for(int i=0;i<8;i++)round(c,-.92f+i*.23f,.44f,.17f,.63f+(i%3)*.13f,.085f,i%2==0?color:light);
                companionPolygon(c,color,0,-1.16f,-.95f,-.16f,-.91f,.62f,.91f,.62f,.95f,-.16f);companionOval(c,-.91f,-.49f,.91f,.7f,color);break;
            default:companionOval(c,-1,-1,1,1,color);
        }
        c.restore();p.setStyle(Paint.Style.FILL);p.setShader(null);
    }
    private void companionOval(Canvas c,float l,float t,float r,float b,int color){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawOval(l,t,r,b,p);}
    private void companionPolygon(Canvas c,int color,float... xy){Path q=new Path();q.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)q.lineTo(xy[i],xy[i+1]);q.close();p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawPath(q,p);}
    private void companionLine(Canvas c,float x,float y,float xx,float yy,int color,float w){p.setColor(color);p.setStrokeWidth(w);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,xx,yy,p);}
    private static int blend(int a,int b,float k){return Color.rgb((int)(Color.red(a)*(1-k)+Color.red(b)*k),(int)(Color.green(a)*(1-k)+Color.green(b)*k),(int)(Color.blue(a)*(1-k)+Color.blue(b)*k));}
    private void openTutorial(boolean replay){
        if(powerSaveBlocked){notice(t("commerce_save_error"));return;}
        if(tutorialSaveBlocked){go("tutorial");return;}
        try{
            tutorial=TutorialSession.restore(store.tutorialState());tutorialGiftClaimed=store.tutorialRewardClaimed();
            if(replay||tutorial.complete()&&tutorialGiftClaimed)tutorial.replay();else if(tutorial.skipped())tutorial.resume();
            persistTutorial();tutorialFeedback="";tutorialFeedbackUntil=0;tutorialChangedAt=SystemClock.uptimeMillis();practiceFlights.clear();go("tutorial");
        }catch(IllegalStateException failure){tutorialLoadBlocked=tutorialSaveBlocked=true;go("tutorial");}
    }
    private void retryTutorialSave(){
        try{
            if(tutorialLoadBlocked){tutorial=TutorialSession.restore(store.tutorialState());tutorialGiftClaimed=store.tutorialRewardClaimed();tutorialLoadBlocked=false;}
            if(persistTutorial()){
                tutorialGiftClaimed=store.tutorialRewardClaimed();
                if(tutorial.skipped())goRoot("home");
            }
        }catch(IllegalStateException failure){tutorialSaveBlocked=true;notice(t("save_error"));}
    }
    private boolean persistTutorial(){
        try{store.saveTutorialState(tutorial.encode());tutorialSaveBlocked=false;return true;}
        catch(IllegalStateException failure){tutorialSaveBlocked=true;notice(t("save_error"));return false;}
    }
    private void leaveTutorial(){
        if(tutorialSaveBlocked){retryTutorialSave();return;}
        if(!tutorial.complete())tutorial.skip();
        if(persistTutorial()){practiceFlights.clear();goRoot("home");}
    }
    private void practiceAction(java.util.function.Supplier<TutorialSession.Action> operation){
        if(tutorialSaveBlocked){notice(t("save_error"));return;}
        TutorialSession.Action result=operation.get();
        if(result.changed&&!persistTutorial())return;
        if(result.move!=null){
            if(result.move.success){
                sfx(result.move.tile==null||result.move.tile.isSwitch()?AudioEngine.Sound.GATE:AudioEngine.Sound.MOVE);
                if(result.move.tile!=null){Tile tile=result.move.tile;float unit=tutorialBoardWidth/tutorial.board().level.size;practiceFlights.add(new Flight(tile,SystemClock.uptimeMillis(),tutorialBoardLeft+(tile.col+.5f)*unit,tutorialBoardTop+(tile.row+.5f)*unit,directionColor(tile.direction)));}
            }else{sfx(AudioEngine.Sound.BLOCKED);haptic();}
        }else sfx(result.hintTileId>=0?AudioEngine.Sound.HINT:AudioEngine.Sound.SELECT);
        tutorialFeedback=result.feedbackKey;tutorialFeedbackUntil=SystemClock.uptimeMillis()+2400;tutorialChangedAt=SystemClock.uptimeMillis();
        if(result.accepted)announceForAccessibility(tt(result.feedbackKey));
        selected=-1;pressed=null;gesturePiece=-1;actionGeneration++;invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);
    }
    private void practicePiece(int id,Direction swipe){
        if(tutorialSaveBlocked){notice(t("save_error"));return;}
        if(tutorial.requiredAction()==TutorialSession.RequiredAction.PREVIEW_SWITCH)practiceAction(()->tutorial.previewSwitch(id));
        else practiceAction(()->tutorial.move(id,swipe));
    }
    private void practiceGate(Direction direction){
        if(tutorialSaveBlocked){notice(t("save_error"));return;}
        if(tutorial.requiredAction()==TutorialSession.RequiredAction.PREVIEW_GATE)practiceAction(()->tutorial.previewGate(direction));
        else practiceAction(()->tutorial.openGate(direction));
    }
    private void claimPracticeGift(){
        if(!persistTutorial())return;
        try{GameStore.TutorialRewardStatus state=store.claimTutorialReward();
            if(state==GameStore.TutorialRewardStatus.GRANTED){tutorialGiftClaimed=true;syncStyle();sfx(AudioEngine.Sound.COIN);notice(n("learn_reward"));}
            else if(state==GameStore.TutorialRewardStatus.ALREADY_CLAIMED){tutorialGiftClaimed=true;notice(n("tutorial_collected"));}
            else notice(state==GameStore.TutorialRewardStatus.STORAGE_FULL?tt("reward_full"):t("save_error"));
        }catch(IllegalStateException failure){tutorialSaveBlocked=true;notice(t("save_error"));}
    }
    private void drawTutorial(Canvas c){
        if(tutorialSaveBlocked){
            hits.clear();scenePaper(c,new RectF(24,155,366,485),SweetUi.CREAM,true);
            wrap(c,t("commerce_save_error"),195,218,295,18,TEXT,true,27);
            objectAction(c,t("retry"),44,387,302,53,PEACH,()->retryTutorialSave());return;
        }
        if(viewportH<480&&!tutorial.complete()){drawTutorialCompact(c);return;}
        fit(c,n("learn"),195,43,24,340,TEXT,true,true);
        if(tutorial.complete()){
            scenePaper(c,new RectF(24,103,366,668),SweetUi.CREAM,true);
            sweet.mascot(c,195,218,65,frameTime,reduceMotion,SweetUi.CELEBRATE);
            fit(c,n("tutorial_done"),195,334,25,300,TEXT,true,true);
            wrap(c,n("learn_reward"),195,377,290,19,TEXT,true,27);
            fit(c,n("learn_note"),195,448,15,293,skin.muted,false,true);
            objectAction(c,tutorialGiftClaimed?n("tutorial_collected"):n("tutorial_claim"),44,489,302,55,GOLD,()->claimPracticeGift());
            objectAction(c,n("start_adventure"),44,565,302,53,PEACH,()->previewLevel(Math.min(BalancedCatalog.LEVEL_COUNT,store.unlockedLevel()),0,0));
            sceneAction(c,n("learn_replay"),24,699,342,()->openTutorial(true));return;
        }
        fit(c,n("lesson",tutorial.lessonIndex()+1,tutorial.lessonCount()),24,76,14,240,skin.accent,true,false);
        fit(c,n("later"),326,76,13,74,TEXT,true,true);hit(282,52,90,47,n("later"),()->leaveTutorial());
        float entrance=reduceMotion?1f:Math.min(1f,(frameTime-tutorialChangedAt)/240f);float dy=(1-entrance)*(1-entrance)*10;
        c.save();c.translate(0,dy);
        scenePaper(c,new RectF(24,101,366,239),tutorial.lessonComplete()?SweetUi.MINT:SweetUi.CREAM,true);
        sweet.mascot(c,62,154,24,frameTime,reduceMotion,tutorial.lessonComplete()?SweetUi.CELEBRATE:SweetUi.HAPPY);
        fit(c,tt("title_"+tutorial.lessonKey()),105,132,18,240,TEXT,true,false);
        wrap(c,tt(tutorial.instructionKey()),105,159,235,14,TEXT,false,21);
        label(24,101,342,138,tt("title_"+tutorial.lessonKey())+". "+tt(tutorial.instructionKey()));c.restore();
        drawTutorialBoard(c,69,278,252);
        Board.ActionPreview preview=tutorial.currentPreview();
        float y=575;
        if(tutorial.lessonComplete())objectAction(c,n("continue_lesson")+"  →",24,y,342,53,PEACH,()->practiceAction(()->tutorial.advance()));
        else if(tutorial.requiredAction()==TutorialSession.RequiredAction.HINT)objectAction(c,n("practice_hint"),24,y,342,53,GOLD,()->practiceAction(()->tutorial.hint()));
        else if(tutorial.requiredAction()==TutorialSession.RequiredAction.UNDO)objectAction(c,n("practice_undo"),24,y,342,53,PEACH,()->practiceAction(()->tutorial.undo()));
        else if(tutorial.requiredAction()==TutorialSession.RequiredAction.PREVIEW_GATE)objectAction(c,q("preview_gate"),24,y,342,53,PEACH,()->practiceGate(tutorial.expectedGate()));
        else if(preview!=null){
            StringBuilder changes=new StringBuilder();for(Direction direction:Direction.values())if(((preview.openedMask|preview.closedMask)&direction.bit)!=0){if(changes.length()>0)changes.append(" · ");changes.append(n((preview.openedMask&direction.bit)!=0?"opens":"closes",t("direction_"+direction.name().toLowerCase(Locale.ROOT))));}
            fit(c,changes.toString(),195,225,13,315,TEXT,true,true);
            objectAction(c,tutorial.expectedGate()!=null?n("opening",t("direction_up")):n("confirm_move"),24,575,342,53,PEACH,()->{if(tutorial.expectedGate()!=null)practiceGate(tutorial.expectedGate());else practicePiece(tutorial.expectedTileId(),null);});
        }else fit(c,!tutorialFeedback.isEmpty()&&frameTime<tutorialFeedbackUntil?tt(tutorialFeedback):n("learn_practice"),195,602,14,338,skin.muted,false,true);
        for(int i=0;i<tutorial.lessonCount();i++)sweet.stepChip(c,90+i*35,687,10,i==tutorial.lessonIndex(),i<tutorial.lessonIndex());
        sceneAction(c,n("learn_skip"),24,721,342,()->leaveTutorial());
        fit(c,n("learn_skip_note"),195,792,12,340,skin.muted,false,true);
    }

    private void drawTutorialCompact(Canvas c){
        fit(c,n("learn"),24,31,21,262,TEXT,true,false);
        fit(c,n("lesson",tutorial.lessonIndex()+1,tutorial.lessonCount()),25,62,13,240,skin.accent,true,false);
        sceneAction(c,n("later"),288,40,78,()->leaveTutorial());
        scenePaper(c,new RectF(210,96,366,278),SweetUi.CREAM,true);
        fit(c,tt("title_"+tutorial.lessonKey()),221,121,15,134,TEXT,true,false);
        wrap(c,tt(tutorial.instructionKey()),221,146,133,13,TEXT,false,18);
        label(210,96,156,182,tt("title_"+tutorial.lessonKey())+". "+tt(tutorial.instructionKey()));
        drawTutorialBoard(c,30,103,146);
        boolean done=tutorial.lessonComplete();TutorialSession.RequiredAction required=tutorial.requiredAction();
        if(done)objectAction(c,n("continue_lesson")+" →",217,230,142,48,PEACH,()->practiceAction(()->tutorial.advance()));
        else if(required==TutorialSession.RequiredAction.HINT)objectAction(c,t("booster_hint"),217,230,142,48,GOLD,()->practiceAction(()->tutorial.hint()));
        else if(required==TutorialSession.RequiredAction.UNDO)objectAction(c,t("undo"),217,230,142,48,PEACH,()->practiceAction(()->tutorial.undo()));
        else if(required==TutorialSession.RequiredAction.PREVIEW_GATE)objectAction(c,n("preview"),217,230,142,48,PEACH,()->practiceGate(tutorial.expectedGate()));
        else if(tutorial.currentPreview()!=null)objectAction(c,required==TutorialSession.RequiredAction.OPEN_GATE?n("open_short"):n("confirm_short"),217,230,142,48,PEACH,()->{if(tutorial.expectedGate()!=null)practiceGate(tutorial.expectedGate());else practicePiece(tutorial.expectedTileId(),null);});
        for(int i=0;i<tutorial.lessonCount();i++)sweet.stepChip(c,90+i*35,310,10,i==tutorial.lessonIndex(),i<tutorial.lessonIndex());
        sceneAction(c,n("learn_skip"),24,345,342,()->leaveTutorial());
        fit(c,n("learn_practice"),195,417,12,338,skin.muted,false,true);
    }
    private void drawTutorialBoard(Canvas c,float left,float top,float width){
        tutorialBoardLeft=left;tutorialBoardTop=top;tutorialBoardWidth=width;
        Board practice=tutorial.board();float unit=width/practice.level.size;
        scenePaper(c,new RectF(left-20,top-20,left+width+20,top+width+20),SweetUi.LILAC,true);
        for(int row=0;row<practice.level.size;row++)for(int col=0;col<practice.level.size;col++){
            round(c,left+col*unit+3,top+row*unit+3,unit-6,unit-6,15,0x50ffffff);
        }
        Board.ActionPreview preview=tutorial.currentPreview();
        for(Direction direction:Direction.values()){
            boolean open=practice.isGateOpen(direction);float x=left+width/2+direction.dc*(width/2+15),y=top+width/2+direction.dr*(width/2+15);
            boolean chosen=direction==tutorial.expectedGate()||preview!=null&&((preview.openedMask|preview.closedMask)&direction.bit)!=0;
            sweet.gate(c,x,y,16,direction,open,chosen,frameTime,reduceMotion);
            String gateLabel=t(open?"gate_open":"gate_closed")+" · "+t("direction_"+direction.name().toLowerCase(Locale.ROOT));
            gateHit(x,y,direction,gateLabel,()->practiceGate(direction));
        }
        for(Barrier barrier:practice.level.barriers)if(practice.isBarrierActive(barrier)){
            float x=left+(barrier.col+.5f)*unit,y=top+(barrier.row+.5f)*unit;
            scenePaper(c,new RectF(x-unit*.39f,y-unit*.39f,x+unit*.39f,y+unit*.39f),SweetUi.CREAM,true);icon(c,"lock",x,y,29,TEXT);
            label(x-unit/2,y-unit/2,unit,unit,u("sealed_wall",1));
        }
        for(Tile tile:practice.remainingTiles()){
            float x=left+(tile.col+.5f)*unit,y=top+(tile.row+.5f)*unit;boolean lit=tile.id==tutorial.expectedTileId()||tile.id==tutorial.highlightedHintId();
            sweet.tile(c,new RectF(x-unit*.38f,y-unit*.38f,x+unit*.38f,y+unit*.38f),tile.direction,directionColor(tile.direction),tile.isSwitch(),false,lit,frameTime,reduceMotion);
            if(practice.level.isKey(tile.id))sweet.key(c,x-unit*.26f,y-unit*.25f,10,tile.direction,frameTime,reduceMotion);
            final int id=tile.id;String description=t("piece_description",tile.row+1,tile.col+1,t("direction_"+tile.direction.name().toLowerCase(Locale.ROOT)));
            hit(left+tile.col*unit,top+tile.row*unit,unit,unit,description,()->practicePiece(id,null));
        }
        Iterator<Flight> flight=practiceFlights.iterator();while(flight.hasNext()){
            Flight f=flight.next();float amount=(frameTime-f.at)/(reduceMotion?100f:360f);if(amount>=1){flight.remove();continue;}float dist=reduceMotion?0:amount*amount*280;
            c.saveLayerAlpha(0,0,390,H,Math.round(255*(1-amount)));sweet.tile(c,new RectF(f.x-unit*.38f+f.tile.direction.dc*dist,f.y-unit*.38f+f.tile.direction.dr*dist,f.x+unit*.38f+f.tile.direction.dc*dist,f.y+unit*.38f+f.tile.direction.dr*dist),f.tile.direction,directionColor(f.tile.direction),f.tile.isSwitch(),false,false,frameTime,reduceMotion);c.restore();
        }
        if(!tutorial.lessonComplete()){
            int target=tutorial.expectedTileId();Tile tile=practice.level.tile(target);
            if(tile!=null&&practice.isPresent(target)){
                float x=left+(tile.col+.5f)*unit,y=top+(tile.row+.5f)*unit;
                sweet.handCoach(c,x,y,x+tile.direction.dc*55,y+tile.direction.dr*55,frameTime-tutorialChangedAt,reduceMotion);
            }else if(tutorial.expectedGate()!=null){Direction direction=tutorial.expectedGate();float x=left+width/2+direction.dc*(width/2+15),y=top+width/2+direction.dr*(width/2+15);sweet.handCoach(c,x,y,x,y,frameTime-tutorialChangedAt,reduceMotion);}
        }
    }
    private String screenTitle(String key){return key.equals("economy")?a21("loop"):key.equals("evolution")?a21("evolution"):key.equals("session_energy")?en20("title"):key.equals("squad")?v19("squad"):key.equals("battle_skill")?v19("skill"):key.equals("companion_motion")?x("motion_gallery"):key.equals("expedition")||key.equals("expedition_odds")?x("expedition"):key.equals("profile")?r("profile"):key.equals("badges")?d("badges"):key.equals("summon")?d("summon"):key.equals("summon_pool")?d("odds"):key.equals("summon_reveal")?r("preview"):key.equals("adventure")?r("adventure"):key.equals("collection_hub")?r("collection"):key.equals("atelier")?r("atelier"):key.equals("home")?h("room_title"):key.equals("home_catalog")||key.equals("home_item")?h("furniture"):key.equals("firstlight")?h("first_title"):key.equals("item")?a("preview"):key.equals("story")?a("story_book"):key.equals("wardrobe")?a("avatar"):key.equals("styles")?q("styles"):key.equals("guardians")||key.equals("guardian")?q("guardians"):key.equals("briefing")?e("objective"):key.equals("tutorial")?n("learn"):t(key);}
    private void drawStyles(Canvas c){
        header(c,q("styles"),q("style_count"));
        int i=0;for(AvatarStyles.Style style:AvatarStyles.all()){
            float x=24+(i%3)*117,y=128+(i/3)*229;boolean active=style.id.equals(avatarStyle);
            sceneShelf(c,new RectF(x,y,x+108,y+210),0xffc5b4c9,active);
            drawCompanion(c,character,x+54,y+71,26,style,AvatarStage.Pose.HAPPY,frameTime,reduceMotion,loadout,presentedCosmetics());
            fit(c,style.name(store.resolvedLanguage()),x+54,y+142,14,98,TEXT,true,true);
            fit(c,active?q("style_active"):q("style_choose"),x+54,y+177,12,98,TEXT,false,true);
            hit(x,y,108,210,style.name(store.resolvedLanguage())+", "+(active?q("style_active"):q("style_choose")),()->{try{store.equipAvatarStyle(style.id);syncStyle();sfx(AudioEngine.Sound.SELECT);}catch(IllegalStateException failure){notice(t("save_error"));}});i++;
        }
    }
    private void drawPrismStory(Canvas c){
        ensureHub();PrismStory.ChapterProgress progress=storyChapter==0?hubStory.currentChapter():hubStory.forChapter(storyChapter);PrismStory.Chapter chapter=progress.chapter;
        header(c,a("story_book"),a("chapter",chapter.number)+" · "+v(chapter.biomeKey));
        scenePaper(c,new RectF(24,103,366,330),SweetUi.LILAC,true);dressedMascot(c,326,139,14);
        fit(c,storyText(chapter.titleKey),44,141,21,240,TEXT,true,false);
        wrap(c,storyText(progress.completed?chapter.storyAfterKey:chapter.storyIntroKey),44,183,300,15,TEXT,false,23);
        fit(c,a("story_progress",hubStory.fragmentsClaimed,100),44,309,12,300,skin.muted,true,false);label(24,103,342,227,storyText(chapter.titleKey)+". "+storyText(progress.completed?chapter.storyAfterKey:chapter.storyIntroKey)+". "+a("story_progress",hubStory.fragmentsClaimed,100));
        for(int i=1;i<=10;i++){
            final int n=i;PrismStory.ChapterProgress row=hubStory.forChapter(i);float x=24+((i-1)%5)*69,y=350+((i-1)/5)*55;
            scenic.selector(c,new RectF(x+7,y-3,x+57,y+46),row.unlocked?0xffbea7cd:0xffb0a8b7,chapter.number==i,ScenicUi.Kind.BOOK);fit(c,""+i+(row.completed?" ✓":row.unlocked?"":" ·"),x+32,y+30,15,56,TEXT,true,true);
            int before=hits.size();hit(x,y,64,48,a("chapter",i)+", "+(row.completed?a("all_claimed"):row.unlocked?a("ready"):t("locked")),()->{storyChapter=n;invalidate();});if(hits.size()>before)hits.get(hits.size()-1).selected=chapter.number==i;
        }
        scenePaper(c,new RectF(24,480,366,601),SweetUi.CREAM,true);fit(c,a("objectives"),44,510,15,300,TEXT,true,false);wrap(c,storyText(chapter.objectiveKey),44,539,300,14,skin.muted,false,21);
        label(24,480,342,121,a("objectives")+". "+storyText(chapter.objectiveKey));
        label(24,615,342,72,a("journey_short")+" "+chapter.firstJourney+"–"+chapter.lastJourney+", "+progress.journeyProgress+" / "+progress.journeyTarget);
        label(24,700,342,77,q("guardians")+", "+a("story_progress",progress.fragmentsClaimed,progress.fragmentTarget));
        fit(c,a("journey_short")+"  "+chapter.firstJourney+"–"+chapter.lastJourney,24,633,16,342,TEXT,true,false);fit(c,progress.journeyProgress+" / "+progress.journeyTarget,24,661,13,342,skin.muted,false,false);
        sweet.progress(c,new RectF(24,674,366,683),progress.journeyProgress/(float)progress.journeyTarget,SweetUi.MINT);
        fit(c,q("guardians"),24,722,16,342,TEXT,true,false);fit(c,a("story_progress",progress.fragmentsClaimed,progress.fragmentTarget),24,750,13,342,skin.muted,false,false);
        sweet.progress(c,new RectF(24,764,366,773),progress.fragmentsClaimed/(float)progress.fragmentTarget,SweetUi.LILAC);
        int next=progress.nextGuardian();boolean available=next>0&&hubStory.guardianUnlocked(next);
        String action=next==0?a("back_journey"):available?q("guardian",next)+"  →":a("play_journey");
        objectAction(c,action,24,798,342,50,PEACH,()->{if(available)openGuardian(next);else continueJourney();});
        fit(c,next==0?a("all_claimed"):available?q("guardian_reward"):q("guardian_locked",next*10),195,879,13,336,skin.muted,false,true);
        sceneAction(c,q("guardians"),24,912,342,()->go("guardians"));
    }
    private void drawGuardians(Canvas c){
        header(c,q("guardians"),q("guardian_unlock"));
        wrap(c,q("guardian_story"),24,110,342,14,TEXT,false,20);
        for(int number=1;number<=GuardianCatalog.COUNT;number++){
            final int n=number;float x=24+((n-1)%2)*177,y=200+((n-1)/2)*84;
            if(y<contentScroll-95||y>contentScroll+viewportH+90)continue;
            boolean unlocked=store.guardianUnlocked(n),done=store.guardianCleared(n);
            scenic.object(c,new RectF(x+2,y+9,x+47,y+65),unlocked?0xffb5a0cf:0xffb7adbd,false,ScenicUi.Kind.KEY);
            fit(c,q("guardian",n)+(done?"  ✓":""),x+53,y+29,15,106,TEXT,true,false);
            fit(c,done?q("guardian_done"):unlocked?t("play"):q("guardian_locked",n*10),x+53,y+53,12,106,skin.muted,false,false);
            hit(x,y,165,73,q("guardian",n)+", "+(unlocked?t("play"):t("locked")),()->{if(unlocked)openGuardian(n);else notice(q("guardian_locked",n*10));});
        }
    }
    private void openGuardian(int number){
        if(!store.guardianUnlocked(number)){notice(q("guardian_locked",number*10));return;}
        GuardianEncounter saved=GuardianEncounter.restore(prefs.getString("guardian_v19_session",""));
        guardian=saved!=null&&saved.definition.number==number&&(!saved.isSolved()||!store.guardianCleared(number))?saved:GuardianEncounter.start(number);
        guardianHint=-1;guardianSaveBlocked=false;go("guardian");persistGuardian();
    }
    private boolean persistGuardian(){
        if(guardian==null)return true;
        boolean saved=prefs.edit().putString("guardian_v19_session",guardian.encode()).commit();
        guardianSaveBlocked=!saved;if(!saved)notice(t("save_error"));return saved;
    }
    private void leaveGuardian(){
        if(!persistGuardian())return;
        menuHistory.removeIf(item->item.equals("guardian")||item.equals("guardians"));
        nextSceneDirection=SceneTransition.Direction.BACK;
        boolean wasNavigatingBack=navigatingBack;navigatingBack=true;
        try{go("guardians");}finally{navigatingBack=wasNavigatingBack;}
    }
    private void guardianMove(int id){
        if(guardian==null||guardianSaveBlocked)return;
        GuardianEncounter.MoveResult result=guardian.move(id);guardianHint=-1;
        if(!persistGuardian())return;
        if(result.success){sfx(result.peeled?AudioEngine.Sound.GATE:AudioEngine.Sound.MOVE);haptic();if(result.solved)sfx(AudioEngine.Sound.WIN);}
        else if(result.blocked){sfx(AudioEngine.Sound.BLOCKED);notice(t("blocked"));}
        invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);
    }
    private void drawGuardian(Canvas c){
        if(guardian==null){leaveGuardian();return;}
        GuardianEncounter.Snapshot snap=guardian.snapshot();
        scenic.object(c,new RectF(24,18,72,66),0xffb5a7ca,false,ScenicUi.Kind.RETURN);hit(24,18,48,48,t("back"),this::leaveGuardian);
        fit(c,q("guardian",snap.number),210,51,25,244,TEXT,true,true);
        AvatarStyles.Style scene=AvatarStyles.all().get((snap.number-1)%AvatarStyles.all().size());
        fit(c,scene.name(store.resolvedLanguage()),25,105,18,242,TEXT,true,false);
        drawCompanion(c,character,326,115,21,AvatarStyles.find(avatarStyle),snap.solved?AvatarStage.Pose.WIN:AvatarStage.Pose.THINK,frameTime,reduceMotion,loadout,presentedCosmetics());
        fit(c,q("guardian_work",snap.totalWork-snap.remainingWork,snap.totalWork),25,143,14,300,TEXT,true,false);
        sweet.progress(c,new RectF(25,157,365,168),1f-snap.remainingWork/(float)snap.totalWork,SweetUi.MINT);
        wrap(c,guardian.definition.cellwise?q("guardian_step"):q("guardian_double"),25,198,340,14,TEXT,false,21);
        if(guardianSaveBlocked){scenePaper(c,new RectF(24,268,366,570),SweetUi.CREAM,true);wrap(c,t("save_error"),195,337,296,18,TEXT,true,25);objectAction(c,t("retry"),44,422,302,52,PEACH,()->persistGuardian());return;}
        float unit=270f/snap.size;for(int r=0;r<snap.size;r++)for(int col=0;col<snap.size;col++)round(c,60+col*unit+2,270+r*unit+2,unit-4,unit-4,12,0x70ffffff);
        for(GuardianEncounter.Piece piece:snap.pieces)if(piece.present){
            float x=60+(piece.col+.5f)*unit,y=270+(piece.row+.5f)*unit,w=unit*.76f;
            // Separate visible slabs and an explicit count communicate a real additional hit.
            for(int layer=piece.layers-1;layer>0;layer--)scenePaper(c,new RectF(x-w/2+layer*3,y-w/2+layer*7,x+w/2+layer*3,y+w/2+layer*7),0xffb29ac8,true);
            sweet.tile(c,new RectF(x-w/2,y-w/2,x+w/2,y+w/2),piece.direction,directionColor(piece.direction),false,false,piece.id==guardianHint,frameTime,reduceMotion);
            if(piece.layers>1){round(c,x+w*.04f,y-w*.46f,w*.44f,22,7,GOLD);fit(c,"×"+piece.layers,x+w*.26f,y-w*.46f+16,12,w*.40f,TEXT,true,true);}
            if(piece.cellwise){p.setColor(TEXT);c.drawCircle(x-7,y+w*.31f,2.7f,p);c.drawCircle(x+2,y+w*.24f,2.7f,p);}
            guardianHit(60+piece.col*unit,270+piece.row*unit,unit,piece.id,q("guardian_piece",piece.id+1,t("direction_"+piece.direction.name().toLowerCase(Locale.ROOT)),piece.layers,piece.cellwise?q("guardian_cell"):""),()->guardianMove(piece.id));
        }
        fit(c,t("moves_left",snap.remainingActions,guardian.definition.baseBudget),195,582,20,340,TEXT,true,true);
        if(snap.solved){
            wrap(c,q("guardian_empty"),195,615,330,15,TEXT,true,21);
            objectAction(c,store.guardianCleared(snap.number)?q("guardian_done"):q("guardian_reward"),24,663,342,57,GOLD,()->{try{int got=store.completeGuardian(snap.number);syncStyle();notice(got>0?"+100 LumaCoins":store.guardianCleared(snap.number)?q("guardian_done"):q("stock_full"));}catch(IllegalStateException failure){notice(t("save_error"));}});
        }else{
            if(snap.remainingActions==0)wrap(c,q("guardian_retry"),195,613,330,14,TEXT,true,21);
            else objectAction(c,q("guardian_hint"),24,609,342,49,PEACH,()->{int[] plan=guardian.optimalPlan();guardianHint=plan.length==0?-1:plan[0];invalidate();});
            sceneAction(c,t("undo_free"),24,690,165,()->{if(guardian.undo()){guardianHint=-1;persistGuardian();sfx(AudioEngine.Sound.UNDO);}});
            sceneAction(c,restartLabel120(),201,690,165,()->{guardian.restart();guardianHint=-1;persistGuardian();});
        }
        sceneAction(c,q("guardians"),24,767,342,this::leaveGuardian);
        fit(c,q("guardian_unlock"),195,850,12,335,skin.muted,false,true);
    }

    private void ensureHub(){
        long now=SystemClock.uptimeMillis();if(hubObjectives!=null&&now<hubRefreshAt)return;
        hubObjectives=ObjectiveDashboard.snapshot(store,meta);hubGoal=CollectionGoal.snapshot(store);
        HashSet<Integer> receipts=new HashSet<>();for(int i=1;i<=100;i++)if(store.guardianCleared(i))receipts.add(i);
        hubStory=PrismStory.snapshot(cachedCompleted,receipts);hubRefreshAt=now+1000;
    }
    private void savedAction(Runnable action){try{action.run();syncStyle();invalidate();}catch(GameStore.LocalSaveException failure){blockLocalSave();}}
    private void openRewards(int tab){rewardTab=Math.max(0,Math.min(3,tab));go("rewards");}
    private void continueJourney(){if(board!=null&&!won&&!board.isSolved()&&mode==0)goRoot("play");else previewLevel(Math.min(BalancedCatalog.LEVEL_COUNT,store.unlockedLevel()),0,0);}
    private String goalName(CollectionGoal goal){return goal.kind==CollectionGoal.Kind.COSMETIC?w(goal.nameKey):g(goal.nameKey);}
    private void goalGlyph(Canvas c,CollectionGoal goal,float x,float y,float radius){
        if(goal.kind==CollectionGoal.Kind.COSMETIC){CosmeticCatalog.Item item=CosmeticCatalog.find(goal.id);art.cosmetic(c,item.slot.name(),CosmeticCatalog.ITEMS.indexOf(item)%6,x,y,radius,cosmeticColor(item));}
        else companionPortrait.drawGearGlyph(c,AvatarGearCatalog.find(goal.id),x,y,radius);
    }
    private void sourceRoute(CollectionGoal.Route route){
        switch(route){case JOURNEY:continueJourney();break;case DAILY:eventTab=0;go("events");break;case WEEKLY:eventTab=1;go("events");break;case SHOP:shopCategory=1;go("shop");break;default:openRewards(0);}
    }
    private void openGoal(CollectionGoal goal){
        if(goal.owned||goal.priceCoins>0){if(goal.kind==CollectionGoal.Kind.COSMETIC)cosmeticOffer(CosmeticCatalog.find(goal.id));else previewGear(AvatarGearCatalog.find(goal.id));}
        else sourceRoute(goal.route);
    }
    private void toggleGoal(String key){savedAction(()->{if(key.equals(store.trackedCollectionGoal()))store.clearTrackedCollectionGoal();else store.setTrackedCollectionGoal(key);notice(a(key.equals(store.trackedCollectionGoal())?"tracked_goal":"empty_goal"));});}
    private void claimLogin(String period){savedAction(()->{if(!period.equals(store.dailyId())){notice(a("period_changed"));return;}int got=store.claimDailyLogin();if(got>0){showMenuGift(a("today"),"+"+got+" LumaCoins",null);sfx(AudioEngine.Sound.COIN);}else notice(t("claimed"));});}
    private void claimQuest(ObjectiveDashboard.Quest quest){savedAction(()->{
        if(!quest.period.equals(quest.weekly?meta.weekId():meta.dayId())){notice(a("period_changed"));return;}
        int got=quest.weekly?meta.claimWeeklyMission(quest.index,store):meta.claimMission(quest.index,store);
        if(got>0){showMenuGift(questTitle(quest),"+"+got+" LumaCoins",null);sfx(AudioEngine.Sound.COIN);}else notice(quest.claimed?t("claimed"):t("mission_note"));
    });}
    private void claimEventBonus(boolean daily,String period){savedAction(()->{
        if(!period.equals(daily?store.dailyId():store.weeklyId())){notice(a("period_changed"));return;}
        int got=daily?store.claimDailyCompletionReward():store.claimWeeklyCompletionReward();if(got>0){showMenuGift(t(daily?"daily":"weekly")+" · "+t("bonus"),"+"+got+" LumaCoins",null);sfx(AudioEngine.Sound.COIN);}else notice(t("claimed"));
    });}
    private void collectJourneyGift(int milestone){savedAction(()->{if(store.nextLootMilestone()!=milestone){notice(t("claimed"));return;}claimJourneyGift();});}
    private void launchObjective(ObjectiveDashboard.Action action){
        switch(action.kind){case PLAY_DAILY_EVENT:eventTab=0;openEventStage(true,Math.max(0,action.index));break;case PLAY_WEEKLY_EVENT:eventTab=1;openEventStage(false,Math.max(0,action.index));break;case PLAY_JOURNEY:previewLevel(Math.max(1,action.index),0,0);break;default:openRewards(3);}
    }
    private String questTitle(ObjectiveDashboard.Quest quest){return V17Strings.format(store.resolvedLanguage(),new String[]{"quest_boards","quest_stars","quest_events"}[quest.index],quest.target);}
    private void questRoute(ObjectiveDashboard.Quest quest){if(quest.ready)claimQuest(quest);else if(quest.claimed)notice(t("claimed"));else sourceRoute(quest.route);}
    private void drawGoalCard(Canvas c,float y,CollectionGoal goal){
        scenePaper(c,new RectF(24,y,366,y+170),goal.owned?SweetUi.MINT:SweetUi.CREAM,true);
        fit(c,a("tracked_goal"),44,y+26,12,252,skin.muted,true,false);goalGlyph(c,goal,330,y+37,20);
        fit(c,goalName(goal),44,y+54,20,250,TEXT,true,false);
        String progress=goal.owned?a("goal_owned"):(goal.priceCoins>0?goal.progress+" / "+goal.target+" LumaCoins":a("goal_progress",goal.progress,goal.target));
        fit(c,progress,44,y+83,13,300,goal.owned?skin.accent2:skin.muted,true,false);
        sweet.progress(c,new RectF(44,y+94,346,y+101),goal.owned?1f:goal.target==0?0:Math.min(1,goal.progress/(float)goal.target),SweetUi.MINT);
        label(24,y,342,106,a("tracked_goal")+", "+goalName(goal)+", "+progress);
        objectAction(c,a(goal.owned||goal.priceCoins>0?"preview":"view_source"),44,y+112,302,48,PEACH,()->openGoal(goal));
    }
    private float rewardContentHeight(){ensureHub();int rows=rewardTab==3?Math.max(1,hubObjectives.readyCount):rewardTab==2?1+hubObjectives.trials.size():rewardTab==0?2+hubObjectives.dailyQuests.size():1+hubObjectives.weeklyQuests.size();return Math.max(viewportH,Menu120Layout.rewardHeight(rows,battleMinimumTouch())+84);}
    private String navParent(){
        if(screen.equals("home_catalog")||screen.equals("home_item"))return "home";
        if(screen.equals("item"))return detailParent.equals("shop")?"shop":"collection";
        if(Arrays.asList("collection","wardrobe","styles","profile","badges","summon","summon_pool","summon_reveal").contains(screen))return "collection";
        if(Arrays.asList("events","rewards","missions").contains(screen))return "events";
        if(Arrays.asList("journey","guardians","story").contains(screen))return "journey";
        return screen;
    }


    private void refreshHomeDraft(){
        homeLayout=store.homeLayout();homeDraft=homeSelection.isEmpty()?null:homeLayout.tryPlace(homeSelection,homeDraftX,homeDraftY,homeDraftRotation);homeInvalidPlacement=!homeSelection.isEmpty()&&homeDraft==null;
    }
    private float[] homeCompanionPosition(){
        if(homePath.isEmpty())return new float[]{homeLayout.companionX,homeLayout.companionY};
        float step=reduceMotion?homePath.size():(frameTime-homeWalkAt)/190f;
        if(step>=homePath.size()){homePath=Collections.emptyList();homeActivity=homePendingActivity;homeActivityUntil=homeActivity.equals("hug")?frameTime+4500:homeActivity.equals("idle")?0:Long.MAX_VALUE;return new float[]{homeLayout.companionX,homeLayout.companionY};}
        int index=Math.max(0,(int)step);float mix=Math.max(0,Math.min(1,step-index));
        HomeLayout.Cell to=homePath.get(index);float fromX=index==0?homeWalkStartX:homePath.get(index-1).x,fromY=index==0?homeWalkStartY:homePath.get(index-1).y;
        float dx=to.x-fromX,dy=to.y-fromY;homeFacing=CompanionMotion.facingForVelocity((dx-dy)*HomeScene.TILE_X,(dx+dy)*HomeScene.TILE_Y,homeFacing);
        return new float[]{fromX+(to.x-fromX)*mix,fromY+(to.y-fromY)*mix};
    }
    private float[] homeVisualPosition(){
        homeLayout=store.homeLayout();float[] pos=homeCompanionPosition();
        HomeLayout.Placement used=homeLayout.placement(homeUsingItem);
        if(homePath.isEmpty()&&used!=null&&homeActivity.equals("rest")&&frameTime<homeActivityUntil){pos[0]=used.x+(used.width()-1)*.5f;pos[1]=used.y+(used.depth()-1)*.5f+.15f;}
        return pos;
    }
    private void moveHomeCompanion(int x,int y,String after){if(!homePath.isEmpty()){notice(h("walking"));return;}savedAction(()->{
        float[] visual=homeVisualPosition();
        if(after.equals("idle"))homeUsingItem="";
        HomeLayout before=store.homeLayout();java.util.List<HomeLayout.Cell> path=new ArrayList<>(before.pathTo(x,y));
        if(x!=before.companionX||y!=before.companionY){if(path.isEmpty()||!store.moveHomeCompanion(x,y)){notice(h("unreachable"));return;}}
        if(Math.abs(visual[0]-before.companionX)+Math.abs(visual[1]-before.companionY)>.01f)path.add(0,new HomeLayout.Cell(before.companionX,before.companionY));
        homeWalkStartX=visual[0];homeWalkStartY=visual[1];homePath=path;homeWalkAt=SystemClock.uptimeMillis();homePendingActivity=after;homeActivity=path.isEmpty()?after:"walk";homeActivityUntil=after.equals("hug")?SystemClock.uptimeMillis()+4500:after.equals("idle")?0:Long.MAX_VALUE;homeLayout=store.homeLayout();
        log("home_move","x",""+x,"y",""+y);if(!after.equals("idle"))sfx(after.equals("lamp")?AudioEngine.Sound.GATE:AudioEngine.Sound.SELECT);
    });}
    private void homeCuddle(){homeUsingItem="";if(!homePath.isEmpty()){homePendingActivity="hug";return;}homeActivity="hug";homeActivityUntil=SystemClock.uptimeMillis()+4500;sfx(AudioEngine.Sound.SELECT);haptic();log("home_cuddle");invalidate();announceForAccessibility(h("cuddle_note"));}
    private void startHomeDecorating(){if(!homePath.isEmpty()){notice(h("walking"));return;}homeDecorating=true;homeSelection="";homeUsingItem="";homeActivity="idle";}
    private void homeUse(HomeLayout.Placement placement){
        if(!homePath.isEmpty()){notice(h("walking"));return;}
        HomeCatalog.Item item=HomeCatalog.item(placement.id);if(item==null)return;
        String activity=item.interaction.equals("rest")||item.interaction.equals("sit")||item.interaction.equals("relax")?"rest":item.interaction.equals("read")?"read":item.interaction.equals("tea")?"tea":item.interaction.equals("light")||item.interaction.equals("switch")?"lamp":item.interaction.equals("cuddle")?"hug":"play";
        HomeLayout state=store.homeLayout();int tx=state.companionX,ty=state.companionY,best=Integer.MAX_VALUE;
        for(int x=0;x<HomeLayout.SIZE;x++)for(int y=0;y<HomeLayout.SIZE;y++){
            int edge=Math.max(Math.max(placement.x-x,0),x-(placement.x+placement.width()-1))+Math.max(Math.max(placement.y-y,0),y-(placement.y+placement.depth()-1));
            if(edge!=1&&HomeCatalog.item(placement.id).solid||edge>0&&!HomeCatalog.item(placement.id).solid||state.isBlocked(x,y))continue;
            java.util.List<HomeLayout.Cell> path=state.pathTo(x,y);int distance=x==state.companionX&&y==state.companionY?0:path.isEmpty()?Integer.MAX_VALUE:path.size();
            if(distance<best){best=distance;tx=x;ty=y;}
        }
        if(best==Integer.MAX_VALUE){notice(h("unreachable"));return;}moveHomeCompanion(tx,ty,activity);homeUsingItem=item.id;if(activity.equals("lamp"))homeScene.setInteraction(item.id,!homeScene.isLightOn(item.id));announceForAccessibility(h(item.interaction));
    }
    private void selectHomeItem(String id){
        if(!store.ownsHomeItem(id)||HomeCatalog.item(id)==null)return;
        homeDecorating=true;homeSelection=id;HomeLayout state=store.homeLayout();HomeLayout.Placement placed=state.placement(id);
        if(placed!=null){homeDraftX=placed.x;homeDraftY=placed.y;homeDraftRotation=placed.rotation;}
        else{boolean found=false;for(int y=0;y<HomeLayout.SIZE&&!found;y++)for(int x=0;x<HomeLayout.SIZE&&!found;x++)if(state.tryPlace(id,x,y,0)!=null){homeDraftX=x;homeDraftY=y;homeDraftRotation=0;found=true;}}
        refreshHomeDraft();go("home");
    }
    private void homeFloorTap(int x,int y){
        if(homeDecorating){
            if(!homeSelection.isEmpty()){homeDraftX=x;homeDraftY=y;refreshHomeDraft();invalidate();return;}
            HomeLayout state=store.homeLayout();for(int i=state.placements().size()-1;i>=0;i--){HomeLayout.Placement item=state.placements().get(i);if(item.covers(x,y)){selectHomeItem(item.id);return;}}
            notice(h("placement_hint"));
        }else moveHomeCompanion(x,y,"idle");
    }
    private boolean homePointer(float x,float y,Hit expandedTarget){
        if(x<0||x>390||y<homeSceneTop||y>=homeToolbarTop)return false;
        if(expandedTarget!=null&&!expandedTarget.homeItem&&expandedTarget.action!=null)return false;
        float lx=x,ly=y-homeSceneTop;
        HomeLayout state=store.homeLayout();float[] pos=homeVisualPosition();String activity=!homePath.isEmpty()?"walk":frameTime<homeActivityUntil?homeActivity:"idle";
        if(homeDecorating&&!homeSelection.isEmpty()){int[] cell=homeScene.cellAtCamera(lx,ly);if(cell!=null){homeFloorTap(cell[0],cell[1]);return true;}}
        int target=homeScene.targetAt(state,lx,ly,pos[0],pos[1],activity);
        if(target>=0){HomeLayout.Placement item=state.placements().get(target);if(homeDecorating)selectHomeItem(item.id);else homeUse(item);}
        else if(target==HomeScene.TARGET_COMPANION){if(!homeDecorating)homeCuddle();}
        else if(target==HomeScene.TARGET_WARDROBE)go("wardrobe");
        else if(target==HomeScene.TARGET_PUZZLE)continueGame();
        // Preserve painter-order targeting; the centred larger target also accepts its outer margin.
        else if(expandedTarget!=null&&expandedTarget.homeItem)expandedTarget.action.run();
        else{int[] cell=homeScene.cellAtCamera(lx,ly);if(cell!=null)homeFloorTap(cell[0],cell[1]);}
        return true;
    }
    private void drawRelayRules(Canvas c){
        header(c,r("adventure"),r("relay_tip"));sceneAction(c,"‹  "+t("back"),24,103,120,()->backMenu());
        String[] notes={r("movement_tip"),r("relay_rule"),r("key_tip"),(economyPolicy121?a21("undo_rule"):l("relay_undo_note"))};
        for(int i=0;i<4;i++){float y=174+i*138;sceneShelf(c,new RectF(24,y,366,y+121),PremiumUi.PAPER,false);
            if(i<3){drawTile(c,new Tile(0,0,0,Direction.values()[i],i==1?Direction.RIGHT.bit:0),69,y+57,47,i==1);if(i==2){icon(c,"lock",69,y+57,23,PremiumUi.INDIGO);}}else icon(c,"back",69,y+57,28,PremiumUi.INDIGO);
            wrap(c,notes[i],110,y+34,235,15,TEXT,false,23);label(24,y,342,121,notes[i]);
        }
        H=Math.max(viewportH,850);
    }
    /** Each destination owns a single visual task; the puzzle never carries this chrome. */
    private boolean battleEnabled(){return board!=null&&board.level.progressionVersion==6&&(mode==0||mode==5)&&battleState!=null;}
    private float battleMinimumTouch(){return 48*getResources().getDisplayMetrics().density/Math.max(.01f,scale);}
    private float battleRailHeight(){return CompanionBattleLayout.heightFor(battleMinimumTouch());}
    private String battleFamily(String id){CompanionBattle.Definition def=CompanionBattle.find(id);return def==null?"":v19("skill_"+def.effect.name().toLowerCase(Locale.ROOT));}
    private String battleDetail(String id){CompanionBattle.Definition def=CompanionBattle.find(id);return def==null?"":v19("skill_"+def.effect.name().toLowerCase(Locale.ROOT)+"_detail",def.amount,def.durationMs/1000,def.cost);}
    private void modernAction(Canvas c,RectF area,String caption,int color,String id,Runnable action,boolean enabled){
        boolean down=pressed!=null&&id.equals(pressed.semanticId);c.save();if(down&&!reduceMotion)c.scale(.98f,.98f,area.centerX(),area.centerY());
        round(c,area.left,area.top+3,area.width(),area.height(),22,alpha(color,35));round(c,area.left,area.top,area.width(),area.height()-3,22,enabled?color:0xffe8e5f0);
        fit(c,caption,area.centerX(),area.centerY()+5,15,area.width()-24,enabled?0xff30203f:0xff797184,true,true);c.restore();
        if(enabled)motionHit(area,caption,id,action);else label(area.left,area.top,area.width(),area.height(),caption);
    }
    private void drawBattleActor(Canvas c,String id,RectF box,CompanionMotion.Action action,CompanionMotion.Facing facing,long elapsed,boolean reduced){
        Catalog.CharacterItem who=Catalog.character(id);if(who==null)return;
        PuzzleReaction.Kind reaction=PuzzleReaction.Kind.IDLE;long reactionAge=0;
        if(screen.equals("play")){
            reaction=puzzleReaction.kind(frameTime);reactionAge=puzzleReaction.elapsed(frameTime);
            if(id.equals(battleActor)&&frameTime-battleEffectAt<760&&battleEffectAt>0)action=CompanionMotion.Action.JUMP;
            else if(reaction==PuzzleReaction.Kind.DANCE||reaction==PuzzleReaction.Kind.CHEER)action=CompanionMotion.Action.HAPPY;
            else if(reaction==PuzzleReaction.Kind.JUMP)action=CompanionMotion.Action.JUMP;
            else if(reaction==PuzzleReaction.Kind.THINK)action=CompanionMotion.Action.THINK;
            else if(frameTime<gatePulseUntil)action=CompanionMotion.Action.SURPRISE;
            else if(frameTime<successUntil)action=CompanionMotion.Action.HAPPY;
            else if(frameTime<shakeUntil)action=CompanionMotion.Action.THINK;
            if(selected>=0&&board!=null&&board.level.tile(selected)!=null){Tile tile=board.level.tile(selected);facing=tile.col<board.level.size/2?CompanionMotion.Facing.LEFT:CompanionMotion.Facing.RIGHT;}
        }
        int level=Math.max(1,store.companionStats(id).level);CompanionMotion.Stance stance=CompanionMotion.parseStance(store.companionStance(id));
        long motionTime=reaction==PuzzleReaction.Kind.IDLE?elapsed:reactionAge;
        CompanionMotion.Frame frame=CompanionMotion.sample(id,level,action,facing,stance,motionTime,reduced);
        float radius=Math.min(box.width(),box.height())*.29f;
        c.save();c.translate(0,PuzzleReaction.rise(reaction,reactionAge,reduced));c.rotate(PuzzleReaction.tilt(reaction,reactionAge,reduced),box.centerX(),box.centerY());
        companionPortrait.draw(c,who,box.centerX(),box.centerY(),radius,AvatarStyles.find(avatarStyle),AvatarStage.Pose.IDLE,elapsed,reduced,loadout,presentedCosmetics(),frame);
        c.restore();
    }
    private void drawBattleDock(Canvas c){
        CompanionBattleScene.Slot[] slots=new CompanionBattleScene.Slot[3];
        for(int i=0;i<3;i++){
            if(i>=battleState.team().size()){slots[i]=new CompanionBattleScene.Slot("","","","",0xffb8a4d8,0,false,false,false,v19("empty_slot"));continue;}
            String id=battleState.team().get(i);CompanionBattle.Definition def=CompanionBattle.find(id);String status=battleState.used(i)?v19("used"):battleState.canUse(i)?v19("ready"):v19("need_energy",def.cost);
            slots[i]=new CompanionBattleScene.Slot(id,t(Catalog.character(id).nameKey),battleFamily(id),def.effect.name(),def.color,def.cost,battleState.canUse(i),battleState.used(i),battleSelected==i,status);
        }
        String comboStatus=battleState.comboSpent()?v19("combo_used"):battleState.comboReady()?v19("combo_ready"):v19("combo_locked_short");
        CompanionBattleScene.Snapshot snap=new CompanionBattleScene.Snapshot(slots,battleState.energy(),CompanionBattle.MAX_ENERGY,v19("energy"),v19("combo"),comboStatus,battleState.comboReady(),battleState.comboSpent());
        CompanionBattleScene.Layout areas=CompanionBattleScene.draw(c,new RectF(16,122,374,122+battleRailHeight()),snap,frameTime,reduceMotion,this::drawBattleActor,battleMinimumTouch(),minimumTextSize());
        for(int i=0;i<3;i++){final int index=i;String desc=i<battleState.team().size()?slots[i].name+". "+slots[i].signature+". "+slots[i].statusLabel+". "+slots[i].energyCost+" "+v19("energy"):v19("empty_slot");
            motionHit(areas.actions[i],desc,"battle_skill_"+i,()->{if(index<battleState.team().size())openBattleSkill(index,false);else openSquad();});}
        motionHit(areas.combo,v19("combo")+". "+(battleState.comboReady()||battleState.comboSpent()?comboStatus:v19("combo_locked")),"battle_combo",()->openBattleSkill(-1,true));
    }
    private void openBattleSkill(int slot,boolean combo){
        if(!battleEnabled()||won||paused||help||powerSaveBlocked||flowRemaining>0)return;
        battleSelected=slot;battleComboPreview=combo;battlePreviewState=battleState.encode();battlePreviewHistory=Arrays.hashCode(board.history());go("battle_skill");menuHistory.push("play");
    }
    private void drawBattleSkillPage(Canvas c){
        if(!battleEnabled()||!battleComboPreview&&(battleSelected<0||battleSelected>=battleState.team().size())){modernAction(c,new RectF(24,100,366,156),v19("back"),0xffc3eddd,"battle_skill_close",()->backMenu(),true);return;}
        modernAction(c,new RectF(18,14,108,64),"‹ "+v19("back"),0xffe8e4fb,"battle_skill_close",()->backMenu(),true);
        String id=battleComboPreview?battleState.team().get(0):battleState.team().get(battleSelected);
        String name=battleComboPreview?v19("combo"):t(Catalog.character(id).nameKey);fit(c,name,235,44,24,245,TEXT,true,true);
        int color=battleComboPreview?0xffb8a0ef:CompanionBattle.find(id).color;
        float pulse=reduceMotion?0:(float)Math.sin(frameTime*.002)*5;round(c,48,92,294,256,42,alpha(color,38));p.setColor(alpha(color,40));c.drawCircle(195,216,85+pulse,p);
        drawBattleActor(c,id,new RectF(98,96,292,334),CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,frameTime,reduceMotion);
        fit(c,battleComboPreview?v19("combo"):battleFamily(id),195,380,25,342,TEXT,true,true);
        float y=prose(c,battleComboPreview?v19("combo_detail"):battleDetail(id),404,TEXT);
        if(!battleComboPreview&&CompanionBattle.find(id).effect==CompanionBattle.Effect.REWIND&&moveBudget.policyVersion()==MoveBudget.FOCUSED_RELAY_POLICY_VERSION)y=prose(c,vr("undo_rule"),y+8,PremiumUi.MUTED);
        y=prose(c,v19("stage_energy_help"),y+12,PremiumUi.MUTED);
        y=prose(c,v19("charge_on_exit"),y+8,PremiumUi.MUTED);
        String energyLabel=v19("energy")+" · "+battleState.energy()+" / "+CompanionBattle.MAX_ENERGY;
        fit(c,energyLabel,195,y+28,18,330,TEXT,true,true);y+=48;
        boolean available=battleComboPreview?battleState.comboReady():battleState.canUse(battleSelected);
        String status=available?v19("skill_activate"):battleComboPreview?battleState.comboSpent()?v19("combo_used"):v19("combo_locked_short"):battleState.used(battleSelected)?v19("used"):v19("need_energy",CompanionBattle.find(id).cost);
        final int slot=battleSelected;final boolean combo=battleComboPreview;
        modernAction(c,new RectF(24,y,366,y+58),status,0xffc3b3f4,"battle_skill_activate",()->activateBattleSkill(slot,combo),available);y+=77;
        modernAction(c,new RectF(24,y,366,y+55),v19("team_back_play"),0xffe5f4f0,"battle_skill_close_bottom",()->backMenu(),true);y+=72;
        fit(c,v19("once_per_run"),195,y+14,12,335,PremiumUi.MUTED,false,true);battleSkillHeight=Math.max(830,y+52);H=Math.max(viewportH,battleSkillHeight);
    }
    private void activateBattleSkill(int slot,boolean combo){
        if(!battleEnabled()||won||paused||help||!running||powerSaveBlocked||flowRemaining>0||!battlePreviewState.equals(battleState.encode())||battlePreviewHistory!=Arrays.hashCode(board.history()))return;
        for(String id:battleState.team())if(!store.ownsCharacter(id)){notice(v19("squad_locked"));return;}
        ensureGuidance();CompanionBattle.Definition def=slot>=0&&slot<battleState.team().size()?CompanionBattle.find(battleState.team().get(slot)):null;
        boolean needsPlan=combo||def!=null&&def.effect!=CompanionBattle.Effect.VISION&&def.effect!=CompanionBattle.Effect.REWIND;
        if(needsPlan&&guidancePending){notice(n("thinking"));return;}
        CompanionBattleAction.Draft draft=CompanionBattleAction.prepare(board,moveBudget,mode,undos,battleState,slot,combo,guidancePlan);
        if(draft==null){notice(v19("skill_no_target"));return;}
        long now=SystemClock.uptimeMillis();effectsPausedAt=now;Board previous=board;battleActor=slot>=0?battleState.team().get(slot):battleState.team().get(0);
        board=draft.board;moveBudget=draft.budget;battleState=draft.state;undos=draft.undos;
        selected=-1;pendingAction=-1;actionPreview=null;safeHighlights.clear();trailUntil=focusUntil=0;hintId=-1;visionUntil=0;
        if(draft.hintId>=0){hintId=draft.hintId;hintUntil=now+draft.hintDurationMs;hintsUsed++;}
        if(draft.visionDurationMs>0){visionUntil=now+draft.visionDurationMs;hintsUsed++;}
        if(draft.trail.length>0){trail=draft.trail;trailUntil=now+draft.trailDurationMs;hintsUsed++;}
        if(elements121!=null)for(Tile tile:previous.level.tiles)if(!board.isPresent(tile.id))elements121.clear(tile.id);
        if(draft.rewound.length>0)exitChain121.correction();
        boolean committed=persistMove();go("play");if(!committed)return;
        long castAt=SystemClock.uptimeMillis();flights.clear();int ordinal=0;
        for(int action:draft.performed){Tile tile=previous.level.tile(action);if(tile!=null)flights.add(new Flight(tile,castAt+ordinal++*(reduceMotion?0:140),bx+(tile.col+.5f)*cell,by+(tile.row+.5f)*cell,draft.color));}
        int target=draft.hintId>=0?draft.hintId:draft.trail.length>0?draft.trail[0]:draft.performed.length>0?draft.performed[draft.performed.length-1]:draft.rewound.length>0?draft.rewound[0]:-1;
        Tile focusedTile=previous.level.tile(target);successX=focusedTile==null?bx+previous.level.size*cell/2:bx+(focusedTile.col+.5f)*cell;successY=focusedTile==null?by+previous.level.size*cell/2:by+(focusedTile.row+.5f)*cell;
        battleEffect=draft.effect;battleEffectColor=draft.color;battleEffectAt=castAt;successUntil=castAt+750;gatePulseUntil=castAt+800;
        sfx(draft.effect==CompanionBattle.Effect.REWIND?AudioEngine.Sound.UNDO:draft.effect==CompanionBattle.Effect.FLOW?AudioEngine.Sound.GATE:draft.effect==CompanionBattle.Effect.PULSE?AudioEngine.Sound.MOVE:AudioEngine.Sound.HINT);haptic();ensureGuidance();announceForAccessibility(combo?v19("combo"):battleFamily(battleActor));
        if(board.isSolved())finishLevel();else if(outOfMoves())exhausted();
    }
    private void openSquad(){boolean fromPlay=screen.equals("play");squadDraft.clear();squadDraft.addAll(store.companionSquad());squadEditSlot=0;squadPage=0;go("squad");if(fromPlay)menuHistory.push("play");}
    private void chooseSquadMember(String id){
        if(!store.ownsCharacter(id)){openItem("character",id);return;}
        int target=Math.min(squadEditSlot,squadDraft.size());int old=squadDraft.indexOf(id);
        if(old==target)return;
        if(old>=0){if(target>=squadDraft.size())return;Collections.swap(squadDraft,old,target);}
        else if(target<squadDraft.size())squadDraft.set(target,id);else if(squadDraft.size()<3)squadDraft.add(id);
        invalidate();announceForAccessibility(t(Catalog.character(id).nameKey));
    }
    private void drawSquad(Canvas c){
        if(squadDraft.isEmpty())squadDraft.addAll(store.companionSquad());
        modernAction(c,new RectF(18,14,111,64),"‹ "+v19("back"),0xffe8e4fb,"squad_back",()->backMenu(),true);fit(c,v19("squad"),244,46,27,224,TEXT,true,true);
        float y=prose(c,v19("team_desc"),84,PremiumUi.MUTED);if(board!=null&&!won&&!board.isSolved())y=prose(c,v19("run_team_fixed"),y+4,0xff7650a8);y=Math.max(135,y+15);
        for(int i=0;i<3;i++){
            final int index=i;float left=19+i*120;RectF box=new RectF(left,y,left+112,y+151);String id=i<squadDraft.size()?squadDraft.get(i):"";
            round(c,left,y,112,151,27,i==squadEditSlot?0xffe0d3fa:0xfff4f1fa);
            if(!id.isEmpty()){drawBattleActor(c,id,new RectF(left+13,y+5,left+99,y+91),CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,frameTime,reduceMotion);fit(c,t(Catalog.character(id).nameKey),left+56,y+111,13,100,TEXT,true,true);fit(c,battleFamily(id),left+56,y+133,11,102,PremiumUi.MUTED,false,true);}
            else{fit(c,"+",left+56,y+67,36,95,0xff8e70c5,true,true);fit(c,v19("empty_slot"),left+56,y+116,12,100,PremiumUi.MUTED,false,true);}
            motionHit(box,v19("team_pick_slot",i+1)+(id.isEmpty()?"":": "+t(Catalog.character(id).nameKey)),"squad_slot_"+i,()->{squadEditSlot=Math.min(index,squadDraft.size());invalidate();});
        }
        y+=173;fit(c,v19("team_pick_slot",squadEditSlot+1),24,y,17,340,TEXT,true,false);y+=18;
        int perPage=6,start=squadPage*perPage,end=Math.min(Catalog.CHARACTERS.length,start+perPage);
        for(int n=start;n<end;n++){
            Catalog.CharacterItem who=Catalog.CHARACTERS[n];int local=n-start;float left=19+(local%3)*120,topY=y+(local/3)*159;boolean owned=store.ownsCharacter(who.id),included=squadDraft.contains(who.id);
            round(c,left,topY,112,148,24,included?0xffd9f0e8:0xfffaf7fc);drawBattleActor(c,who.id,new RectF(left+16,topY+4,left+96,topY+91),CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,frameTime,reduceMotion);
            fit(c,t(who.nameKey),left+56,topY+108,13,101,TEXT,true,true);fit(c,included?v19("squad"):owned?t("owned"):t("locked"),left+56,topY+132,12,102,owned?0xff347c68:PremiumUi.MUTED,included,true);
            final String id=who.id;motionHit(new RectF(left,topY,left+112,topY+148),t(who.nameKey)+". "+battleFamily(id)+". "+(owned?t("owned"):t("locked")),"squad_member_"+id,()->chooseSquadMember(id));
        }
        y+=2*159+11;int pages=(Catalog.CHARACTERS.length+perPage-1)/perPage;
        modernAction(c,new RectF(20,y,105,y+52),"‹",0xffeee9fb,"squad_page_back",()->{squadPage--;invalidate();},squadPage>0);fit(c,(squadPage+1)+" / "+pages,195,y+32,15,140,TEXT,true,true);
        modernAction(c,new RectF(285,y,370,y+52),"›",0xffeee9fb,"squad_page_next",()->{squadPage++;invalidate();},squadPage<pages-1);y+=69;
        if(squadDraft.size()>1){modernAction(c,new RectF(24,y,366,y+50),v19("remove_from_squad"),0xfff3e3ed,"squad_remove",()->{if(squadEditSlot<squadDraft.size()&&squadDraft.size()>1){squadDraft.remove(squadEditSlot);squadEditSlot=Math.min(squadEditSlot,squadDraft.size()-1);invalidate();}},squadEditSlot<squadDraft.size());y+=64;}
        modernAction(c,new RectF(24,y,366,y+59),v19(board!=null&&!won&&!board.isSolved()?"save_squad_next":"save_squad"),0xffbfe8d9,"squad_save",()->savedAction(()->{if(store.setCompanionSquad(new ArrayList<>(squadDraft))){notice(v19("squad_saved"));invalidate();}}),!squadDraft.equals(store.companionSquad()));y+=78;
        y=prose(c,v19("run_team_fixed"),y,PremiumUi.MUTED);y=prose(c,v19("cosmetics_note"),y+7,PremiumUi.MUTED);squadHeight=Math.max(1050,y+125);H=Math.max(viewportH,squadHeight);drawFixedNavigation(c);
    }

    private int readyGiftCount120(){ensureHub();return hubObjectives.readyCount;}
    private void drawAdventure(Canvas c){
        Menu121Layout menu=new Menu121Layout(viewportH,battleMinimumTouch());ensureHub();int current=Math.min(1000,store.unlockedLevel());
        round(c,0,0,390,menu.contentHeight,0,0xfff7f4fc);
        String name=profileSignedIn&&!profileName.isEmpty()?profileName:store.playerNickname();
        fit(c,m20("hello",name),24,36,24,280,TEXT,true,false);
        int shownHomeXp121=(int)xpMotion121.sample(meta.xp(),frameTime,reduceMotion);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"player_level",1+shownHomeXp121/MetaProgress.XP_PER_RANK),24,64,12,176,0xff655291,true,false);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"xp_progress",shownHomeXp121%MetaProgress.XP_PER_RANK,MetaProgress.XP_PER_RANK),260,64,12,100,0xff655291,true,true);
        round(c,24,78,342,7,4,0xffe6dff1);if(shownHomeXp121%MetaProgress.XP_PER_RANK>0)round(c,24,78,342f*(shownHomeXp121%MetaProgress.XP_PER_RANK)/MetaProgress.XP_PER_RANK,7,4,0xff8c6cc8);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"coins_loop"),24,103,12,342,PremiumUi.MUTED,false,false);
        motionHit(menuRect(menu.profile),m20("hello",name)+". "+Menu121Strings.get(store.resolvedLanguage(),"player_level",meta.rank())+". "+Menu121Strings.get(store.resolvedLanguage(),"xp_progress",meta.rankProgress(),MetaProgress.XP_PER_RANK)+". "+Menu121Strings.get(store.resolvedLanguage(),"xp_rule"),"home_profile",()->openAccount());
        round(c,menu.settings.left,menu.settings.top,menu.settings.width(),menu.settings.height(),20,0xffe9e2f4);icon(c,"settings",menu.settings.centerX(),menu.settings.centerY(),22,0xff695781);
        motionHit(menuRect(menu.settings),t("settings"),"settings_entry",()->go("settings"));
        hero121Scene.draw(c,menuRect(menu.hero),frameTime,reduceMotion,character.color);
        CompanionProgression.Stats avatarProgress=store.companionStats(character.id);CompanionProgression.Definition avatarDefinition=CompanionProgression.find(character.id);
        hero121Fit(c,Menu121Strings.get(store.resolvedLanguage(),"avatar_role"),42,140,11,239,0xffe9e3ff,true,false);
        String grade=(avatarDefinition==null?"":avatarDefinition.rarity.name()+" · ")+Menu121Strings.get(store.resolvedLanguage(),"companion_level",Math.max(1,avatarProgress.level));
        c.save();c.clipRect(menu.hero.left,menu.hero.top+20,menu.hero.right,menu.hero.bottom-89);dressedMascot(c,195,245,67);c.restore();
        round(c,264,145,86,30,12,0xb52e2854);hero121Fit(c,grade,307,165,12,78,0xffddfff4,true,true);
        hero121Fit(c,t(character.nameKey),195,379,24,300,0xfffffaff,true,true);
        String copyProgress=avatarProgress.maxed()?Menu121Strings.get(store.resolvedLanguage(),"max_evolution"):Menu121Strings.get(store.resolvedLanguage(),"copies_progress",avatarProgress.copies,avatarProgress.nextThreshold);
        hero121Fit(c,copyProgress+" · "+Menu121Strings.get(store.resolvedLanguage(),"evolve_by_copies"),195,400,12,306,0xffe8e0f8,false,true);
        motionHit(menuRect(menu.avatar),t(character.nameKey)+". "+grade+". "+copyProgress+". "+Menu121Strings.get(store.resolvedLanguage(),"copies_skills_rule"),"home_avatar",()->go("evolution"));
        modernAction(c,menuRect(menu.evolution),Menu121Strings.get(store.resolvedLanguage(),"evolution_action"),0xffc6ece5,"home_evolution",()->go("evolution"),true);
        modernAction(c,menuRect(menu.style),Menu121Strings.get(store.resolvedLanguage(),"style_action"),0xffead8f5,"home_wardrobe",()->go("wardrobe"),true);
        List<String> team=store.companionSquad();
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"team_role"),24,menu.team.top+15,12,232,0xff655291,true,false);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"choose")+" ›",366,menu.team.top+15,12,100,0xff655291,true,true);
        for(int i=0;i<3;i++){
            float left=24+i*117,yy=menu.team.top+28;RectF slot=new RectF(left,yy,left+108,menu.team.bottom);round(c,left,yy,108,slot.height(),19,0xffeee7f7);
            if(i<team.size()){
                String id=team.get(i);CompanionBattle.Definition skill=CompanionBattle.find(id);drawBattleActor(c,id,new RectF(left+5,yy+3,left+48,yy+55),CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,frameTime,reduceMotion);
                fit(c,t(Catalog.character(id).nameKey),left+49,yy+25,12,54,TEXT,true,false);
                round(c,left+8,yy+58,92,21,10,skill==null?0xffded6eb:blend(skill.color,0xffffffff,.74f));fit(c,battleFamily(id),left+54,yy+73,11,86,0xff4e3c69,true,true);
            }else{center(c,"+",left+54,yy+36,25,0xff9b86b6,true);fit(c,Menu121Strings.get(store.resolvedLanguage(),"choose"),left+54,yy+71,12,94,0xff726087,false,true);}
        }
        motionHit(menuRect(menu.team),Menu121Strings.get(store.resolvedLanguage(),"battle_role")+". "+Menu121Strings.get(store.resolvedLanguage(),"team_purpose"),"squad_entry",()->openSquad());
        String play=t(board!=null&&!won&&!board.isSolved()?"resume":"play")+"  ·  "+t("level_number",board!=null&&!won?levelIndex:current);
        modernAction(c,menuRect(menu.play),play,0xffb7e7d6,"journey_continue",()->continueGame(),true);
        String[] rooms={"", "living", "kitchen", "garden"};String[] roomNames={r("house"),h("room_living"),Menu121Strings.get(store.resolvedLanguage(),"kitchen"),h("room_garden")};String[] roomArt={"", "sofa", "kitchen", "greenhouse"};
        for(int i=0;i<4;i++){final int roomIndex=i;Menu120Layout.Rect place=menu.environments[i];round(c,place.left,place.top,place.width(),place.height(),20,i==0?0xffdcece4:i==2?0xffffead4:0xffe9e1f3);
            RectF illustration=new RectF(place.centerX()-29,place.top+8,place.centerX()+29,place.top+62);if(i==0)scenic.object(c,illustration,0xff8cb7a6,false,ScenicUi.Kind.HOUSE);else homeScene.drawItem(c,roomArt[i],illustration,frameTime,reduceMotion);
            fit(c,roomNames[i],place.centerX(),place.bottom-13,12,place.width()-8,TEXT,true,true);
            motionHit(menuRect(place),roomNames[i],i==0?"home_room_quick":"home_room_"+rooms[i],()->{if(roomIndex>0){if(!HomeCatalog.validRoom(rooms[roomIndex])){notice(b("item_unavailable"));return;}switchHomeRoom(rooms[roomIndex]);}goRoot("home");});
        }
        round(c,menu.gifts.left,menu.gifts.top,menu.gifts.width(),menu.gifts.height(),25,0xfffff2d8);round(c,menu.shop.left,menu.shop.top,menu.shop.width(),menu.shop.height(),25,0xffe9e0f8);
        drawGiftIcon(c,menu.gifts.centerX(),menu.gifts.top+43,51,0xffd3a7e8,false);fit(c,m20("gifts"),menu.gifts.centerX(),menu.gifts.top+89,20,150,TEXT,true,true);
        int ready=readyGiftCount120();fit(c,ready>0?m20("gift_ready",ready):a("today"),menu.gifts.centerX(),menu.gifts.top+114,12,150,ready>0?0xff8b5b24:PremiumUi.MUTED,ready>0,true);
        if(ready>0){float pulse=reduceMotion?1:1+(float)Math.sin(frameTime*.004)*.04f;p.setColor(0xffffd77f);c.drawCircle(menu.gifts.right-24,menu.gifts.top+21,15*pulse,p);center(c,String.valueOf(ready),menu.gifts.right-24,menu.gifts.top+26,13,TEXT,true);}
        motionHit(menuRect(menu.gifts),m20("quests")+", "+m20("gift_ready",ready),"rewards_entry",()->openRewards(ready>0?3:0));
        drawStorefront(c,menu.shop.centerX(),menu.shop.top+45,73);fit(c,m20("shop"),menu.shop.centerX(),menu.shop.top+89,20,150,TEXT,true,true);fit(c,m20("shop_looks"),menu.shop.centerX(),menu.shop.top+114,12,150,PremiumUi.MUTED,false,true);
        motionHit(menuRect(menu.shop),m20("shop")+". "+Menu121Strings.get(store.resolvedLanguage(),"coins_role"),"shop_entry",()->{shopCategory=1;goRoot("shop");});
        Menu120Layout.Rect[] shortcuts={menu.map,menu.expedition,menu.events};String[] names={r("all_levels"),x("expedition"),r("events")};ScenicUi.Kind[] marks={ScenicUi.Kind.COMPASS,ScenicUi.Kind.PORTAL,ScenicUi.Kind.LANTERN};
        for(int i=0;i<3;i++){final int index=i;Menu120Layout.Rect box=shortcuts[i];round(c,box.left,box.top,box.width(),box.height(),22,0xffeee8f7);scenic.object(c,new RectF(box.centerX()-20,box.top+9,box.centerX()+20,box.top+48),i==0?0xff83bcae:i==1?0xffb593d4:0xffd9b574,false,marks[i]);fit(c,names[i],box.centerX(),box.bottom-15,12,box.width()-12,TEXT,true,true);
            motionHit(menuRect(box),names[i],i==0?"journey_entry":i==1?"expedition_entry":"events_entry",()->{if(index==0){journeyTab=0;go("journey");}else if(index==1)openExpedition();else go("events");});}
        fit(c,"⌂  "+h("room_title"),menu.room.centerX(),menu.room.centerY()+5,13,155,PremiumUi.MUTED,false,true);fit(c,"✦  "+r("atelier"),menu.atelier.centerX(),menu.atelier.centerY()+5,13,155,PremiumUi.MUTED,false,true);
        motionHit(menuRect(menu.room),h("room_title"),"home_room",()->goRoot("home"));motionHit(menuRect(menu.atelier),r("atelier"),"home_atelier",()->goRoot("atelier"));H=menu.contentHeight;drawFixedNavigation(c);
    }
    /** Dark hero stages retain their authored high-contrast text, with the normal minimum font size. */
    private void hero121Fit(Canvas c,String caption,float x,float y,float size,float width,int color,boolean heavy,boolean centered){
        p.setShader(null);p.setTypeface(heavy?bold:regular);p.setTextAlign(Paint.Align.LEFT);p.setTextSize(Math.max(minimumTextSize(),size));
        float measured=p.measureText(caption);if(measured>width)p.setTextSize(Math.max(minimumTextSize(),p.getTextSize()*width/measured));
        String visible=android.text.TextUtils.ellipsize(caption,p,width,android.text.TextUtils.TruncateAt.END).toString();p.setColor(color);c.drawText(visible,centered?x-p.measureText(visible)/2:x,y,p);
    }
    private void drawStorefront(Canvas c,float x,float y,float size){
        c.save();c.translate(x,y);float s=size/78f;c.scale(s,s);
        p.setColor(0x2e715c91);c.drawOval(-40,27,40,38,p);round(c,-32,-23,64,53,12,0xfff9d4ce);round(c,-38,-35,76,15,7,0xff9975bc);
        for(int i=0;i<6;i++)round(c,-39+i*13,-30,13,22,5,i%2==0?0xfffff3d6:0xffcfafe7);
        round(c,-24,-6,24,35,7,0xfff9f5ff);round(c,6,-6,19,22,6,0xffc1e7de);star(c,15,5,6,0xfffff3b8);
        shopArt.capsule(c,-12,13,10,frameTime,reduceMotion);shopArt.coin(c,34,23,10,frameTime,reduceMotion);
        if(!reduceMotion)star(c,42,-27+(float)Math.sin(frameTime*.003)*3,5,0xffffd688);c.restore();
    }
    private void drawCollectionHub(Canvas c){
        drawScenery(c,"collection");sceneHeading(c,r("collection"),d("look_book"));
        SceneRootLayout positions=rootLayout();
        sceneCaption(c,flagGlyph(store.playerFlag())+"  "+store.playerNickname(),170,104,292,20);sceneHit(positions.collectionProfileHit,r("profile"),()->go("profile"));
        float cy=positions.collectionPortraitY, radius=positions.collectionPortraitRadius;dressedMascot(c,195,cy,radius);
        sceneHit(positions.collectionPortraitHit,r("wardrobe"),()->go("wardrobe"));sceneCaption(c,t(character.nameKey),195,positions.collectionNameBaseline,280,22);
        sceneDestination(c,ScenicUi.Kind.MIRROR,r("wardrobe"),positions.collectionWardrobe,0xffae8fc5,()->go("wardrobe"));
        sceneDestination(c,ScenicUi.Kind.CAPSULE,d("summon"),positions.collectionSummon,0xffb9a0dc,()->go("summon"));
        float companionsY=positions.collectionRowY;
        drawCompanion(c,Catalog.character("miko"),70,companionsY-3,18,AvatarStyles.find("plush_classic"),AvatarStage.Pose.IDLE,frameTime,reduceMotion,null,Collections.emptyList());
        drawCompanion(c,Catalog.character("nova"),101,companionsY+4,22,AvatarStyles.find("plush_classic"),AvatarStage.Pose.IDLE,frameTime,reduceMotion,null,Collections.emptyList());
        sceneCaption(c,d("my_companions"),88,companionsY+49,132,14);sceneHit(positions.collectionCompanionsHit,d("my_companions"),()->{collectionTab=0;collectionPage=0;inventoryFilter=0;go("collection");});
        sceneDestination(c,ScenicUi.Kind.MEDAL,d("badges"),positions.collectionBadges,0xffd8ab5d,()->{profileBadgeSlot=0;go("badges");});
        sceneDestination(c,ScenicUi.Kind.DUMMY,r("equipment"),positions.collectionEquipment,0xff86b6ac,()->{collectionTab=2;collectionPage=0;inventoryFilter=0;go("collection");});
        sceneSiblings(c);H=viewportH;
    }
    private ExpeditionRun shownExpedition(){ExpeditionRun run=store.expeditionRun();return run!=null&&(!run.claimed||expeditionShowResult)?run:null;}
    private void openExpedition(){expeditionShowResult=false;if(!CompanionProgression.expeditionAvailable(expeditionCompanion)||!store.ownsCharacter(expeditionCompanion))expeditionCompanion="nova";if(!store.ownsCharacter(expeditionTarget))expeditionTarget=expeditionCompanion;go("expedition");}
    private String expeditionSkillKey(String id){CompanionProgression.Definition who=CompanionProgression.find(id);return who==null||who.skill==CompanionProgression.Skill.NONE?"skill_none":who.skill==CompanionProgression.Skill.REVEAL?"skill_reveal":who.skill==CompanionProgression.Skill.REROUTE?"skill_reroute":"skill_project";}
    private String expeditionSkillDetail(String id){String key=expeditionSkillKey(id);return key.equals("skill_none")?x(key):x(key+"_detail");}
    private String expeditionOptionTitle(ExpeditionCatalog.Option option){return x(option.titleKey);}
    private ExpeditionScene.Branch expeditionBranch(ExpeditionRun run,ExpeditionCatalog.Option option){
        String future=run.revealed(option.id)?x("puzzle_number",option.futureBoardNumber):"";
        String title=option.project&&run.goal==ExpeditionRun.Goal.COPIES?x("exp_route_project_copies"):expeditionOptionTitle(option);
        return new ExpeditionScene.Branch(title,x("puzzle_number",option.boardNumber)+" · "+x(option.descriptionKey),x("route_saved"),future);
    }
    private ExpeditionScene.Snapshot expeditionSnapshot(){
        ExpeditionRun run=shownExpedition();String id=run==null?expeditionCompanion:run.companionId;
        CompanionProgression.Definition def=CompanionProgression.find(id);if(def==null){id="nova";def=CompanionProgression.find(id);}
        CompanionProgression.Stats stats=store.companionStats(id);ExpeditionScene.Snapshot s=new ExpeditionScene.Snapshot();
        s.title=x("observatory");s.subtitle=x("expedition_intro");s.companionName=t(Catalog.character(id).nameKey);s.rarity=def.rarity.name();s.level=run==null?stats.level:run.companionLevel;s.copies=stats.copies;s.nextCopies=stats.nextThreshold;
        if(run==null&&!store.ownsCharacter(expeditionTarget))expeditionTarget=id;ExpeditionRun.Goal goal=run==null?expeditionGoal:run.goal;String target=run==null?expeditionTarget:run.targetId;
        s.goalTitle=x(goal==ExpeditionRun.Goal.COPIES?"goal_copies":"goal_home");s.goalDetail=(goal==ExpeditionRun.Goal.COPIES?t(Catalog.character(target).nameKey)+" · ":"")+x(goal==ExpeditionRun.Goal.COPIES?"goal_copies_detail":"goal_home_detail");
        s.skillTitle=x(expeditionSkillKey(id));s.skillDetail=expeditionSkillDetail(id);
        s.guaranteed=goal==ExpeditionRun.Goal.COPIES?x("one_copy",t(Catalog.character(target).nameKey)):x("home_progress",Math.min(GameStore.EXPEDITION_HOME_TARGET,store.expeditionHomeProgress()+ExpeditionCatalog.HOME_CONTRIBUTION),GameStore.EXPEDITION_HOME_TARGET);
        s.discovery=x("one_discovery");s.steps=ExpeditionCatalog.STAGES;
        if(run==null){s.phase=ExpeditionScene.Phase.START;s.skillAvailable=false;return s;}
        s.step=Math.min(s.steps,run.stage()+1);s.claimed=run.claimed;
        if(run.finished()){
            s.phase=ExpeditionScene.Phase.RETURN;GameStore.ExpeditionReward receipt=store.expeditionReward(run.id);
            if(receipt!=null){CompanionProgression.Stats revealed=store.companionStats(receipt.discoveryId);s.companionName=t(Catalog.character(receipt.discoveryId).nameKey);s.rarity=CompanionProgression.find(receipt.discoveryId).rarity.name();s.level=revealed.level;s.copies=revealed.copies;s.nextCopies=revealed.nextThreshold;ArrayList<String> rows=new ArrayList<>();rows.add(x(receipt.discoveryDuplicate?"copy_added":"new_companion",t(Catalog.character(receipt.discoveryId).nameKey)));
                rows.add(x("copies",receipt.discoveryAfter,CompanionProgression.stats(receipt.discoveryAfter).nextThreshold));
                if(!receipt.targetId.isEmpty())rows.add(x("copy_added",t(Catalog.character(receipt.targetId).nameKey)));
                if(receipt.homeAfter>receipt.homeBefore)rows.add(x("home_progress",receipt.homeAfter,GameStore.EXPEDITION_HOME_TARGET));
                if(receipt.coins>0)rows.add(x("coins",receipt.coins));s.receipt=rows.toArray(new String[0]);}
            return s;
        }
        s.phase=ExpeditionScene.Phase.ROUTE;s.readyToPlay=run.selectedOption()!=null;s.skillAvailable=false;
        for(ExpeditionCatalog.Option option:run.options())if(run.canUseSkill(option.id))s.skillAvailable=true;
        s.skillDetail+=" "+x("skill_uses",run.skillRemaining());
        List<ExpeditionCatalog.Option> options=run.options();if(!options.isEmpty())s.left=expeditionBranch(run,options.get(0));if(options.size()>1)s.right=expeditionBranch(run,options.get(1));else s.right=null;if(options.size()>2)s.third=expeditionBranch(run,options.get(2));
        return s;
    }
    private void drawExpedition(Canvas c){
        ExpeditionScene.Snapshot snapshot=expeditionSnapshot();H=Math.max(viewportH,ExpeditionScene.requiredHeight(snapshot,minimumTextSize()));
        ExpeditionRun run=shownExpedition();String portraitId=run==null?expeditionCompanion:run.companionId;GameStore.ExpeditionReward receipt=run==null?null:store.expeditionReward(run.id);if(receipt!=null)portraitId=receipt.discoveryId;
        final Catalog.CharacterItem portrait=Catalog.character(portraitId);
        ExpeditionScene.Layout rendered=expeditionScene.draw(c,new RectF(0,0,390,H),snapshot,store.resolvedLanguage(),minimumTextSize(),48,"",(canvas,box)->drawCompanion(canvas,portrait,box.centerX(),box.centerY(),Math.min(box.width(),box.height())*.30f,AvatarStyles.find(avatarStyle),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,loadout,presentedCosmetics()));
        H=Math.max(H,rendered.contentHeight);
        for(ExpeditionScene.Target target:rendered.targets){RectF box=target.bounds;int before=hits.size();hit(box.left,box.top,box.width(),box.height(),target.label,target.enabled?()->expeditionAction(target.id):null);if(hits.size()>before)hits.get(hits.size()-1).semanticId=target.id;}
    }
    private void expeditionAction(String action){savedAction(()->{
        ExpeditionRun run=shownExpedition();
        if(action.equals("expedition_back")){goRoot("adventure");return;}
        if(action.equals("expedition_odds")){go("expedition_odds");return;}
        if(action.equals("expedition_companion")&&run==null){String[] choices={"nova","miko","orbit"};int index=Arrays.asList(choices).indexOf(expeditionCompanion);for(int n=1;n<=choices.length;n++){String next=choices[Math.floorMod(index+n,choices.length)];if(store.ownsCharacter(next)){expeditionCompanion=next;notice(t(Catalog.character(next).nameKey));break;}}return;}
        if(action.equals("expedition_goal")&&run==null){ArrayList<String> owned=new ArrayList<>();for(Catalog.CharacterItem who:Catalog.CHARACTERS)if(store.ownsCharacter(who.id))owned.add(who.id);int current=owned.indexOf(expeditionTarget);if(expeditionGoal==ExpeditionRun.Goal.HOME){expeditionGoal=ExpeditionRun.Goal.COPIES;expeditionTarget=owned.get(0);}else if(current+1<owned.size())expeditionTarget=owned.get(current+1);else expeditionGoal=ExpeditionRun.Goal.HOME;return;}
        if(action.equals("expedition_start")&&run==null){ExpeditionRun created=store.beginExpedition(expeditionCompanion,expeditionGoal,expeditionGoal==ExpeditionRun.Goal.COPIES?expeditionTarget:ExpeditionCatalog.SOUVENIR_ID,UUID.randomUUID().toString());if(created!=null){contentScroll=0;actionGeneration++;hits.clear();}return;}
        if(run==null)return;
        if(action.equals("expedition_claim")){if(!run.claimed){if(store.claimExpedition(run.id)!=null){expeditionShowResult=true;contentScroll=0;sfx(AudioEngine.Sound.REVEAL);}}else{expeditionShowResult=false;goRoot("home");}return;}
        if(action.equals("expedition_continue")){startExpeditionPuzzle(run);return;}
        if(action.equals("expedition_skill")){for(ExpeditionCatalog.Option option:run.options())if(run.canUseSkill(option.id)){store.useExpeditionSkill(run.id,option.id);sfx(AudioEngine.Sound.SELECT);break;}actionGeneration++;hits.clear();return;}
        int choice=action.equals("expedition_left")?0:action.equals("expedition_right")?1:action.equals("expedition_third")?2:-1;
        if(choice>=0&&choice<run.options().size()){ExpeditionRun selected=store.chooseExpedition(run.id,run.options().get(choice).id);if(selected!=null)startExpeditionPuzzle(selected);}
    });}
    private void startExpeditionPuzzle(ExpeditionRun expedition){
        if(expedition==null||expedition.selectedOption()==null||!prepareAbandon())return;
        stopTimer();if(mode!=5&&!saveSession()){notice(t("commerce_save_error"));return;}
        if(restoreSessionFrom(expeditionPrefs)){goRoot("play");return;}
        String energyRun=reserveSessionEnergy(5,expedition.selectedOption().boardNumber);if(energyRun==null)return;
        mode=5;levelIndex=expedition.selectedOption().boardNumber;eventIndex=expedition.stage();eventPeriod=expedition.id;contentVersion=7;friendCode="";
        board=new Board(RelayCatalog.get(levelIndex));activeElapsed=activeStarted=0;hintsUsed=undos=xpReward=0;won=paused=false;flights.clear();hintId=-1;visionUntil=0;winAt=0;coachId=-1;resetMoveRun();
        runId=energyRun;puzzleReaction.reset();goRoot("play");if(!saveSession())powerSaveBlocked=true;
    }
    private void drawExpeditionOdds(Canvas c){
        header(c,x("odds"),x("one_discovery"));float y=prose(c,x("discovery_note"),184,skin.muted);y=prose(c,x("surplus_note"),y,skin.muted);for(SummonCatalog.Item item:SummonCatalog.items(SummonCatalog.Banner.AVATARS)){
            CompanionProgression.Definition def=CompanionProgression.find(item.id);fit(c,t(item.nameKey)+" · "+def.rarity.name(),28,y,18,330,TEXT,true,false);
            fit(c,x("chance",String.format(Locale.forLanguageTag(store.resolvedLanguage()),"%.2f",item.chanceBasisPoints/100f)),28,y+27,14,330,skin.muted,false,false);y+=85;
        }sceneAction(c,x("back"),24,y,342,()->backMenu());H=Math.max(viewportH,y+110);
    }
    private String flagGlyph(String code){
        if("WORLD".equals(code))return "◎";
        return new String(Character.toChars(0x1f1e6+code.charAt(0)-'A'))+new String(Character.toChars(0x1f1e6+code.charAt(1)-'A'));
    }
    private int badgeAccent(int index){return new int[]{0xffd79a31,0xff567fc7,0xff8b60bd,0xff278c76,0xffcf707f,0xff5688af}[Math.max(0,index)%6];}
    private int badgeIndex(String id){for(int i=0;i<BadgeCatalog.ITEMS.size();i++)if(BadgeCatalog.ITEMS.get(i).id.equals(id))return i;return 0;}
    private void playerRibbon(Canvas c,float x,float y,float width,float height,boolean clickable){
        sceneShelf(c,new RectF(x,y,x+width,y+height),0xffede9fa,true);
        premium.fit(c,flagGlyph(store.playerFlag()),x+27,y+43,24,42,PremiumUi.INK,false,true);
        fit(c,store.playerNickname(),x+57,y+29,20,width-135,TEXT,true,false);
        fit(c,d("player_card")+"  ›",x+57,y+height-15,12,width-135,PremiumUi.MUTED,false,false);
        List<String> badges=store.equippedBadges();for(int i=0;i<3;i++){String id=badges.get(i);premium.badge(c,x+width-30-i*27,y+height/2,11,id.isEmpty()?0xffc3bfd3:badgeAccent(badgeIndex(id)),id.isEmpty()?0:badgeIndex(id),!id.isEmpty());}
        if(clickable)hit(x,y,width,height,r("profile"),()->go("profile"));
    }
    private void editPlayerNickname(){
        showTextSheet(d("edit_nickname"),d("nickname_hint"),store.playerNickname(),android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,72,value->{
            String normalized=PlayerProfile.normalizeNickname(value);if(normalized.isEmpty())return d("nickname_error");
            try{if(store.setPlayerNickname(normalized)){notice(d("saved"));invalidate();return null;}return d("nickname_error");}catch(GameStore.LocalSaveException failure){if(sceneDialog!=null)sceneDialog.dismiss();blockLocalSave();return null;}
        });
    }
    private interface SceneTextCommit { String commit(String value); }
    private void showTextSheet(String title,String hint,String value,int inputType,int maxLength,SceneTextCommit commit){
        finishScenePresentation();android.widget.LinearLayout box=new android.widget.LinearLayout(getContext());box.setOrientation(android.widget.LinearLayout.VERTICAL);int pad=(int)(24*getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);
        android.graphics.drawable.GradientDrawable paper=new android.graphics.drawable.GradientDrawable();paper.setColor(0xfff9f3ff);paper.setCornerRadius(pad);box.setBackground(paper);
        android.widget.TextView heading=new android.widget.TextView(getContext());heading.setText(title);heading.setTextSize(23);heading.setTextColor(TEXT);heading.setTypeface(bold);box.addView(heading);
        android.widget.EditText field=new android.widget.EditText(getContext());field.setSingleLine(true);field.setText(value);field.setSelectAllOnFocus(true);field.setHint(hint);field.setTextColor(TEXT);field.setTextSize(19);field.setInputType(inputType);field.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);field.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(maxLength)});box.addView(field,new android.widget.LinearLayout.LayoutParams(-1,(int)(68*getResources().getDisplayMetrics().density)));
        android.widget.TextView note=new android.widget.TextView(getContext());note.setText(hint);note.setTextSize(13);note.setTextColor(PremiumUi.MUTED);box.addView(note);
        android.app.Dialog dialog=new android.app.Dialog(getContext());sceneDialog=dialog;dialog.setContentView(box);dialog.setCanceledOnTouchOutside(true);
        field.setOnEditorActionListener((view,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_DOWN&&event.getRepeatCount()==0){String error=commit.commit(field.getText().toString());if(error!=null)field.setError(error);else dialog.dismiss();return true;}return false;});
        dialog.setOnDismissListener(closed->{if(sceneDialog==dialog)sceneDialog=null;});dialog.show();android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));window.setLayout(Math.round((Math.min(390,getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density)-32)*getResources().getDisplayMetrics().density),android.view.ViewGroup.LayoutParams.WRAP_CONTENT);window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);}field.requestFocus();
    }
    private void drawPlayerProfile(Canvas c){
        header(c,r("profile"),d("local_profile"));
        hero121Scene.draw(c,new RectF(24,109,366,436),frameTime,reduceMotion,character.color);
        dressedMascot(c,195,260,79);label(34,130,322,280,equippedPortraitDescription());
        hero121Fit(c,store.playerNickname(),195,402,26,305,0xfff8f2ff,true,true);
        motionHit(new RectF(24,112,366,436),d("edit_nickname"),"profile_nickname",()->editPlayerNickname());
        int shownXp=(int)xpMotion121.sample(meta.xp(),frameTime,reduceMotion);
        round(c,24,451,342,113,25,0xffe5dcf5);fit(c,Menu121Strings.get(store.resolvedLanguage(),"player_level",1+shownXp/MetaProgress.XP_PER_RANK),44,485,23,300,TEXT,true,false);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"xp_progress",shownXp%MetaProgress.XP_PER_RANK,MetaProgress.XP_PER_RANK),44,512,15,300,TEXT,true,false);
        round(c,44,533,302,9,5,0xffcec1e3);float amount=(shownXp%MetaProgress.XP_PER_RANK)/(float)MetaProgress.XP_PER_RANK;if(amount>0)round(c,44,533,302*amount,9,5,0xff8a6cc1);
        motionHit(new RectF(24,451,366,564),Menu121Strings.get(store.resolvedLanguage(),"xp_rule")+". "+meta.xp()+" XP","profile_progression",()->go("economy"));
        modernAction(c,new RectF(24,582,366,638),a21("evolution"),0xffbfe9d9,"profile_evolution",()->go("evolution"),true);
        fit(c,d("choose_flag"),24,678,20,342,TEXT,true,false);
        for(int i=0;i<PlayerProfile.FLAGS.size();i++){final String flag=PlayerProfile.FLAGS.get(i);float x=24+(i%5)*69,y=698+(i/5)*67;boolean selected=flag.equals(store.playerFlag());
            scenic.selector(c,new RectF(x+12,y-3,x+52,y+39),selected?0xff9cb8cd:0xffb9afd0,selected,ScenicUi.Kind.FLAG);fit(c,flagGlyph(flag),x+32,y+27,21,49,TEXT,false,true);fit(c,flag.equals("WORLD")?d("world"):flag,x+32,y+54,11,60,TEXT,selected,true);
            hit(x,y-3,64,65,flag.equals("WORLD")?d("world"):flag,()->savedAction(()->{store.setPlayerFlag(flag);notice(d("saved"));}));
        }
        List<String> badges=store.equippedBadges();float badgeY=923;
        for(int i=0;i<3;i++){final int slot=i;String id=badges.get(i);float x=127+i*68;premium.badge(c,x,badgeY+27,22,id.isEmpty()?0xffbdb6d0:badgeAccent(badgeIndex(id)),badgeIndex(id),!id.isEmpty());hit(x-30,badgeY-5,60,70,d("badge_slot",i+1),()->{profileBadgeSlot=slot;go("badges");});}
        modernAction(c,new RectF(24,1011,366,1067),a21("loop"),0xffffe7bc,"profile_economy",()->go("economy"),true);
        twoLines(c,d("profile_note"),24,1092,342,13,PremiumUi.MUTED);H=Math.max(viewportH,1160);
    }
    private String badgeProgressText(BadgeCatalog.Item item){return d(item.metric==BadgeCatalog.Metric.LEVELS?"metric_levels":item.metric==BadgeCatalog.Metric.PLACED_ITEMS?"metric_placed":"metric_avatars",Math.min(item.requirement,store.badgeProgress(item.id)),item.requirement);}
    private void drawBadges(Canvas c){
        header(c,d("badges"),d("badge_slots"));List<String> worn=store.equippedBadges();
        for(int i=0;i<3;i++){final int slot=i;float x=24+i*116;String id=worn.get(i);scenic.selector(c,new RectF(x+20,110,x+90,180),0xffbba7d7,profileBadgeSlot==i,ScenicUi.Kind.MEDAL);premium.badge(c,x+55,146,20,id.isEmpty()?0xffbfbacf:badgeAccent(badgeIndex(id)),badgeIndex(id),!id.isEmpty());fit(c,"0"+(i+1),x+55,199,13,94,TEXT,profileBadgeSlot==i,true);hit(x,105,110,102,d("badge_slot",i+1),()->{profileBadgeSlot=slot;invalidate();});}
        for(int i=0;i<BadgeCatalog.ITEMS.size();i++){final BadgeCatalog.Item item=BadgeCatalog.ITEMS.get(i);float x=24+(i%2)*177,y=229+(i/2)*207;boolean earned=store.badgeUnlocked(item.id),selected=worn.contains(item.id);sceneShelf(c,new RectF(x,y,x+165,y+192),0xffd0b8cd,selected);premium.badge(c,x+82.5f,y+47,36,badgeAccent(i),i,earned);fit(c,d(item.nameKey),x+82.5f,y+106,15,145,TEXT,true,true);premium.copy(c,badgeProgressText(item),x+12,y+128,141,12,PremiumUi.MUTED,2);fit(c,d(selected?"equipped":earned?"badge_earned":"badge_locked"),x+82.5f,y+177,12,146,earned?0xff5c4a9c:PremiumUi.MUTED,true,true);hit(x,y,165,192,d(item.nameKey)+", "+badgeProgressText(item),()->{if(!store.badgeUnlocked(item.id)){notice(d("badge_locked"));return;}savedAction(()->{if(store.equipBadge(profileBadgeSlot,item.id)){notice(d("equipped"));go("profile");}});});}
        sceneAction(c,d("remove_badge"),24,866,342,()->savedAction(()->{store.equipBadge(profileBadgeSlot,"");go("profile");}));H=Math.max(viewportH,1015);
    }
    private SummonCatalog.Banner summonBanner(){return summonTab==0?SummonCatalog.Banner.AVATARS:SummonCatalog.Banner.SIGNATURES;}
    private String summonName(SummonCatalog.Item item){return item.kind==SummonCatalog.Kind.AVATAR?t(item.nameKey):d(item.nameKey);}
    private int summonAccent(SummonCatalog.Item item){return item.rarity==SummonCatalog.Rarity.EPIC?0xffb78236:item.rarity==SummonCatalog.Rarity.RARE?0xff8a62c0:0xff4b92b6;}
    private String summonRarity(SummonCatalog.Item item){return d(item.rarity==SummonCatalog.Rarity.EPIC?"rarity_epic":item.rarity==SummonCatalog.Rarity.RARE?"rarity_rare":"rarity_common");}
    private void drawSummonPortrait(Canvas c,SummonCatalog.Item item,float x,float y,float radius){
        if(item==null)return;List<CosmeticCatalog.Item> clothes=new ArrayList<>();
        if(item.kind==SummonCatalog.Kind.OUTFIT)for(String id:SignatureOutfits.find(item.outfitId).cosmeticIds){CosmeticCatalog.Item piece=CosmeticCatalog.find(id);if(piece!=null)clothes.add(piece);}
        drawCompanion(c,item.kind==SummonCatalog.Kind.AVATAR?Catalog.character(item.avatarId):character,x,y,radius,AvatarStyles.find("plush_classic"),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,null,clothes);
    }
    private void summonTabs(Canvas c){
        String[] names={d("companions_banner"),d("outfits_banner")};
        for(int i=0;i<2;i++){final int tab=i;float x=24+i*177;scenic.selector(c,new RectF(x+2,103,x+53,155),i==0?0xff9e9bd2:0xffcb9cc4,summonTab==i,i==0?ScenicUi.Kind.CAPSULE:ScenicUi.Kind.DUMMY);fit(c,names[i],x+59,134,13,106,TEXT,summonTab==i,false);int before=hits.size();hit(x,101,165,56,names[i],()->{summonTab=tab;summonPreview="";contentScroll=0;});if(hits.size()>before)hits.get(before).selected=summonTab==i;}
    }
    private void returnToMenu(String destination){nextSceneDirection=SceneTransition.Direction.BACK;while(!menuHistory.isEmpty()&&!menuHistory.peek().equals(destination))menuHistory.pop();if(!menuHistory.isEmpty())menuHistory.pop();navigatingBack=true;try{go(destination);}finally{navigatingBack=false;}}
    private void confirmSummon121(){int price=SummonCatalog.priceCoins(summonBanner());if(store.coins()<price){notice(d("summon_funds"));return;}confirmInScene(a21("draw_confirm",price),a21("draw_cost",store.coins()-price),()->performSummon());}
    private void performSummon(){
        final SummonCatalog.Banner banner=summonBanner();final String request=UUID.randomUUID().toString();summonRequest=request;
        savedAction(()->{GameStore.SummonResult result=store.drawSummon(banner,request);if(result==null){notice(d("summon_funds"));return;}summonPreview="";actionGeneration++;hits.clear();sfx(AudioEngine.Sound.PURCHASE);go("summon_reveal");});
    }
    private void drawSummon(Canvas c){
        header(c,d("summon"),d("summon_intro"));summonTabs(c);
        List<SummonCatalog.Item> pool=SummonCatalog.items(summonBanner());SummonCatalog.Item item=pool.get(pool.size()-1);
        sceneAura(c,new RectF(18,169,372,491),summonTab==0?0xff8b91cf:0xffbf9cc4,frameTime,reduceMotion);
        if(summonTab==0){drawSummonPortrait(c,pool.get(8),77,346,39);drawSummonPortrait(c,pool.get(15),313,346,39);}
        drawSummonPortrait(c,item,195,327,68);fit(c,d(summonTab==0?"companions_banner":"outfits_banner"),195,477,22,324,TEXT,true,true);
        twoLines(c,d(summonTab==0?"companions_detail":"outfits_detail"),24,503,342,14,PremiumUi.MUTED);
        scenic.object(c,new RectF(139,562,251,674),summonTab==0?0xff8c8fd2:0xffc29dc8,pressed!=null&&pressed.name.equals(d("summon_once",SummonCatalog.priceCoins(summonBanner()))),ScenicUi.Kind.CAPSULE);hit(100,555,190,162,d("summon_once",SummonCatalog.priceCoins(summonBanner())),()->confirmSummon121());if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="summon_draw";
        fit(c,d("summon_once",SummonCatalog.priceCoins(summonBanner())),195,706,16,342,TEXT,true,true);fit(c,d("earned_only"),195,732,12,342,PremiumUi.MUTED,false,true);
        sceneDestination(c,ScenicUi.Kind.BOOK,d("odds"),105,810,80,0xffb2a0d0,()->{summonPreview="";go("summon_pool");});
        if(store.lastSummonResult()!=null)sceneDestination(c,ScenicUi.Kind.CAPSULE,d("last_reveal"),285,810,80,0xffc5a7cd,()->{summonRequest=store.lastSummonRequestId();summonPreview="";go("summon_reveal");});
        H=Math.max(viewportH,940);
    }
    private void drawSummonPool(Canvas c){
        header(c,d("odds"),d(summonTab==0?"companions_banner":"outfits_banner"));summonTabs(c);
        premium.copy(c,d("odds_note"),24,186,342,14,PremiumUi.MUTED,3);
        List<SummonCatalog.Item> items=SummonCatalog.items(summonBanner());
        for(int i=0;i<items.size();i++){final SummonCatalog.Item item=items.get(i);float x=24+(i%2)*177,y=248+(i/2)*248;boolean owned=store.ownsSummonItem(item.id);sceneAura(c,new RectF(x,y,x+165,y+232),summonAccent(item),0,true);drawSummonPortrait(c,item,x+82.5f,y+70,37);fit(c,summonName(item),x+82.5f,y+160,16,147,TEXT,true,true);fit(c,summonRarity(item)+(owned?" · "+r("owned"):""),x+82.5f,y+182,12,147,PremiumUi.MUTED,true,true);
            String chance=String.format(Locale.forLanguageTag(store.resolvedLanguage()),"%.2f",item.chanceBasisPoints/100f);premium.copy(c,d("chance",chance,item.duplicateCoins),x+11,y+205,143,12,PremiumUi.MUTED,2);
            hit(x,y,165,232,summonName(item)+", "+chance+"%",()->{summonPreview=item.id;go("summon_reveal");});
        }
        H=Math.max(viewportH,248+(float)Math.ceil(items.size()/2f)*248+110);
    }
    private void drawSummonReveal(Canvas c){
        GameStore.SummonResult result=summonPreview.isEmpty()?store.summonReceipt(summonRequest):null;
        if(result==null&&summonPreview.isEmpty()){result=store.lastSummonResult();if(result!=null)summonRequest=result.requestId;}
        SummonCatalog.Item item=SummonCatalog.find(result!=null?result.itemId:summonPreview);if(item==null){go("summon");return;}
        final boolean preview=!summonPreview.isEmpty();String identity=(preview?"preview:":"receipt:")+(preview?summonPreview:result.requestId);
        if(!identity.equals(summonShown121)){summonShown121=identity;summonRevealAt121=frameTime;}
        long age=Math.max(0,frameTime-summonRevealAt121);boolean opening=!preview&&!reduceMotion&&age<660;
        header(c,preview?r("preview"):d(result.duplicate?"duplicate":"new_arrival"),summonRarity(item));
        hero121Scene.draw(c,new RectF(18,112,372,549),frameTime,reduceMotion,summonAccent(item));
        if(opening){float t=age/660f;shopArt.capsule(c,195,295,74+8*(float)Math.sin(t*Math.PI),frameTime,false);motionHit(new RectF(24,115,366,545),t("continue"),"summon_skip",()->{summonRevealAt121=frameTime-660;invalidate();});}
        else{
            int save=c.saveLayerAlpha(18,112,372,549,preview||reduceMotion?255:Math.round(Math.min(1,(age-660)/240f)*255));
            drawSummonPortrait(c,item,195,302,item.kind==SummonCatalog.Kind.OUTFIT?83:99);c.restoreToCount(save);
            hero121Fit(c,summonName(item),195,513,28,324,0xfffcf5ff,true,true);
        }
        String outcome=preview?(store.ownsSummonItem(item.id)?r("owned"):r("preview")):result.duplicate?d("duplicate_coins",result.compensationCoins):d("saved");
        fit(c,outcome,195,583,17,342,TEXT,true,true);float y=601;
        if(item.kind==SummonCatalog.Kind.AVATAR){CompanionProgression.Stats stats=store.companionStats(item.avatarId);String progress=Menu121Strings.get(store.resolvedLanguage(),"companion_level",Math.max(1,stats.level))+" · "+Menu121Strings.get(store.resolvedLanguage(),"copies_progress",stats.copies,stats.nextThreshold);fit(c,progress,195,y+24,14,342,TEXT,true,true);y+=47;}
        if(store.ownsSummonItem(item.id)){final String id=item.id;modernAction(c,new RectF(24,y,366,y+56),d("equip"),0xffc1eadd,"summon_equip",()->savedAction(()->{if(store.equipSummonItem(id)){notice(d("equipped"));syncStyle();}}),true);y+=73;}
        final boolean fromPreview=preview;
        modernAction(c,new RectF(24,y,366,y+56),preview?t("back"):d("back_banner"),0xffe3d7f4,"summon_done",()->{if(fromPreview)returnToMenu("summon_pool");else{summonRequest="";returnToMenu("summon");}},true);y+=75;
        y=prose(c,a21("draw_rule"),y,PremiumUi.MUTED);modernAction(c,new RectF(24,y+14,366,y+70),d("look_book"),0xffffe8bf,"summon_collection",()->goRoot("collection_hub"),true);summonRevealHeight121=y+102;H=Math.max(viewportH,summonRevealHeight121);
    }

    private void drawAtelier(Canvas c){
        drawScenery(c,"atelier");sceneHeading(c,r("atelier"),h("room_title"));
        SceneRootLayout positions=rootLayout();homeScene.drawItem(c,"sofa",sceneRect(positions.atelierSofaArt),frameTime,reduceMotion);
        sceneCaption(c,h("furniture")+" · "+HomeCatalog.ITEMS.size(),195,positions.atelierSofaBaseline,330,22);sceneHit(positions.atelierSofaHit,h("furniture"),()->{homeCatalogGroup=0;homeCatalogTab=0;go("home_catalog");});
        String[] names={r("stellar"),r("forest"),r("neon")};String[] ids={"aquarium","plant","arcade"};int[] colors={0xffa794d4,0xff8cb58d,0xffcf95bb};
        for(int i=0;i<3;i++){final int group=i;float x=68+i*127,yy=positions.atelierGroupY;homeScene.drawItem(c,ids[i],sceneRect(positions.atelierGroupArt[i]),frameTime,reduceMotion);sceneCaption(c,names[i],x,yy+66,117,14);sceneHit(positions.atelierGroupHit[i],names[i],()->{homeCatalogTab=0;homeCatalogGroup=group+1;go("home_catalog");});}
        sceneDestination(c,ScenicUi.Kind.BLUEPRINT,h("wallpaper"),positions.atelierWalls,0xffc8a1cd,()->{homeCatalogTab=1;homeCatalogGroup=0;go("home_catalog");});
        sceneDestination(c,ScenicUi.Kind.LEAF,h("floor"),positions.atelierFloor,0xff9cb898,()->{homeCatalogTab=2;homeCatalogGroup=0;go("home_catalog");});sceneSiblings(c);H=viewportH;
    }
    private void houseZoom(Canvas c,String glyph,String description,float x,float y,Runnable action){
        scenic.object(c,new RectF(x,y,x+48,y+48),0xff9c99c8,false,glyph.equals("+")?ScenicUi.Kind.ZOOM_IN:ScenicUi.Kind.ZOOM_OUT);hit(x,y,48,48,description,action);
    }
    private void switchHomeRoom(String room){
        savedAction(()->{if(!store.setHomeRoom(room))return;homeSelection="";homeDraft=null;homePath=Collections.emptyList();homeActivity="idle";homeUsingItem="";invalidate();});
    }
    private void drawPremiumHome(Canvas c){
        homeLayout=store.homeLayout();HomeLayout displayed=homeLayout;
        if(homeDecorating&&!homeSelection.isEmpty()){refreshHomeDraft();if(homeDraft!=null)displayed=homeDraft;}
        homeSceneTop=70;homeSceneHeight=Math.max(280,viewportH-100);homeSceneScale=1f;
        float sceneBottom=homeSceneTop+homeSceneHeight;homeToolbarTop=viewportH-(homeDecorating?174:112);
        homeScene.setViewport(390,homeSceneHeight);homeScene.setRoom(store.homeRoom());homeScene.setInteraction(homeUsingItem,homeScene.isLightOn(homeUsingItem));
        float[] position=homeVisualPosition();String activity=!homePath.isEmpty()?"walk":frameTime<homeActivityUntil?homeActivity:"idle";
        homeScene.setCompanionProfile(Math.max(1,store.companionStats(character.id).level),CompanionMotion.parseStance(store.companionStance(character.id)),homeFacing);
        int selection=-1;for(int i=0;i<displayed.placements().size();i++)if(displayed.placements().get(i).id.equals(homeSelection))selection=i;
        c.save();c.clipRect(0,homeSceneTop,390,sceneBottom);c.translate(0,homeSceneTop);
        homeScene.draw(c,0,displayed,store.homeWallpaper(),store.homeFloor(),character,AvatarStyles.find(avatarStyle),loadout,presentedCosmetics(),frameTime,reduceMotion,position[0],position[1],activity,selection,homeDecorating);
        if(homeInvalidPlacement){PointF point=homeScene.projectedFloorPoint(homeDraftX,homeDraftY);stroke(c,new RectF(point.x-20,point.y-12,point.x+20,point.y+12),5,0xffb64c6c,3);icon(c,"close",point.x,point.y,15,0xffb64c6c);}c.restore();
        sceneHeading(c,homeDecorating?h("decorate"):r("house"),h("room_"+store.homeRoom()));label(0,homeSceneTop,390,homeSceneHeight,h("scene_accessible"));
        if(!homeDecorating&&store.expeditionsCompleted()>0){int progress=store.expeditionHomeProgress();float yy=Math.min(homeToolbarTop-90,225);
            scenic.object(c,new RectF(304,yy,366,yy+63),progress>=GameStore.EXPEDITION_HOME_TARGET?0xffd4a14b:0xff9baac7,false,ScenicUi.Kind.MEDAL);
            fit(c,progress+" / "+GameStore.EXPEDITION_HOME_TARGET,335,yy+80,13,85,TEXT,true,true);hit(294,yy-5,82,95,x("souvenir_name")+". "+x("home_progress",progress,GameStore.EXPEDITION_HOME_TARGET),()->openExpedition());if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="expedition_souvenir";
        }
        for(HomeLayout.Placement item:homeLayout.placements()){
            RectF rect=new RectF();homeScene.projectedBoundsFor(item,rect);rect.offset(0,homeSceneTop);
            if(rect.intersect(0,homeSceneTop,390,homeToolbarTop)){
                float centerX=rect.centerX(),centerY=rect.centerY(),width=Math.max(36,rect.width()),height=Math.max(40,rect.height());
                rect.set(centerX-width/2,centerY-height/2,centerX+width/2,centerY+height/2);rect.intersect(0,homeSceneTop,390,homeToolbarTop);
                int before=hits.size();hit(rect.left,rect.top,rect.width(),rect.height(),hn(item.id),()->{if(homeDecorating)selectHomeItem(item.id);else homeUse(item);});if(hits.size()>before)hits.get(before).homeItem=true;
            }
        }
        if(!homeDecorating){PointF feet=homeScene.projectedFloorPoint(position[0],position[1]);float size=Math.min(390f/640f,homeSceneHeight/480f)*homeScene.cameraZoom();RectF body=new RectF(feet.x-35*size,homeSceneTop+feet.y-87*size,feet.x+35*size,homeSceneTop+feet.y+5*size);if(body.intersect(0,homeSceneTop,390,homeToolbarTop))hit(body.left,body.top,body.width(),body.height(),h("cuddle"),()->homeCuddle());}
        int roomIndex=0;for(String room:HomeCatalog.ROOMS){final String id=room;float lane=390f/HomeCatalog.ROOMS.size(),x=lane*(roomIndex+++.5f);
            homeScene.drawItem(c,room.equals("living")?"sofa":room.equals("bedroom")?"canopy_bed":room.equals("kitchen")?"kitchen":"greenhouse",new RectF(x-30,87,x+30,145),frameTime,reduceMotion);
            if(room.equals(store.homeRoom())){p.setColor(0xff70b5a5);c.drawCircle(x,156,2.8f,p);}
            sceneCaption(c,h("room_"+room),x,166,lane-8,12);motionHit(new RectF(x-lane/2+3,83,x+lane/2-3,173),h("room_"+room),"house_room_"+id,()->switchHomeRoom(id));
        }
        if(homeDecorating){
            float yy=viewportH-184;
            if(homeSelection.isEmpty()){
                sceneDestination(c,ScenicUi.Kind.BLUEPRINT,h("furniture"),123,yy+20,78,0xff8eacc2,()->{homeCatalogGroup=0;homeCatalogTab=0;go("home_catalog");});
                sceneDestination(c,ScenicUi.Kind.CONFIRM,h("done"),268,yy+20,78,0xff79b5a2,()->{homeDecorating=false;homeSelection="";homeDraft=null;});
            }else{
                sceneCaption(c,hn(homeSelection),195,yy-27,320,18);
                sceneDestination(c,ScenicUi.Kind.ROTATE,h("rotate"),65,yy+24,63,0xffaaa1d4,()->{homeDraftRotation=1-homeDraftRotation;refreshHomeDraft();});
                sceneDestination(c,ScenicUi.Kind.SATCHEL,h("remove"),195,yy+24,63,0xffd2a1b6,()->savedAction(()->{if(store.removeHomeItem(homeSelection)){homeSelection="";homeDraft=null;}}));
                sceneDestination(c,ScenicUi.Kind.CONFIRM,h("place"),325,yy+24,63,0xff74b59f,()->savedAction(()->{if(store.placeHomeItem(homeSelection,homeDraftX,homeDraftY,homeDraftRotation)){notice(h("placed"));homeSelection="";homeDraft=null;sfx(AudioEngine.Sound.SELECT);}else notice(h("placement_blocked"));}));
                sceneAction(c,t("cancel"),135,viewportH-83,120,()->{homeSelection="";homeDraft=null;});
            }
        }else{
            SceneRootLayout positions=rootLayout();
            sceneDestination(c,ScenicUi.Kind.BLUEPRINT,h("decorate"),positions.homeDecorate,0xff8bb7aa,()->startHomeDecorating());
            sceneDestination(c,ScenicUi.Kind.MIRROR,r("wardrobe"),positions.homeWardrobe,0xffb79ed0,()->go("wardrobe"));
            sceneSiblings(c);
        }
        H=viewportH;
    }
    private java.util.List<String> homeCatalogIds(){ArrayList<String> ids=new ArrayList<>();if(homeCatalogTab==0){String theme=homeCatalogGroup==1?"stellar":homeCatalogGroup==2?"forest":homeCatalogGroup==3?"neon":"";for(HomeCatalog.Item item:HomeCatalog.ITEMS)if(theme.isEmpty()||theme.equals(HomeCatalog.theme(item.id)))ids.add(item.id);}else for(HomeCatalog.Surface item:homeCatalogTab==1?HomeCatalog.WALLPAPERS:HomeCatalog.FLOORS)ids.add(item.id);return ids;}
    private void drawHomeCatalog(Canvas c){
        header(c,h("furniture"),h("room_title"));sceneAction(c,h("back"),24,103,342,()->go("home"));
        String[] categories={h("furniture"),h("wallpaper"),h("floor")};
        for(int i=0;i<3;i++){final int tab=i;float x=24+i*116;scenic.selector(c,new RectF(x+2,167,x+42,207),0xffaaa4cd,homeCatalogTab==i,i==0?ScenicUi.Kind.BLUEPRINT:i==1?ScenicUi.Kind.CLOTH_RAIL:ScenicUi.Kind.LEAF);fit(c,categories[i],x+47,198,12,62,TEXT,homeCatalogTab==i,false);int before=hits.size();hit(x,168,110,49,categories[i],()->{homeCatalogTab=tab;homeCatalogGroup=0;contentScroll=0;});if(hits.size()>before)hits.get(hits.size()-1).selected=i==homeCatalogTab;}
        java.util.List<String> catalogIds=homeCatalogIds();int count=catalogIds.size();H=Math.max(viewportH,239+(float)Math.ceil(count/2.0)*196+110);
        for(int i=0;i<count;i++){
            final String id=catalogIds.get(i);
            float x=24+(i%2)*177,y=239+(i/2)*196;boolean owned=store.ownsHomeItem(id);int price=HomeCatalog.price(id);
            sceneShelf(c,new RectF(x,y,x+165,y+179),owned?SweetUi.CREAM:SweetUi.LILAC,true);drawHomeObject(c,id,new RectF(x+26,y+5,x+139,y+94));
            fit(c,hn(id),x+82.5f,y+114,14,147,TEXT,true,true);fit(c,owned?h("owned"):h("price",price),x+82.5f,y+139,12,148,skin.muted,false,true);
            fit(c,a("preview")+"  →",x+82.5f,y+164,13,148,TEXT,true,true);
            hit(x,y,165,179,hn(id)+", "+(owned?h("owned"):h("price",price)),()->{homeDetail=id;go("home_item");});
        }
    }
    private void drawHomeObject(Canvas c,String id,RectF bounds){
        if(HomeCatalog.item(id)!=null){homeScene.drawItem(c,id,bounds,frameTime,reduceMotion);return;}
        HomeCatalog.Surface surface=HomeCatalog.surface(id);if(surface==null)return;
        round(c,bounds.left,bounds.top,bounds.width(),bounds.height(),18,surface.color);
        if(HomeCatalog.floor(id)!=null){for(int i=1;i<5;i++)round(c,bounds.left+5,bounds.top+i*bounds.height()/5,bounds.width()-10,1,1,surface.accent);}
        else{for(int row=0;row<3;row++)for(int col=0;col<4;col++)star(c,bounds.left+(col+.5f)*bounds.width()/4,bounds.top+(row+.5f)*bounds.height()/3,4,surface.accent);}
    }
    private void drawHomeItem(Canvas c){
        String id=homeDetail;if(!HomeCatalog.known(id)){go("home_catalog");return;}
        HomeCatalog.Item item=HomeCatalog.item(id);boolean owned=store.ownsHomeItem(id);int price=HomeCatalog.price(id);HomeLayout.Placement placement=item==null?null:store.homeLayout().placement(id);
        header(c,h("furniture"),h("room_title"));scenePaper(c,new RectF(24,108,366,359),SweetUi.CREAM,true);drawHomeObject(c,id,new RectF(76,119,314,331));
        fit(c,hn(id),24,398,24,342,TEXT,true,false);
        if(item!=null)wrap(c,HomeStrings.description(store.resolvedLanguage(),id),24,430,342,15,TEXT,false,22);
        String state=owned?placement!=null?h("placed"):h("owned"):h("price",price);
        fit(c,state,24,494,16,342,TEXT,true,false);label(24,377,342,126,hn(id)+", "+state);
        float y=521;
        if(!owned){
            objectAction(c,h("buy",price)+" LumaCoins",24,y,342,54,PEACH,()->savedAction(()->{if(store.purchaseHomeItem(id)){sfx(AudioEngine.Sound.PURCHASE);notice(h("owned"));}else notice(h("not_enough"));}));y+=74;
            if(item!=null){sceneAction(c,h(id.equals(store.homeGoal())?"clear_goal":"choose_goal"),24,y,342,()->savedAction(()->{store.setHomeGoal(id.equals(store.homeGoal())?"":id);notice(h("goal"));}));y+=65;}
            sceneAction(c,h("play"),24,y,342,()->continueGame());y+=65;
        }else{
            boolean applied=item==null&&(id.equals(store.homeWallpaper())||id.equals(store.homeFloor()));
            if(item!=null)objectAction(c,h("place"),24,y,342,54,PEACH,()->selectHomeItem(id));
            else if(!applied)objectAction(c,t("equip"),24,y,342,54,PEACH,()->savedAction(()->{if(HomeCatalog.wallpaper(id)!=null)store.setHomeWallpaper(id);else store.setHomeFloor(id);notice(h("placed"));}));
            else{scenePaper(c,new RectF(24,y,366,y+54),SweetUi.MINT,false);fit(c,e("equipped"),195,y+33,17,318,TEXT,true,true);label(24,y,342,54,e("equipped"));}
            y+=75;
        }
        sceneAction(c,h("back"),24,y,342,()->go("home_catalog"));sceneAction(c,h("room_title"),24,y+65,342,()->goRoot("home"));
    }
    private void finishFirstLight(){savedAction(()->{store.finishFirstLight();firstLight=null;goRoot("adventure");log("first_light_finish");});}
    private void firstLightMove(int id){savedAction(()->{
        if(firstLight==null||firstLight.isSolved())return;
        Board.MoveResult result=firstLight.move(id);if(!result.success){sfx(AudioEngine.Sound.BLOCKED);notice(h("first_gate"));return;}
        store.saveFirstLightHistory(FirstLight.history(firstLight));sfx(result.tile.isSwitch()?AudioEngine.Sound.GATE:AudioEngine.Sound.MOVE);
        practiceFlights.add(new Flight(result.tile,SystemClock.uptimeMillis(),59+(result.tile.col+.5f)*68,292+(result.tile.row+.5f)*68,directionColor(result.tile.direction)));
        if(result.tile.isSwitch())gatePulseUntil=SystemClock.uptimeMillis()+1700;
        if(firstLight.isSolved())sfx(AudioEngine.Sound.WIN);log("first_light_move","piece",""+id);
    });}
    private void drawFirstLight(Canvas c){
        if(firstLight==null)firstLight=FirstLight.restore(store.firstLightHistory());
        boolean solved=firstLight.isSolved();text(c,"LUMA DRIFT",24,47,26,TEXT,true);
        drawCompanion(c,character,195,133,35,AvatarStyles.find(avatarStyle),solved?AvatarStage.Pose.WIN:frameTime<gatePulseUntil?AvatarStage.Pose.GATE:AvatarStage.Pose.THINK,frameTime,reduceMotion,loadout,presentedCosmetics());
        fit(c,h(solved?"first_done":"first_title"),195,218,24,340,TEXT,true,true);wrap(c,h("first_note"),195,245,330,14,TEXT,true,21);
        float left=59,up=292,unit=68;
        scenePaper(c,new RectF(44,up-17,346,up+289),SweetUi.LILAC,true);
        for(int row=0;row<4;row++)for(int col=0;col<4;col++)round(c,left+col*unit+4,up+row*unit+4,unit-8,unit-8,14,0x55ffffff);
        for(Direction d:Direction.values()){float x=left+136+d.dc*145,y=up+136+d.dr*145;boolean open=firstLight.isGateOpen(d);round(c,x-(d.dc==0?20:8),y-(d.dc==0?8:20),d.dc==0?40:16,d.dc==0?16:40,7,open?SweetUi.light(SweetUi.MINT):PEACH);arrow(c,x,y,d,7,TEXT);}
        if(frameTime<gatePulseUntil){float gateX=left+281,gateY=up+136;stroke(c,new RectF(gateX-13,gateY-25,gateX+13,gateY+25),10,0xff428f81,2);p.setColor(0xff7db5a5);p.setStrokeWidth(2);for(int i=0;i<9;i++){float mix=i/9f;c.drawCircle(93+(gateX-93)*mix,462+(gateY-462)*mix,2,p);}}
        for(Tile tile:firstLight.remainingTiles()){
            float x=left+(tile.col+.5f)*unit,y=up+(tile.row+.5f)*unit;final int id=tile.id;
            sweet.tile(c,new RectF(x-26,y-26,x+26,y+26),tile.direction,directionColor(tile.direction),tile.isSwitch(),false,tile.id==0,frameTime,reduceMotion);
            hit(x-32,y-32,64,64,t("piece_description",tile.row+1,tile.col+1,t("direction_"+tile.direction.name().toLowerCase(Locale.ROOT))),()->firstLightMove(id));
        }
        for(Iterator<Flight> it=practiceFlights.iterator();it.hasNext();){Flight f=it.next();float progress=(frameTime-f.at)/(reduceMotion?90f:360f);if(progress>=1){it.remove();continue;}float distance=reduceMotion?0:progress*progress*220;c.saveLayerAlpha(0,0,390,H,(int)(255*(1-progress)));sweet.tile(c,new RectF(f.x-26+f.tile.direction.dc*distance,f.y-26+f.tile.direction.dr*distance,f.x+26+f.tile.direction.dc*distance,f.y+26+f.tile.direction.dr*distance),f.tile.direction,f.color,f.tile.isSwitch(),false,false,frameTime,reduceMotion);c.restore();}
        if(!solved)wrap(c,h("first_gate"),195,623,330,14,TEXT,true,22);
        else objectAction(c,h("first_home")+"  →",24,610,342,58,PEACH,()->finishFirstLight());
        sceneAction(c,h("first_skip"),24,700,342,()->finishFirstLight());
    }



    private void tinyTile(Canvas c,float x,float y,Direction d,int color){c.save();c.translate(x,y);c.rotate(reduceMotion?0:(float)Math.sin(frameTime*.001)*8);round(c,-19,-19,38,38,12,color);arrow(c,0,0,d,10,INK);c.restore();}



    private int difficultyColor(ProgressionInfo info){return info.difficulty==ProgressionInfo.Difficulty.EXPERT?0xffe7b2ff:info.difficulty==ProgressionInfo.Difficulty.HARD?PEACH:skin.accent2;}
    private void difficultyPill(Canvas c,ProgressionInfo info,float x,float y,float width){int color=difficultyColor(info);round(c,x,y,width,29,12,alpha(color,24));fit(c,e(info.difficultyKey)+" · "+e(info.beatKey),x+width/2,y+20,12,width-14,color,true,true);}
    private int cosmeticColor(CosmeticCatalog.Item item){String id=item.id;if(id.contains("pumpkin")||id.contains("witch"))return 0xffffb473;if(id.contains("cupid")||id.contains("valentine"))return 0xffffa9cf;if(id.contains("moon"))return 0xffb7b0ff;if(id.contains("star"))return GOLD;if(id.contains("aurora"))return 0xffa8dfff;return 0xff91e5cc;}

    private void dressedMascot(Canvas c,float x,float y,float r){
        drawCompanion(c,character,x,y,r,AvatarStyles.find(avatarStyle),screen.equals("play")?frameTime<gatePulseUntil?AvatarStage.Pose.GATE:frameTime<successUntil?AvatarStage.Pose.HAPPY:AvatarStage.Pose.THINK:AvatarStage.Pose.IDLE,frameTime,reduceMotion,loadout,presentedCosmetics());
    }

    private String cosmeticSource(CosmeticCatalog.Item item){String key=item.source==CosmeticCatalog.Source.LOGIN_DAYS?"source_login":item.source==CosmeticCatalog.Source.WEEKLY_WINS?"source_weekly":item.source==CosmeticCatalog.Source.EVENT_STARS?"source_event":item.source==CosmeticCatalog.Source.EARNED_COINS?"source_coins":"source_starter";return V17Strings.format(store.resolvedLanguage(),key,item.requirement);}
    private void drawWardrobe(Canvas c){
        header(c,r("wardrobe"),b("clothes_owned",store.ownedCosmeticCount(),24));
        sceneStage(c,new RectF(24,103,366,344),0xffad9dce);dressedMascot(c,195,222,59);label(64,104,262,245,equippedPortraitDescription());
        fit(c,t(character.nameKey),195,350,20,310,TEXT,true,true);
        tabs(c,a("appearance"),a("equipment"),wardrobeMode,374,()->{wardrobeMode=0;wardrobePage=0;},()->{wardrobeMode=1;wardrobePage=0;});
        int count=wardrobeMode==0?4:3;float width=342f/count;
        for(int i=0;i<count;i++){final int slot=i;float x=24+i*width;boolean active=wardrobeMode==0?wardrobeSlot==i:wardrobeGearSlot==i;String name=wardrobeMode==0?v(new String[]{"hat","dress","shoes","gloves"}[i]):g(AvatarGearCatalog.Slot.values()[i].key());
            RectF object=new RectF(x+width/2-25,437,x+width/2+25,484);
            if(wardrobeMode==0){CosmeticCatalog.Item first=null;for(CosmeticCatalog.Item item:CosmeticCatalog.ITEMS)if(item.slot==CosmeticCatalog.Slot.values()[i]){first=item;break;}if(first!=null)CharacterSprites.drawGarmentPreview(c,first,object.left,object.top,object.right,object.bottom);}
            else{scenic.selector(c,object,0xffa59bcc,active,i==0?ScenicUi.Kind.STARS:i==1?ScenicUi.Kind.LANTERN:ScenicUi.Kind.SHIELD);}
            if(active){p.setColor(0xffa799ce);c.drawOval(x+width/2-23,487,x+width/2+23,491,p);}
            fit(c,name,x+width/2,510,12,width-7,TEXT,active,true);int before=hits.size();hit(x,430,width,87,name,()->{if(wardrobeMode==0)wardrobeSlot=slot;else wardrobeGearSlot=slot;});if(hits.size()>before)hits.get(before).selected=active;
        }
        if(wardrobeMode==0){
            ArrayList<CosmeticCatalog.Item> items=new ArrayList<>();for(CosmeticCatalog.Item item:CosmeticCatalog.ITEMS)if(item.slot==CosmeticCatalog.Slot.values()[wardrobeSlot])items.add(item);
            for(int i=0;i<items.size();i++){CosmeticCatalog.Item item=items.get(i);float x=24+(i%3)*117,y=537+(i/3)*164;boolean owned=store.ownsCosmetic(item.id),on=!store.usesOriginalCompanionCostume()&&item.id.equals(store.equippedCosmetic(item.slot));
                sceneShelf(c,new RectF(x,y,x+108,y+141),0xffbdacc7,on);CharacterSprites.drawGarmentPreview(c,item,x+15,y+1,x+93,y+93);fit(c,w(item.nameKey),x+54,y+113,12,102,TEXT,on,true);fit(c,on?e("equipped"):owned?e("owned"):e("to_unlock"),x+54,y+134,11,102,PremiumUi.MUTED,false,true);hit(x,y,108,150,w(item.nameKey)+", "+(on?e("equipped"):owned?e("owned"):e("to_unlock")),()->cosmeticOffer(item));}
        }else{
            ArrayList<AvatarGearCatalog.Item> items=new ArrayList<>();for(AvatarGearCatalog.Item item:AvatarGearCatalog.ITEMS)if(item.slot==AvatarGearCatalog.Slot.values()[wardrobeGearSlot])items.add(item);
            for(int i=0;i<items.size();i++){AvatarGearCatalog.Item item=items.get(i);float x=24+(i%3)*117,y=537+(i/3)*164;boolean owned=store.ownsAvatarGear(item.id),on=item.id.equals(loadout.item(item.slot).id);sceneShelf(c,new RectF(x,y,x+108,y+141),0xffbdacc7,on);gearGlyph(c,item,x+54,y+44,31);fit(c,g(item.nameKey),x+54,y+113,12,102,TEXT,on,true);fit(c,on?e("equipped"):owned?e("owned"):e("to_unlock"),x+54,y+134,11,102,PremiumUi.MUTED,false,true);hit(x,y,108,150,g(item.nameKey),()->previewGear(item));}
        }
        String costumeLabel=x(store.usesOriginalCompanionCostume()?"motion_outfit_original":"motion_outfit_worn");
        RectF costumeButton=new RectF(24,887,366,941);
        scenic.objectAction(c,costumeButton,costumeLabel,SweetUi.LILAC,false,ScenicUi.Kind.MIRROR);
        motionHit(costumeButton,costumeLabel,"wardrobe_costume_toggle",()->savedAction(()->store.setUseOriginalCompanionCostume(!store.usesOriginalCompanionCostume())));
        sceneAction(c,r("companions"),24,979,165,()->{collectionTab=0;collectionPage=0;inventoryFilter=0;go("collection");});sceneAction(c,a("visual_styles"),201,979,165,()->go("styles"));H=Math.max(viewportH,1120);
    }
    private void drawWardrobeItem(Canvas c,CosmeticCatalog.Item item,float y){
        boolean owned=store.ownsCosmetic(item.id),on=!store.usesOriginalCompanionCostume()&&item.id.equals(store.equippedCosmetic(item.slot));sceneShelf(c,new RectF(24,y,366,y+116),0xffc5b2c7,on);
        CharacterSprites.drawGarmentPreview(c,item,30,y+9,104,y+102);fit(c,w(item.nameKey),113,y+29,18,235,TEXT,true,false);
        String state=on?e("equipped"):owned?e("owned"):e("to_unlock");fit(c,state+" · "+w(item.rarity.name().toLowerCase(Locale.ROOT)),113,y+53,12,235,owned?skin.accent2:skin.muted,true,false);fit(c,owned?v("cosmetic_only"):cosmeticSource(item),113,y+78,12,235,skin.muted,false,false);fit(c,on?e("equipped"):owned?e("action_equip"):item.priceCoins>0?item.priceCoins+" LumaCoins":store.cosmeticProgress(item.id)+" / "+item.requirement,113,y+102,12,235,GOLD,true,false);hit(24,y,342,116,w(item.nameKey)+", "+state+", "+cosmeticSource(item),()->cosmeticOffer(item));
    }
    private void wornCosmeticName(Canvas c,CosmeticCatalog.Item item,float x,float baseline){
        String name=w(item.nameKey);int separator=name.indexOf(" · ");if(separator>=0)name=name.substring(separator+3);
        p.setTypeface(regular);p.setTextSize(Math.max(12,minimumTextSize()));
        int space=name.indexOf(' ');
        if(space>0&&p.measureText(name)>62){
            fit(c,name.substring(0,space),x,baseline-6,12,62,skin.muted,false,true);
            fit(c,name.substring(space+1),x,baseline+8,12,62,skin.muted,false,true);
        }else fit(c,name,x,baseline,12,62,skin.muted,false,true);
    }
    private String equippedPortraitDescription(){
        StringJoiner items=new StringJoiner(", ");if(store.usesOriginalCompanionCostume())items.add(x("motion_outfit_original"));for(CosmeticCatalog.Item item:presentedCosmetics())items.add(w(item.nameKey));
        for(AvatarGearCatalog.Slot slot:AvatarGearCatalog.Slot.values())items.add(g(loadout.item(slot).nameKey));
        return b("portrait_current",t(character.nameKey),AvatarStyles.find(avatarStyle).name(store.resolvedLanguage()),items.toString());
    }
    private void showAppliedLook(String name,boolean showCompanion){
        if(showCompanion)go("wardrobe");else{contentScroll=0;actionGeneration++;hits.clear();}
        sfx(AudioEngine.Sound.SELECT);haptic();notice(b("look_applied",name));
    }
    private View companionPreview(Catalog.CharacterItem who,AvatarLoadout gear,List<CosmeticCatalog.Item> clothes){
        final AvatarStyles.Style style=AvatarStyles.find(avatarStyle);final ArrayList<CosmeticCatalog.Item> snapshot=new ArrayList<>(clothes);final boolean still=reduceMotion;
        View preview=new View(getContext()){
            @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);canvas.drawColor(0xfffff4fc);float r=Math.min(getWidth(),getHeight())/4.3f;drawCompanion(canvas,who,getWidth()/2f,getHeight()/2f,r,style,AvatarStage.Pose.HAPPY,SystemClock.uptimeMillis(),still,gear,snapshot);if(!still&&isAttachedToWindow())postInvalidateDelayed(50);}
            @Override protected void onMeasure(int width,int height){setMeasuredDimension(View.MeasureSpec.getSize(width),(int)(220*getResources().getDisplayMetrics().density));}
        };preview.setContentDescription(a("preview_only"));return preview;
    }
    private View cosmeticPreview(CosmeticCatalog.Item item){ArrayList<CosmeticCatalog.Item> clothes=new ArrayList<>(presentedCosmetics());clothes.add(item);return companionPreview(character,loadout,clothes);}
    private String acquisitionCaption(String source,String fallback){
        if(source==null||source.isEmpty())return a("source_account");
        if(source.equals("EARNED_CAPSULE"))return a("acquired_with",a("source_capsule"));
        if(source.equals("EARNED_SUMMON_"+SummonCatalog.VERSION))return a("acquired_with",d("summon"));
        if(source.equals("EARNED_COINS"))return a("acquired_with","LumaCoins");
        return a("acquired_with",fallback);
    }
    private void cosmeticOffer(CosmeticCatalog.Item item){openItem("cosmetic",item.id);}
    private void openCapsule(){capsuleRequest=UUID.randomUUID().toString();openItem("capsule","");}
    private void performCapsule(String receipt){savedAction(()->{
        GameStore.LootResult got=store.drawCosmeticLoot(receipt);if(got==null){notice(w("not_enough_coins"));return;}
        detailKind="cosmetic";detailId=got.itemId;detailMessage=got.duplicate?v("duplicate",got.compensationCoins):v("cosmetic_only");contentScroll=0;actionGeneration++;hits.clear();sfx(AudioEngine.Sound.PURCHASE);notice(detailMessage);
    });}
    private void claimJourneyGift(){
        try{String got=store.claimMilestoneLoot();syncStyle();if(got.isEmpty())notice(q("stock_full"));else{sfx(AudioEngine.Sound.COIN);showMenuGift(q("gifts"),t("loot_received",t("booster_"+got)),got);}}catch(IllegalStateException failed){notice(t("save_error"));}
    }
    private void claimTrial(String id){
        try{GameStore.PowerTrialStatus result=store.claimPowerTrial(id);syncStyle();if(result==GameStore.PowerTrialStatus.GRANTED){showMenuGift(t("booster_"+id),t("loot_received",t("booster_"+id)),id);sfx(AudioEngine.Sound.COIN);}else notice(result==GameStore.PowerTrialStatus.STORAGE_FULL?q("stock_full"):t("claimed"));}catch(IllegalStateException failure){notice(t("save_error"));}
    }

    private void selectRewardTab(int tab){rewardTab=tab;contentScroll=0;actionGeneration++;hits.clear();invalidate();}
    private void rewardTabs(Canvas c){
        String[] labels={a("today"),a("this_week"),a("journey_short"),a("rewards_all")};
        for(int i=0;i<4;i++){final int tab=i;float xx=24+i*86;boolean on=i==rewardTab;RectF area=new RectF(xx,100,xx+80,158);
            round(c,area.left,area.top,area.width(),area.height(),23,on?0xffe9dbf8:0xfff1edf7);fit(c,labels[i],area.centerX(),135,12,73,TEXT,on,true);
            int before=hits.size();motionHit(area,labels[i],"reward_tab_"+i,()->selectRewardTab(tab));if(hits.size()>before)hits.get(hits.size()-1).selected=on;}
    }
    /** Claimed rows are semantic text only: no enabled button or stale claim callback. */
    private void rewardGiftRow(Canvas c,float y,String title,String detail,String action,String power,boolean ready,boolean claimed,float progress,Runnable run){
        float height=Menu120Layout.rewardRowHeight(battleMinimumTouch());
        p.setColor(claimed?0xffeeeaf3:ready?0xfff2e5fa:0xfff1edf7);c.drawCircle(72,y+52,43,p);
        drawGiftIcon(c,72,y+54,claimed?47:57,claimed?0xffc9bfd6:ready?0xffd3afea:0xffd8cde4,claimed);
        if(power!=null&&!power.isEmpty())shopArt.power(c,power,72,y+48,18,frameTime,reduceMotion||claimed);
        if(claimed)center(c,"✓",104,y+26,20,0xff77a997,true);
        fit(c,title,132,y+29,18,230,TEXT,true,false);
        fit(c,detail,132,y+55,13,230,PremiumUi.MUTED,false,false);
        if(!claimed&&progress>=0){sweet.progress(c,new RectF(132,y+70,360,y+76),Math.max(0,Math.min(1,progress)),0xffbfded2);}
        label(24,y,342,85,title+". "+detail+". "+(claimed?m20("collected"):ready?m20("open_gift"):m20("in_progress")));
        if(claimed){fit(c,m20("collected"),132,y+111,14,225,0xff6d9085,true,false);}
        else{modernAction(c,new RectF(132,y+88,360,y+88+Math.max(48,battleMinimumTouch())),ready?m20("open_gift"):action,ready?0xfff5d594:0xffeee7f5,"reward_"+(power==null?"coins":power)+"_"+(int)y,run,true);}
        p.setColor(0xffeee8f3);c.drawRect(30,y+height-7,360,y+height-6,p);
    }
    private void drawQuestCard(Canvas c,float y,ObjectiveDashboard.Quest quest){
        String action=a(quest.kind==ObjectiveDashboard.QuestKind.EVENTS?quest.weekly?"play_weekly":"play_daily":"play_journey");
        rewardGiftRow(c,y,questTitle(quest),quest.progress+" / "+quest.target+"  ·  +"+quest.coins+" LumaCoins",action,null,Menu120Layout.canClaim(quest.ready,quest.claimed),quest.claimed,quest.progress/(float)quest.target,()->questRoute(quest));
    }
    private void drawRewards(Canvas c){
        ensureHub();ObjectiveDashboard.Snapshot dash=hubObjectives;header(c,m20("quests"),a("ready_count",dash.readyCount));rewardTabs(c);
        if(rewardTab==3){drawReadyRewards(c,dash);drawFixedNavigation(c);return;}
        float y=184,step=Menu120Layout.rewardRowHeight(battleMinimumTouch());
        if(rewardTab==2){
            int milestone=dash.nextMilestone;String gift=dash.journeyLootId;
            String detail=milestone==0?e("saga_complete"):q("gift_progress",Math.min(cachedCompleted,milestone),milestone,t("booster_"+gift));
            rewardGiftRow(c,y,q("gifts"),detail,a("play_journey"),gift,dash.journeyReady,milestone==0,milestone==0?1:Math.min(1,cachedCompleted/(float)milestone),()->{if(dash.journeyReady)collectJourneyGift(milestone);else continueJourney();});y+=step;
            for(ObjectiveDashboard.Trial trial:dash.trials){
                String info=trial.claimed?m20("collected"):trial.unlocked?q("trial",t(trial.nameKey)):e("power_unlock_at",trial.unlockLevel);
                rewardGiftRow(c,y,t(trial.nameKey),info,a("play_journey"),trial.id,Menu120Layout.canClaim(trial.ready,trial.claimed),trial.claimed,-1,()->{if(trial.ready)claimTrial(trial.id);else continueJourney();});y+=step;
            }
        }else{
            boolean weekly=rewardTab==1;
            if(!weekly){rewardGiftRow(c,y,v("login_day",dash.loginDay),"+"+dash.loginCoins+" LumaCoins",m20("open_gift"),null,dash.loginDailyReady,!dash.loginDailyReady,-1,()->claimLogin(dash.dayId));y+=step;}
            for(ObjectiveDashboard.Quest quest:weekly?dash.weeklyQuests:dash.dailyQuests){drawQuestCard(c,y,quest);y+=step;}
            boolean ready=weekly?dash.weeklyEventReady:dash.dailyEventReady,claimed=weekly?store.weeklyBonusClaimed():store.dailyBonusClaimed();
            int done=weekly?store.weeklyCompletedCount():store.dailyCompletedCount(),total=weekly?Catalog.WEEKLY_COUNT:Catalog.DAILY_COUNT;
            rewardGiftRow(c,y,t(weekly?"weekly":"daily")+" · "+t("bonus"),done+" / "+total+"  ·  +"+(weekly?250:100)+" LumaCoins",a(weekly?"play_weekly":"play_daily"),null,Menu120Layout.canClaim(ready,claimed),claimed,done/(float)total,()->{if(ready)claimEventBonus(!weekly,weekly?dash.weekId:dash.dayId);else{eventTab=weekly?1:0;go("events");}});y+=step;
        }
        H=Math.max(viewportH,y+Menu120Layout.NAV_RESERVE+20);drawFixedNavigation(c);
    }
    private void drawReadyRewards(Canvas c,ObjectiveDashboard.Snapshot dash){
        float y=184,step=Menu120Layout.rewardRowHeight(battleMinimumTouch());
        if(dash.loginDailyReady){rewardGiftRow(c,y,v("login_day",dash.loginDay),"+"+dash.loginCoins+" LumaCoins",m20("open_gift"),null,true,false,-1,()->claimLogin(dash.dayId));y+=step;}
        for(ObjectiveDashboard.Quest quest:dash.dailyQuests)if(quest.ready){rewardGiftRow(c,y,a("today")+" · "+questTitle(quest),"+"+quest.coins+" LumaCoins",m20("open_gift"),null,true,false,-1,()->claimQuest(quest));y+=step;}
        for(ObjectiveDashboard.Quest quest:dash.weeklyQuests)if(quest.ready){rewardGiftRow(c,y,a("this_week")+" · "+questTitle(quest),"+"+quest.coins+" LumaCoins",m20("open_gift"),null,true,false,-1,()->claimQuest(quest));y+=step;}
        if(dash.dailyEventReady){rewardGiftRow(c,y,t("daily")+" · "+t("bonus"),"+100 LumaCoins",m20("open_gift"),null,true,false,-1,()->claimEventBonus(true,dash.dayId));y+=step;}
        if(dash.weeklyEventReady){rewardGiftRow(c,y,t("weekly")+" · "+t("bonus"),"+250 LumaCoins",m20("open_gift"),null,true,false,-1,()->claimEventBonus(false,dash.weekId));y+=step;}
        if(dash.journeyReady){rewardGiftRow(c,y,q("gifts"),t("booster_"+dash.journeyLootId)+" · "+dash.nextMilestone,m20("open_gift"),dash.journeyLootId,true,false,-1,()->collectJourneyGift(dash.nextMilestone));y+=step;}
        for(ObjectiveDashboard.Trial trial:dash.trials)if(trial.ready){rewardGiftRow(c,y,t(trial.nameKey),q("trial",t(trial.nameKey)),m20("open_gift"),trial.id,true,false,-1,()->claimTrial(trial.id));y+=step;}
        if(dash.readyCount==0){drawGiftIcon(c,195,285,99,0xffcfbbdf,true);twoLines(c,a("all_claimed"),33,385,324,22,TEXT);modernAction(c,new RectF(24,468,366,526),a("today"),0xffe7dbf4,"reward_today",()->selectRewardTab(0),true);y=550;}
        H=Math.max(viewportH,y+Menu120Layout.NAV_RESERVE+20);
    }

    private void drawJourney(Canvas c){
        boolean remix=journeyTab==1;int total=remix?BalancedCatalog.REMIX_COUNT:BalancedCatalog.LEVEL_COUNT,unlocked=remix?store.remixUnlockedLevel():store.unlockedLevel();
        if(remix&&!store.remixAvailable()){header(c,e("nav_map"),t("remix_unlock"));tabs(c,t("journey"),t("remix"),journeyTab,101,()->{journeyTab=0;contentScroll=0;},()->{});sceneWindow(c,new RectF(24,170,366,520),0xfff7f0ff);dressedMascot(c,195,270,52);wrap(c,t("remix_unlock"),195,392,292,18,TEXT,true,25);sceneAction(c,t("continue"),44,449,302,()->previewLevel(Math.min(12,store.unlockedLevel()),0,0));return;}
        int first=SagaMap.firstVisible(contentScroll,total),last=SagaMap.lastVisible(contentScroll,viewportH,total);
        java.util.List<String> team=store.companionSquad();Catalog.CharacterItem captain=team.isEmpty()?character:Catalog.character(team.get(0));if(captain==null)captain=character;
        java.util.List<SocialClient.Friend> friends=SocialClient.cachedFriends(getContext());
        drawingMapNodes=true;c.save();c.clipRect(0,contentScroll+SagaMap.header(viewportH),390,contentScroll+viewportH-84);
        JourneyMapScene.terrain(c,contentScroll,viewportH,first,last,total,frameTime,reduceMotion);
        JourneyMapScene.route(c,first,last,unlocked,frameTime,reduceMotion);
        for(int n=first;n<=last;n++){
            final int number=n;float x=SagaMap.x(n),y=SagaMap.y(n);boolean open=n<=unlocked,current=n==unlocked;
            int stars=remix?store.remixStars(n):store.stars(n);ProgressionInfo info=remix?StrategyCatalog.info(n,true):RelayCatalog.info(n);int color=difficultyColor(info);
            JourneyMapScene.node(c,n,open,current,stars,color,frameTime,reduceMotion);
            if(open)center(c,""+n,x,y+7,20,TEXT,true);else{icon(c,"lock",x,y-7,14,0xff716b89);center(c,""+n,x,y+17,12,0xff716b89,true);}
            round(c,x-26,y+32,52,17,8,open?0xfafff8e8:0xdde8e4f2);
            for(int k=0;k<3;k++)star(c,x+(k-1)*15,y+40,6,k<stars?0xffd69c39:0xffc0b8cf);
            if(current){round(c,x-68,y+50,136,24,10,0xedfffaff);fit(c,JourneyMapStrings.get(store.resolvedLanguage(),"next"),x,y+66,12,125,TEXT,true,true);}
            if(info.keyCount>0){round(c,x-41,y-27,22,22,8,GOLD);p.setColor(INK);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(x-33,y-19,3.2f,p);c.drawLine(x-31,y-17,x-25,y-11,p);c.drawLine(x-27,y-13,x-24,y-16,p);p.setStyle(Paint.Style.FILL);}
            if(info.difficulty!=ProgressionInfo.Difficulty.NORMAL)star(c,x+29,y-26,9,color);
            int before=hits.size();hit(x-38,y-31,76,79,t("level_number",n)+", "+e(info.difficultyKey)+", "+e(info.elementKey)+", "+JourneyMapStrings.get(store.resolvedLanguage(),"stars",stars)+(current?", "+JourneyMapStrings.get(store.resolvedLanguage(),"next"):"")+(open?"":", "+t("locked")),()->{if(open)previewLevel(number,remix?3:0,0);else notice(t("unlock_previous"));});if(hits.size()>before)hits.get(hits.size()-1).semanticId="map_level_"+(remix?"remix_":"journey_")+n;
            if(!remix&&n%10==0){
                final int guardianNumber=n/10;float gx=x<195?314:76;boolean done=store.guardianCleared(guardianNumber),available=store.guardianUnlocked(guardianNumber);
                scenic.object(c,new RectF(gx-25,y-35,gx+25,y+14),done?0xffe9b76a:available?0xffaa89db:0xffaaa3bd,false,ScenicUi.Kind.KEY);
                fit(c,"G"+guardianNumber+(done?" ✓":""),gx,y+29,12,72,TEXT,true,true);
                hit(gx-31,y-34,62,72,q("guardian",guardianNumber)+", "+(done?q("guardian_done"):available?t("play"):q("guardian_locked",n)),()->{if(available)openGuardian(guardianNumber);else{storyChapter=(guardianNumber-1)/10+1;go("story");}});
            }
            boolean hasFriend=false;if(!remix)for(SocialClient.Friend friend:friends)if(friend.level==n){hasFriend=true;break;}
            if(current&&(remix||n%10!=0)&&!hasFriend){
                float ax=SagaMap.companionX(n);p.setColor(0x36ffffff);c.drawOval(ax-43,y+23,ax+43,y+44,p);
                drawCompanion(c,captain,ax,y-5,24,AvatarStyles.find(avatarStyle),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,captain.id.equals(character.id)?loadout:null,captain.id.equals(character.id)?presentedCosmetics():Collections.emptyList());
                round(c,ax-50,y+36,100,24,10,0xedfffaff);fit(c,v19("squad")+"  ›",ax,y+53,12,92,TEXT,true,true);
                motionHit(new RectF(ax-48,y-53,ax+48,y+58),v19("team_title")+". "+battleFamily(captain.id),"map_current_squad",()->openSquad());
            }
            if(!remix){int i=0;for(SocialClient.Friend friend:friends)if(friend.level==n&&i++<2){float fx=x+(x<195?59:-59),fy=y+(i-1)*29;scenic.object(c,new RectF(fx-22,fy-18,fx+22,fy+18),0xffb8a1ef,false,ScenicUi.Kind.PROFILE);fit(c,friend.nickname,fx,fy+5,12,44,INK,true,true);hit(fx-25,fy-14,50,28,friend.nickname+", "+t("level_number",n),()->openSocial());}}
        }
        drawingMapNodes=false;c.restore();c.save();c.translate(0,contentScroll);float old=drawingScroll;drawingScroll=0;
        if(viewportH<500){
            round(c,0,0,390,58,0,0xfffbf7ff);fit(c,e("nav_map"),17,25,18,112,TEXT,true,false);fit(c,t(remix?"remix":"journey"),17,46,12,112,skin.accent2,true,false);
            hit(5,0,122,57,t("journey")+" / "+t("remix"),()->{journeyTab=1-journeyTab;contentScroll=SagaMap.scrollTo(journeyTab==1?store.remixUnlockedLevel():store.unlockedLevel(),viewportH,journeyTab==1?BalancedCatalog.REMIX_COUNT:BalancedCatalog.LEVEL_COUNT);});
            sceneAction(c,v("current_level"),131,6,112,()->contentScroll=SagaMap.scrollTo(unlocked,viewportH,total));sceneAction(c,v("jump"),250,6,116,()->jumpMap(total));
        }else{
            int visible=SagaMap.at(contentScroll+(SagaMap.header(viewportH)+viewportH-84)*.5f,total),sector=SagaMap.sectorStart(visible),sectorEnd=SagaMap.sectorEnd(visible,total);
            round(c,0,0,390,194,0,0xfffbf7ff);round(c,19,11,5,72,2,JourneyMapScene.ink(visible));
            fit(c,e("nav_map"),35,34,25,244,TEXT,true,false);
            fit(c,worldName(visible),35,57,15,244,JourneyMapScene.ink(visible),true,false);
            fit(c,JourneyMapStrings.get(store.resolvedLanguage(),"world",SagaMap.biome(visible)+1,sector,sectorEnd)+"  ·  "+unlocked+" / "+total,35,77,12,244,PremiumUi.MUTED,false,false);
            drawCompanion(c,captain,337,46,23,AvatarStyles.find(avatarStyle),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,captain.id.equals(character.id)?loadout:null,captain.id.equals(character.id)?presentedCosmetics():Collections.emptyList());
            motionHit(new RectF(289,3,385,95),v19("team_title")+". "+battleFamily(captain.id),"map_header_squad",()->openSquad());
            fit(c,JourneyMapStrings.get(store.resolvedLanguage(),"squad"),35,95,12,338,JourneyMapScene.ink(visible),true,false);
            tabs(c,t("journey"),t("remix"),journeyTab,100,()->{journeyTab=0;contentScroll=SagaMap.scrollTo(store.unlockedLevel(),viewportH,BalancedCatalog.LEVEL_COUNT);},()->{journeyTab=1;contentScroll=SagaMap.scrollTo(store.remixUnlockedLevel(),viewportH,BalancedCatalog.REMIX_COUNT);});
            modernAction(c,new RectF(24,145,137,193),JourneyMapStrings.get(store.resolvedLanguage(),"current"),0xffe2d8f4,"map_current",()->contentScroll=SagaMap.scrollTo(unlocked,viewportH,total),true);modernAction(c,new RectF(149,145,249,193),JourneyMapStrings.get(store.resolvedLanguage(),"jump"),0xffd7ece8,"map_jump",()->jumpMap(total),true);modernAction(c,new RectF(261,145,366,193),JourneyMapStrings.get(store.resolvedLanguage(),"journal"),0xffffe8c0,"map_story",()->go("story"),true);
        }
        drawingScroll=old;c.restore();drawFixedNavigation(c);
    }
    private void jumpMap(int total){showTextSheet(v("jump"),v("jump_note")+" · 1–"+total,"",android.text.InputType.TYPE_CLASS_NUMBER,4,value->{try{int number=Integer.parseInt(value);if(number<1||number>total)return "1–"+total;contentScroll=SagaMap.scrollTo(number,viewportH,total);invalidate();return null;}catch(NumberFormatException invalid){return "1–"+total;}});}
    private void previewLevel(int index,int m,int event){
        if(m==3&&(!store.remixAvailable()||index>store.remixUnlockedLevel())){notice(t("remix_unlock"));return;}
        if(m==0&&!store.isLevelUnlocked(index)){notice(t("unlock_previous"));return;}
        briefingIndex=index;briefingMode=m;briefingEvent=event;
        briefingLevel=m==0?RelayCatalog.get(index):m==3?StrategyCatalog.remix(index):StrategyCatalog.event(m==1?store.dailySeed(event):store.weeklySeed(event));
        briefingReturn=screen.equals("play")?m==0||m==3?"journey":"events":screen;if(screen.equals("play")){menuHistory.clear();menuHistory.push(briefingReturn);}go("briefing");
    }
    private void drawBriefing(Canvas c){
        if(briefingLevel==null){go("adventure");return;}
        sceneAction(c,"‹  "+t("back"),24,18,100,()->backMenu());
        String briefingTitle=briefingMode==0?t("level_number",briefingIndex):briefingMode==3?t("remix")+" "+briefingIndex:t(briefingMode==1?"daily":"weekly")+" · "+t("stage_number",briefingEvent+1);
        fit(c,briefingTitle,195,112,30,330,TEXT,true,true);
        float stageH=Math.min(300,Math.max(190,viewportH-425));sceneStage(c,new RectF(24,148,366,148+stageH),PremiumUi.LILAC);
        float size=Math.min(208,stageH-40),unit=size/briefingLevel.size,left=(390-size)/2,top=168+(stageH-40-size)/2;
        for(Tile tile:briefingLevel.tiles)drawTile(c,tile,left+(tile.col+.5f)*unit,top+(tile.row+.5f)*unit,unit-5,false);
        LearningGuide.Context rule=lesson(new Board(briefingLevel));float y=174+stageH;
        fit(c,l(rule.titleKey),195,y,20,330,TEXT,true,true);wrap(c,l(rule.descriptionKey,rule.descriptionArgs),195,y+30,320,14,PremiumUi.MUTED,true,21);
        objectAction(c,t("play")+"  →",24,Math.min(viewportH-96,y+119),342,56,PEACH,()->start(briefingIndex,briefingMode,briefingEvent));if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="briefing_play";
    }
    private void tabs(Canvas c,String a,String b,int tab,float y,Runnable aa,Runnable bb){
        scenic.selector(c,new RectF(35,y-4,91,y+42),0xffaaa3cd,tab==0,ScenicUi.Kind.BOOK);
        scenic.selector(c,new RectF(208,y-4,264,y+42),0xff94b8b2,tab==1,ScenicUi.Kind.STARS);
        fit(c,a,98,y+26,14,92,TEXT,tab==0,false);fit(c,b,271,y+26,14,95,TEXT,tab==1,false);
        int before=hits.size();hit(24,y-3,171,50,a,aa);if(hits.size()>before)hits.get(before).selected=tab==0;
        before=hits.size();hit(195,y-3,171,50,b,bb);if(hits.size()>before)hits.get(before).selected=tab==1;
    }
    private String g(String key,Object...args){return GearStrings.get(store.resolvedLanguage(),key,args);}
    private void drawLoadout(Canvas c,float r,int shape){
        int head=AvatarGearCatalog.ITEMS.indexOf(loadout.item(AvatarGearCatalog.Slot.HEAD))%6;
        int aura=AvatarGearCatalog.ITEMS.indexOf(loadout.item(AvatarGearCatalog.Slot.AURA))%6;
        int charm=AvatarGearCatalog.ITEMS.indexOf(loadout.item(AvatarGearCatalog.Slot.CHARM))%6;
        int color=aura<2?skin.accent2:aura<4?PEACH:GOLD;
        p.setColor(alpha(color,90));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(r*.035f);c.drawOval(-r*1.25f,-r*1.13f,r*1.25f,r*1.12f,p);p.setStyle(Paint.Style.FILL);
        for(int i=0;i<3+aura;i++){double angle=i*Math.PI*2/(3+aura)+(reduceMotion?0:frameTime*.00015);star(c,(float)Math.cos(angle)*r*1.21f,(float)Math.sin(angle)*r*1.12f,r*.055f,color);}
        float y=shape==3?-r*1.52f:-r*.88f;
        if(head==0){companionLine(c,0,y,0,y-r*.25f,skin.accent2,r*.07f);companionOval(c,-r*.02f,y-r*.38f,r*.23f,y-r*.16f,skin.accent2);}
        else if(head==1){companionPolygon(c,skin.accent2,-r*.4f,y,0,y-r*.42f,r*.34f,y-r*.08f);}
        else if(head==2){p.setColor(GOLD);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(r*.11f);c.drawArc(-r*.31f,y-r*.35f,r*.31f,y+r*.07f,35,285,false,p);p.setStyle(Paint.Style.FILL);}
        else if(head==3){companionPolygon(c,GOLD,-r*.62f,y,-r*.65f,y-r*.31f,-r*.27f,y-r*.08f,0,y-r*.4f,r*.28f,y-r*.08f,r*.65f,y-r*.31f,r*.62f,y);}
        else if(head==4){round(c,-r*.76f,y-r*.08f,r*1.52f,r*.24f,r*.08f,skin.accent2);star(c,0,y,r*.14f,WHITE);}
        else{for(int sign:new int[]{-1,1}){companionLine(c,sign*r*.4f,y,sign*r*.67f,y-r*.58f,GOLD,r*.1f);companionLine(c,sign*r*.56f,y-r*.31f,sign*r*.91f,y-r*.37f,skin.accent2,r*.08f);}}
        float xx=r*.76f,yy=r*.72f;companionLine(c,xx,yy-r*.13f,xx,yy+r*.16f,GOLD,r*.035f);
        if(charm%3==0)icon(c,"heart",xx,yy+r*.2f,r*.3f,charm>=3?GOLD:PEACH);else if(charm%3==1)star(c,xx,yy+r*.2f,r*.17f,charm>=3?GOLD:skin.accent2);else{p.setColor(charm>=3?GOLD:skin.accent);c.drawCircle(xx,yy+r*.2f,r*.14f,p);}
    }
    private void gearGlyph(Canvas c,AvatarGearCatalog.Item item,float x,float y,float r){companionPortrait.drawGearGlyph(c,item,x,y,r);}

    private void drawCollection(Canvas c){
        boolean chars=collectionTab==0,gear=collectionTab==2,powers=collectionTab==3;
        java.util.List<InventoryPresentation.Entry> all=powers?Collections.emptyList():chars?InventoryPresentation.companions(store):gear?InventoryPresentation.gear(store,(AvatarGearCatalog.Slot)null):InventoryPresentation.themes(store);
        header(c,r("collection"),powers?r("powers"):e("collection_count",InventoryPresentation.counts(all).owned,all.size()));
        String[] categories={e("tab_companions"),e("tab_themes"),e("tab_equipment"),e("tab_powers")};ScenicUi.Kind[] kinds={ScenicUi.Kind.PROFILE,ScenicUi.Kind.COMPASS,ScenicUi.Kind.SHIELD,ScenicUi.Kind.SATCHEL};
        for(int i=0;i<4;i++){final int tab=i;float x=24+i*86;scenic.selector(c,new RectF(x+20,101,x+62,144),0xffaa9fca,collectionTab==i,kinds[i]);fit(c,categories[i],x+41,161,12,80,TEXT,collectionTab==i,true);int before=hits.size();hit(x,99,82,69,categories[i],()->{collectionTab=tab;collectionPage=0;inventoryFilter=0;});if(hits.size()>before)hits.get(before).selected=collectionTab==i;}
        String[] filters=chars?new String[]{e("filter_all"),e("filter_owned"),e("filter_locked"),x("guest_series")}:new String[]{e("filter_all"),e("filter_owned"),e("filter_locked")};ScenicUi.Kind[] filterKinds={ScenicUi.Kind.EYE,ScenicUi.Kind.SATCHEL,ScenicUi.Kind.KEY,ScenicUi.Kind.STARS};
        for(int i=0;i<filters.length;i++){final int filter=i;float width=chars?86:116,x=24+i*width;scenic.selector(c,new RectF(x+width*.5f-18,179,x+width*.5f+18,215),0xff9db6b4,inventoryFilter==i,filterKinds[i]);fit(c,filters[i],x+width*.5f,235,11,width-5,TEXT,inventoryFilter==i,true);int before=hits.size();hit(x,177,width-4,64,filters[i],()->{inventoryFilter=filter;collectionPage=0;});if(hits.size()>before)hits.get(before).selected=inventoryFilter==i;}
        if(chars&&inventoryFilter==3){ArrayList<InventoryPresentation.Entry> guests=new ArrayList<>();for(InventoryPresentation.Entry entry:all)if(entry.id.startsWith("lol_"))guests.add(entry);all=guests;}
        if(powers){drawPowerInventory(c);return;}
        InventoryPresentation.Filter filter=inventoryFilter==1?InventoryPresentation.Filter.OWNED:inventoryFilter==2?InventoryPresentation.Filter.LOCKED:InventoryPresentation.Filter.ALL;
        java.util.List<InventoryPresentation.Entry> shown=InventoryPresentation.filter(all,filter);InventoryPresentation.Page page=InventoryPresentation.page(shown.size(),chars?4:6,collectionPage);collectionPage=page.page;
        for(int i=0;i<page.size();i++){InventoryPresentation.Entry entry=shown.get(page.first-1+i);float x=24+(i%2)*177,y=250+(i/2)*(chars?248:148);boolean selected=entry.selected(),owned=entry.owned();sceneShelf(c,new RectF(x,y,x+165,y+(chars?232:136)),0xffc5b0c8,selected);
            if(chars)sceneAura(c,new RectF(x,y,x+165,y+204),selected?0xff72b2a5:0xffa99acb,frameTime,reduceMotion);
            if(gear)gearGlyph(c,entry.gear,x+82,y+43,32);
            else if(chars)drawCompanion(c,Catalog.character(entry.id),x+82,y+90,42f,AvatarStyles.find(avatarStyle),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,null,Collections.emptyList());
            else{Catalog.SkinItem theme=Catalog.skin(entry.id);scenic.object(c,new RectF(x+43,y+7,x+122,y+83),theme.accent,false,ScenicUi.Kind.COMPASS);}
            String title=gear?g(entry.nameKey):t(entry.nameKey);fit(c,title,x+82,y+(chars?196:103),16,149,TEXT,true,true);fit(c,e(entry.stateKey()),x+82,y+(chars?220:125),12,149,owned?PremiumUi.INDIGO:PremiumUi.MUTED,false,true);
            hit(x,y,165,chars?232:136,title+", "+e(entry.stateKey()),()->{if(gear)previewGear(entry.gear);else previewCosmetic(chars,chars?characterIndex(entry.id):themeIndex(entry.id));});
        }
        if(shown.isEmpty())wrap(c,e("collection_empty"),195,363,294,18,TEXT,true,25);H=Math.max(viewportH,905);inventoryPager(c,page);
    }
    private int characterIndex(String id){for(int i=0;i<Catalog.CHARACTERS.length;i++)if(Catalog.CHARACTERS[i].id.equals(id))return i;return 0;}
    private int themeIndex(String id){for(int i=0;i<Catalog.SKINS.length;i++)if(Catalog.SKINS[i].id.equals(id))return i;return 0;}
    private void inventoryPager(Canvas c,InventoryPresentation.Page page){if(page.pageCount<=1)return;float y=H-151;sceneAction(c,"‹",24,y,62,()->{if(page.hasPrevious())collectionPage--;});fit(c,e("saga_page",page.page+1,page.pageCount),195,y+29,14,190,TEXT,true,true);sceneAction(c,"›",304,y,62,()->{if(page.hasNext())collectionPage++;});}
    private void drawPowerInventory(Canvas c){
        HashSet<String> active=new HashSet<>();for(Catalog.BoosterItem item:Catalog.BOOSTERS)if(board!=null&&powerActive(item.id))active.add(item.id);
        ArrayList<InventoryPresentation.Power> shown=new ArrayList<>();for(InventoryPresentation.Power power:InventoryPresentation.powers(store,active))if(inventoryFilter==0||inventoryFilter==1&&power.unlocked&&(power.stock>0||power.active)||inventoryFilter==2&&!power.unlocked)shown.add(power);
        InventoryPresentation.Page page=InventoryPresentation.page(shown.size(),6,collectionPage);collectionPage=page.page;
        for(int i=0;i<page.size();i++){InventoryPresentation.Power power=shown.get(page.first-1+i);float x=24+(i%2)*177,y=250+(i/2)*148;sceneShelf(c,new RectF(x,y,x+165,y+136),power.active?PremiumUi.MINT:PremiumUi.PAPER,false);shopArt.power(c,power.id,x+82,y+41,32,frameTime,reduceMotion);fit(c,t(power.nameKey),x+82,y+94,16,149,TEXT,true,true);fit(c,power.unlocked?e("power_stock",power.stock):e("power_unlock_at",power.unlockLevel),x+82,y+119,12,149,PremiumUi.MUTED,false,true);hit(x,y,165,136,t(power.nameKey),()->powerOffer(power.id));}
        if(shown.isEmpty())wrap(c,e("collection_empty"),195,363,294,18,TEXT,true,25);H=Math.max(viewportH,905);inventoryPager(c,page);
    }
    private String shortGearSource(AvatarGearCatalog.Item item){
        String source=item.source==AvatarGearCatalog.Source.JOURNEY_CLEARS?t("journey"):item.source==AvatarGearCatalog.Source.WEEKLY_WINS?t("weekly"):item.source==AvatarGearCatalog.Source.EVENT_STARS?t("events"):g(item.source.key());
        return source+" · "+Math.min(item.requirement,gearProgress.value(item.source))+"/"+item.requirement;
    }
    private void previewGear(AvatarGearCatalog.Item item){openItem("gear",item.id);}
    private void previewCosmetic(boolean chars,int index){openItem(chars?"character":"theme",chars?Catalog.CHARACTERS[index].id:Catalog.SKINS[index].id);}
    /** Ordinary scrollable item page: looking never grants, spends or equips an item. */
    private void openItem(String kind,String id){
        boolean fromPlay=screen.equals("play");if(!screen.equals("item"))detailParent=navParent();
        detailKind=kind;detailId=id;detailMessage="";detailHeight=1100;go("item");if(fromPlay)menuHistory.push("play");
    }
    private float prose(Canvas c,String value,float y,int color){
        float size=Math.max(14,minimumTextSize()),line=size+8;p.setTypeface(regular);p.setTextSize(size);int lines=0;
        for(String paragraph:value.split("\\n",-1)){String row="";for(String word:paragraph.split(" ")){if(!row.isEmpty()&&p.measureText(row+" "+word)>302){lines++;row="";}row+=row.isEmpty()?word:" "+word;}lines++;}
        wrap(c,value,44,y,302,size,color,false,line);label(44,y-size,302,lines*line+4,value);return y+lines*line+14;
    }
    private void dualWallet(Canvas c,float y){
        Long gold=displayedGold;
        String amount=gold==null?"—":String.valueOf(gold),state=gold==null?z("gold_unloaded"):z("gold_last");
        for(int i=0;i<2;i++){float x=i==0?24:202;sceneAura(c,new RectF(x,y,x+164,y+76),i==0?0xffe0bd7b:0xffb9a2dc,frameTime,true);}
        shopArt.coin(c,47,y+37,14,frameTime,true);shopArt.gold(c,225,y+37,14,frameTime,true);
        fit(c,"LumaCoins",70,y+20,12,112,TEXT,true,false);fit(c,String.valueOf(store.coins()),70,y+46,21,110,TEXT,true,false);
        fit(c,"LumaGold",248,y+20,12,108,TEXT,true,false);fit(c,amount,248,y+46,20,102,TEXT,true,false);
        fit(c,v("earned"),70,y+65,12,108,skin.muted,false,false);fit(c,z(gold==null?"gold_short":"gold_cached_short"),248,y+65,12,108,skin.muted,false,false);
        hit(24,y,164,76,"LumaCoins: "+store.coins()+". "+z("coins_note"),()->{shopCategory=0;if(!screen.equals("shop"))go("shop");});
        hit(202,y,164,76,"LumaGold: "+amount+". "+state,()->{shopCategory=2;if(!screen.equals("shop"))go("shop");else selectShopCategory(2);});
    }
    private void drawCompanion(Canvas canvas,Catalog.CharacterItem who,float xPos,float yPos,float radius,AvatarStyles.Style style,AvatarStage.Pose pose,long time,boolean still,AvatarLoadout gear,List<CosmeticCatalog.Item> clothes){
        Catalog.CharacterItem actor=who==null?character:who;
        CompanionMotion.Stance stance=CompanionMotion.parseStance(store.companionStance(actor.id));
        CompanionMotion.Action action=pose==AvatarStage.Pose.HAPPY||pose==AvatarStage.Pose.WIN?CompanionMotion.Action.HAPPY:pose==AvatarStage.Pose.THINK?CompanionMotion.Action.THINK:pose==AvatarStage.Pose.GATE?CompanionMotion.Action.SURPRISE:CompanionMotion.Action.STANCE;
        CompanionMotion.Frame motion=CompanionMotion.sample(actor.id,Math.max(1,store.companionStats(actor.id).level),action,CompanionMotion.Facing.FRONT,stance,time,still);
        companionPortrait.draw(canvas,actor,xPos,yPos,radius,style,pose,time,still,gear,clothes,motion);
    }
    private void motionHit(RectF bounds,String label,String id,Runnable action){int before=hits.size();hit(bounds.left,bounds.top,bounds.width(),bounds.height(),label,action);if(hits.size()>before)hits.get(hits.size()-1).semanticId=id;}
    private String motionPoseName(int index){
        String[] names={"front","back","left","right","walk","walk","walk","walk","jump","land","hug","crouch","happy","sad","surprise","think"};
        if(index>=16)return x("stance_"+CompanionMotion.Stance.values()[index-16].name().toLowerCase(Locale.ROOT));
        return x("motion_"+names[index])+(index>=4&&index<8?" · "+x("motion_"+names[index-4]):"");
    }
    private void drawCompanionMotion(Canvas c){
        Catalog.CharacterItem who=Catalog.character(detailId);if(who==null)who=character;final Catalog.CharacterItem actor=who;
        H=Math.max(viewportH,1000);header(c,x("motion_gallery"),t(who.nameKey));
        int milestone=CompanionMotion.formLevel(motionPreviewForm),level=Math.max(1,store.companionStats(who.id).level);
        boolean owned=store.ownsCharacter(who.id);
        int renderedLevel=owned&&motionPreviewForm==CompanionMotion.formForLevel(level)?level:milestone;
        boolean preview=!owned||renderedLevel!=level;
        fit(c,x("evolution_form",motionPreviewForm+1),195,158,22,342,TEXT,true,true);
        if(preview)twoLines(c,x("motion_preview",renderedLevel),24,170,342,14,skin.muted);
        else fit(c,x("level",renderedLevel),195,188,14,342,skin.muted,false,true);
        sceneAura(c,new RectF(24,210,366,540),SweetUi.MINT,frameTime,reduceMotion);
        CompanionMotion.Action action=motionPreviewPose<4?CompanionMotion.Action.IDLE:motionPreviewPose<8?CompanionMotion.Action.WALK:motionPreviewPose==8?CompanionMotion.Action.JUMP:motionPreviewPose==9?CompanionMotion.Action.LAND:motionPreviewPose==10?CompanionMotion.Action.HUG:motionPreviewPose==11?CompanionMotion.Action.CROUCH:motionPreviewPose==12?CompanionMotion.Action.HAPPY:motionPreviewPose==13?CompanionMotion.Action.SAD:motionPreviewPose==14?CompanionMotion.Action.SURPRISE:motionPreviewPose==15?CompanionMotion.Action.THINK:CompanionMotion.Action.STANCE;
        CompanionMotion.Facing facing=CompanionMotion.Facing.values()[motionPreviewPose<8?motionPreviewPose%4:0];
        CompanionMotion.Stance stance=motionPreviewPose>=16?CompanionMotion.Stance.values()[motionPreviewPose-16]:CompanionMotion.parseStance(store.companionStance(who.id));
        CompanionMotion.Frame motion=CompanionMotion.sample(who.id,renderedLevel,action,facing,stance,frameTime,reduceMotion);
        companionPortrait.draw(c,who,195,375,71,AvatarStyles.find(avatarStyle),AvatarStage.Pose.IDLE,frameTime,reduceMotion,motionPreviewWearables?loadout:null,motionPreviewWearables?wornCosmetics:Collections.emptyList(),motion);
        fit(c,motionPoseName(motionPreviewPose),195,562,20,342,TEXT,true,true);
        fit(c,x("pose_index",motionPreviewPose+1),195,591,14,342,skin.muted,false,true);
        RectF previous=new RectF(24,330,78,390),next=new RectF(312,330,366,390);
        scenic.object(c,previous,SweetUi.LILAC,false,ScenicUi.Kind.RETURN);scenic.object(c,next,SweetUi.PEACH,false,ScenicUi.Kind.COMPASS);
        motionHit(previous,x("previous_pose"),"motion_previous",()->{motionPreviewPose=Math.floorMod(motionPreviewPose-1,20);invalidate();});
        motionHit(next,x("next_pose"),"motion_next",()->{motionPreviewPose=(motionPreviewPose+1)%20;invalidate();});
        for(int form=0;form<4;form++){final int chosen=form;float xx=59+form*91;RectF tab=new RectF(xx-36,612,xx+36,704);if(form==motionPreviewForm)sceneAura(c,tab,SweetUi.MINT,0,true);CompanionMotion.Frame thumb=CompanionMotion.sample(who.id,CompanionMotion.formLevel(form),CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,CompanionMotion.Stance.CALM,0,true);companionPortrait.draw(c,who,xx,650,17,AvatarStyles.find(avatarStyle),AvatarStage.Pose.IDLE,0,true,null,Collections.emptyList(),thumb);fit(c,String.valueOf(CompanionMotion.formLevel(form)),xx,702,14,65,TEXT,form==motionPreviewForm,true);motionHit(tab,x("evolution_form",form+1)+" · "+x("level",CompanionMotion.formLevel(form)),"motion_form_"+form,()->{motionPreviewForm=chosen;invalidate();});}
        fit(c,x("stance_label"),195,728,20,342,TEXT,true,true);
        CompanionMotion.Stance selected=CompanionMotion.parseStance(store.companionStance(who.id));
        for(int stanceIndex=0;stanceIndex<4;stanceIndex++){final CompanionMotion.Stance chosen=CompanionMotion.Stance.values()[stanceIndex];float xx=59+stanceIndex*91;RectF tab=new RectF(xx-36,746,xx+36,848);if(chosen==selected)sceneAura(c,tab,SweetUi.MINT,0,true);CompanionMotion.Frame thumb=CompanionMotion.sample(who.id,milestone,CompanionMotion.Action.STANCE,CompanionMotion.Facing.FRONT,chosen,0,true);companionPortrait.draw(c,who,xx,783,17,AvatarStyles.find(avatarStyle),AvatarStage.Pose.IDLE,0,true,null,Collections.emptyList(),thumb);fit(c,x("stance_"+chosen.name().toLowerCase(Locale.ROOT)),xx,840,12,84,TEXT,chosen==selected,true);motionHit(new RectF(xx-43,740,xx+43,850),x("stance_"+chosen.name().toLowerCase(Locale.ROOT)),"motion_stance_"+chosen.name().toLowerCase(Locale.ROOT),()->savedAction(()->{motionPreviewPose=16+chosen.ordinal();if(store.ownsCharacter(actor.id))store.setCompanionStance(actor.id,chosen.name());invalidate();}));}
        String outfitLabel=x(motionPreviewWearables?"motion_outfit_worn":"motion_outfit_original");
        RectF outfitButton=new RectF(24,872,366,920);
        scenic.objectAction(c,outfitButton,outfitLabel,SweetUi.LILAC,false,ScenicUi.Kind.MIRROR);
        motionHit(outfitButton,outfitLabel,"motion_outfit_toggle",()->{motionPreviewWearables=!motionPreviewWearables;invalidate();});
        label(24,210,342,390,t(who.nameKey)+". "+motionPoseName(motionPreviewPose)+". "+(preview?x("motion_preview",renderedLevel):x("level",renderedLevel))+". "+outfitLabel);
    }
    private void drawItemDetail(Canvas c){
        scenic.object(c,new RectF(24,20,72,68),0xffb5a7ca,false,ScenicUi.Kind.RETURN);hit(24,20,48,48,t("back"),()->backMenu());
        fit(c,a("preview"),91,51,22,270,TEXT,true,false);dualWallet(c,86);
        Catalog.BoosterItem power=detailKind.equals("power")?Catalog.booster(detailId):null;
        CosmeticCatalog.Item cloth=detailKind.equals("cosmetic")?CosmeticCatalog.find(detailId):null;
        AvatarGearCatalog.Item gear=detailKind.equals("gear")?AvatarGearCatalog.find(detailId):null;
        Catalog.CharacterItem who=detailKind.equals("character")?Catalog.character(detailId):null;
        Catalog.SkinItem theme=detailKind.equals("theme")?Catalog.skin(detailId):null;
        boolean capsule=detailKind.equals("capsule");
        if(power==null&&cloth==null&&gear==null&&who==null&&theme==null&&!capsule){sceneAction(c,t("close"),24,210,342,()->backMenu());return;}
        String name=power!=null?t(power.nameKey):cloth!=null?w(cloth.nameKey):gear!=null?g(gear.nameKey):who!=null?t(who.nameKey):theme!=null?t(theme.nameKey):v("loot");
        fit(c,name,195,185,25,342,TEXT,true,true);
        sceneAura(c,new RectF(24,205,366,447),capsule?SweetUi.LILAC:SweetUi.MINT,frameTime,reduceMotion);
        if(power!=null)shopArt.power(c,power.id,195,323,77,frameTime,reduceMotion);
        else if(capsule)shopArt.capsule(c,195,323,76,frameTime,reduceMotion);
        else if(theme!=null){round(c,106,246,178,150,55,theme.bg);for(int i=0;i<4;i++)round(c,124+(i%2)*78,268+(i/2)*54,64,41,20,i%2==0?theme.accent:theme.accent2);}
        else{
            ArrayList<CosmeticCatalog.Item> clothes=new ArrayList<>(presentedCosmetics());if(cloth!=null){clothes.removeIf(it->it.slot==cloth.slot);clothes.add(cloth);}
            AvatarLoadout preview=gear==null?loadout:new AvatarLoadout(gear.slot==AvatarGearCatalog.Slot.HEAD?gear.id:loadout.headId,gear.slot==AvatarGearCatalog.Slot.AURA?gear.id:loadout.auraId,gear.slot==AvatarGearCatalog.Slot.CHARM?gear.id:loadout.charmId);
            drawCompanion(c,who==null?character:who,195,323,58,AvatarStyles.find(avatarStyle),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,preview,clothes);
        }
        label(24,205,342,242,a("preview_only")+". "+name);
        float y=prose(c,a("preview_only"),477,skin.muted);
        if(!detailMessage.isEmpty())y=prose(c,detailMessage,y,TEXT);
        if(power!=null){
            boolean unlocked=store.boosterUnlocked(power.id);int stock=store.boosterStock(power.id);
            y=prose(c,unlocked?t("stock")+": "+stock:t("power_unlock",power.unlockLevel),y,TEXT);
            y=prose(c,t(power.descriptionKey),y,skin.muted);
            if(!Catalog.isPowerOffered(power.id))y=prose(c,l("shield_unneeded"),y,TEXT);
            if(unlocked&&Catalog.isPowerOffered(power.id)){
                if(stock<=store.boosterStockLimit()-power.amount){final String id=power.id;objectAction(c,t("power_buy",power.amount,store.boosterPrice(id)),24,y,342,54,PEACH,()->savedAction(()->{if(store.purchaseBooster(id)){sfx(AudioEngine.Sound.PURCHASE);notice(t("purchase_success"));}else notice(t("not_enough"));}));y+=72;}
                else y=prose(c,q("stock_full"),y,TEXT);
                if(stock<store.boosterStockLimit()){final String id=power.id;sceneAction(c,t("power_ad"),24,y,342,()->getContext().startActivity(com.androidhit.lumadrift.commerce.CommerceActivity.powerIntent(getContext(),id)));y+=65;}
            }
        }else if(capsule){
            y=prose(c,w("capsule_note"),y,TEXT);y=prose(c,w("capsule_odds"),y,skin.muted);y=prose(c,w("capsule_item_odds"),y,skin.muted);y=prose(c,w("capsule_duplicates"),y,skin.muted);
            objectAction(c,v("open_capsule"),24,y,342,54,PEACH,()->performCapsule(capsuleRequest));y+=73;
        }else{
            final boolean owned=cloth!=null?store.ownsCosmetic(cloth.id):gear!=null?store.ownsAvatarGear(gear.id):who!=null?store.ownsCharacter(who.id):store.ownsSkin(theme.id);
            final boolean equipped=cloth!=null?!store.usesOriginalCompanionCostume()&&cloth.id.equals(store.equippedCosmetic(cloth.slot)):gear!=null?gear.id.equals(loadout.item(gear.slot).id):who!=null?who.id.equals(store.equippedCharacter()):theme.id.equals(store.equippedSkin());
            String key=cloth!=null?"cosmetic:"+cloth.id:gear!=null?"gear:"+gear.id:"";
            y=prose(c,e(equipped?"equipped":owned?"owned":"to_unlock"),y,TEXT);
            if(who!=null){CompanionProgression.Definition definition=CompanionProgression.find(who.id);CompanionProgression.Stats stats=store.companionStats(who.id);
                y=prose(c,x("rarity",definition.rarity.name())+" · "+x("level",Math.max(1,stats.level)),y,TEXT);
                y=prose(c,stats.maxed()?"Lv. 10":x("copies",stats.copies,stats.nextThreshold),y,skin.muted);
                if(who.id.startsWith("lol_"))y=prose(c,x("guest_series_note"),y,skin.muted);y=prose(c,x("progression_rule"),y,skin.muted);y=prose(c,definition.skill==CompanionProgression.Skill.NONE?x("skill_none"):x(expeditionSkillKey(who.id))+". "+expeditionSkillDetail(who.id),y,TEXT);
                final String visualId=who.id;sceneAction(c,x("motion_gallery"),24,y,342,()->{detailId=visualId;motionPreviewPose=16+CompanionMotion.parseStance(store.companionStance(visualId)).ordinal();motionPreviewForm=CompanionMotion.formForLevel(Math.max(1,store.companionStats(visualId).level));motionPreviewWearables=false;go("companion_motion");});y+=72;
                if(owned){final String companionId=who.id;sceneAction(c,x("expedition"),24,y,342,()->{expeditionTarget=companionId;expeditionGoal=ExpeditionRun.Goal.COPIES;if(CompanionProgression.expeditionAvailable(companionId))expeditionCompanion=companionId;openExpedition();});y+=72;}
            }else y=prose(c,gear!=null?gear.blockedGrace>0?l("blocked_free"):GearStrings.effectCaption(store.resolvedLanguage(),gear):v("cosmetic_only"),y,skin.muted);
            if(cloth!=null)y=prose(c,owned?acquisitionCaption(store.cosmeticAcquisitionSource(cloth.id),cosmeticSource(cloth)):cosmeticSource(cloth),y,skin.muted);
            if(gear!=null)y=prose(c,GearStrings.sourceCaption(store.resolvedLanguage(),gear,gearProgress),y,skin.muted);
            int price=cloth!=null?cloth.priceCoins:gear!=null?gear.priceCoins:who!=null?who.price:theme.price;
            boolean direct=cloth!=null?cloth.priceCoins>0:gear!=null?gear.source==AvatarGearCatalog.Source.EARNED_COINS:true;
            if(!equipped&&(owned||direct)){
                String action=owned?e("action_equip"):price+" LumaCoins";
                objectAction(c,action,24,y,342,54,PEACH,()->savedAction(()->{
                    if(!owned){boolean bought=cloth!=null?store.purchaseCosmetic(cloth.id):gear!=null?store.purchaseAvatarGear(gear.id):who!=null?store.purchaseCharacter(who.id):store.purchaseSkin(theme.id);
                        if(!bought){notice(t("not_enough"));return;}sfx(AudioEngine.Sound.PURCHASE);notice(e("owned"));actionGeneration++;hits.clear();return;}
                    boolean applied=cloth!=null?store.equipCosmetic(cloth.id):gear!=null?store.equipAvatarGear(gear.id):who!=null?store.equipCharacter(who.id):store.equipSkin(theme.id);
                    if(applied)showAppliedLook(name,theme==null);else notice(b("item_unavailable"));
                }));y+=73;
            }else if(!owned){sceneAction(c,a("view_source"),24,y,342,()->{
                if(cloth!=null){if(cloth.source==CosmeticCatalog.Source.LOGIN_DAYS)openRewards(0);else{eventTab=cloth.source==CosmeticCatalog.Source.WEEKLY_WINS?1:0;go("events");}}
                else if(gear!=null)sourceRoute(gear.source==AvatarGearCatalog.Source.JOURNEY_CLEARS?CollectionGoal.Route.JOURNEY:gear.source==AvatarGearCatalog.Source.WEEKLY_WINS?CollectionGoal.Route.WEEKLY:gear.source==AvatarGearCatalog.Source.EVENT_STARS?CollectionGoal.Route.DAILY:CollectionGoal.Route.REWARDS);
            });y+=65;}
            if(!key.isEmpty()){final String goalKey=key;sceneAction(c,a(key.equals(store.trackedCollectionGoal())?"untrack_item":"track_item"),24,y,342,()->toggleGoal(goalKey));y+=65;}
        }
        sceneAction(c,t("close"),24,y,342,()->backMenu());detailHeight=Math.max(840,y+170);H=Math.max(viewportH,detailHeight);
    }

    private void selectShopCategory(int category){shopCategory=category;contentScroll=0;actionGeneration++;hits.clear();invalidate();}
    private void drawShop(Canvas c){
        round(c,0,0,390,1200,0,0xfff7f4fc);fit(c,m20("shop"),24,43,30,342,TEXT,true,false);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),"coins_role"),24,68,12,342,0xff74618e,false,false);
        String[] tabs={m20("shop_tab_powers"),m20("shop_tab_looks"),m20("shop_tab_gold")};
        for(int i=0;i<3;i++){final int category=i;float xx=24+i*116;boolean on=shopCategory==i;RectF area=new RectF(xx,88,xx+110,146);
            round(c,xx,88,110,58,21,on?0xff715496:0xffeae3f3);hero121Fit(c,tabs[i],area.centerX(),123,13,100,on?0xfffffaff:TEXT,true,true);int before=hits.size();motionHit(area,tabs[i],"shop_category_"+i,()->selectShopCategory(category));if(hits.size()>before)hits.get(hits.size()-1).selected=on;
        }
        round(c,24,161,342,44,16,shopCategory==2?0xffe9e1f5:0xffffefd0);if(shopCategory==2)shopArt.gold(c,48,183,14,frameTime,reduceMotion);else shopArt.coin(c,48,183,14,frameTime,reduceMotion);
        fit(c,Menu121Strings.get(store.resolvedLanguage(),shopCategory==2?"gold_role":"coins_loop"),72,188,12,278,0xff6b4d6f,true,false);
        motionHit(new RectF(24,155,366,211),Menu121Strings.get(store.resolvedLanguage(),"economy_route"),"shop_economy",()->go("economy"));
        RectF feature=new RectF(24,220,366,516);hero121Scene.draw(c,feature,frameTime,reduceMotion,0xffb5a5e4);
        if(shopCategory==0){
            ArrayList<Catalog.BoosterItem> offered=new ArrayList<>();for(Catalog.BoosterItem power:Catalog.BOOSTERS)if(Catalog.isPowerOffered(power.id))offered.add(power);
            if(offered.isEmpty()){H=shopContentHeight120=Math.max(viewportH,400);drawFixedNavigation(c);return;}
            shopPage=Math.max(0,Math.min(offered.size()-1,shopPage));Catalog.BoosterItem item=offered.get(shopPage);String id=item.id;boolean unlocked=store.boosterUnlocked(id);
            hero121Fit(c,Menu121Strings.get(store.resolvedLanguage(),"shop_powers"),195,245,11,302,0xffdfd7f6,true,true);hero121Fit(c,t(item.nameKey),195,276,24,302,0xfffffaff,true,true);
            shopArt.power(c,id,195,378,76,frameTime,reduceMotion);
            drawShopCarouselControls(c,shopPage,offered.size(),()->{shopPage=(shopPage+offered.size()-1)%offered.size();invalidate();},()->{shopPage=(shopPage+1)%offered.size();invalidate();});
            fit(c,unlocked?u("stock",store.boosterStock(id)):t("power_level",item.unlockLevel),195,543,13,342,0xff755d89,true,true);twoLines(c,z("power_"+id),33,566,324,15,TEXT);
            modernAction(c,new RectF(24,618,366,682),unlocked?"×"+item.amount+"  ·  "+Menu121Strings.get(store.resolvedLanguage(),"coin_price",store.boosterPrice(id)):t("power_unlock",item.unlockLevel),unlocked?0xffffd78e:0xffe8e0f2,"shop_power_preview",()->powerOffer(id),true);
            modernAction(c,new RectF(24,700,366,760),a("open_inventory")+" →",0xffe7dbf4,"shop_inventory",()->{collectionTab=3;collectionPage=0;go("collection");},true);
            modernAction(c,new RectF(24,778,366,838),Menu121Strings.get(store.resolvedLanguage(),"earn_coins")+" →",0xffd5ede0,"shop_free_gifts",()->openRewards(2),true);H=Math.max(viewportH,Menu121Layout.SHOP_CONTENT_HEIGHT);
        }else if(shopCategory==1){
            ArrayList<CosmeticCatalog.Item> items=new ArrayList<>();for(CosmeticCatalog.Item item:CosmeticCatalog.ITEMS)if(item.priceCoins>0)items.add(item);
            int total=items.size()+2;shopLookPage=Math.max(0,Math.min(total-1,shopLookPage));String name,price,status,kind;Runnable inspect;
            if(shopLookPage<2){
                boolean friends=shopLookPage==0;name=friends?m20("shop_arrivals"):a("appearance");price=Menu121Strings.get(store.resolvedLanguage(),"coin_price",SummonCatalog.priceCoins(friends?SummonCatalog.Banner.AVATARS:SummonCatalog.Banner.SIGNATURES));
                status=Menu121Strings.get(store.resolvedLanguage(),friends?"evolve_by_copies":"look_only");kind=Menu121Strings.get(store.resolvedLanguage(),friends?"companion_draw":"outfit_draw");
                shopArt.capsule(c,195,380,65,frameTime,reduceMotion);
                if(friends){drawBattleActor(c,"miko",new RectF(48,320,140,447),CompanionMotion.Action.HAPPY,CompanionMotion.Facing.RIGHT,frameTime,reduceMotion);drawBattleActor(c,"orbit",new RectF(250,320,342,447),CompanionMotion.Action.HAPPY,CompanionMotion.Facing.LEFT,frameTime,reduceMotion);}
                else{for(int i=0;i<3;i++)star(c,100+i*95,371+(i%2)*24,9,0xffffdc95);}
                inspect=()->{summonTab=friends?0:1;go("summon");};
            }else{
                CosmeticCatalog.Item item=items.get(shopLookPage-2);boolean owned=store.ownsCosmetic(item.id),equipped=!store.usesOriginalCompanionCostume()&&item.id.equals(store.equippedCosmetic(item.slot));
                name=w(item.nameKey);price=equipped?Menu121Strings.get(store.resolvedLanguage(),"equipped"):owned?Menu121Strings.get(store.resolvedLanguage(),"owned"):Menu121Strings.get(store.resolvedLanguage(),"coin_price",item.priceCoins);status=Menu121Strings.get(store.resolvedLanguage(),"look_only");kind=Menu121Strings.get(store.resolvedLanguage(),"direct_buy");
                ArrayList<CosmeticCatalog.Item> clothes=new ArrayList<>(presentedCosmetics());clothes.removeIf(it->it.slot==item.slot);clothes.add(item);
                c.save();c.clipRect(30,282,360,465);drawCompanion(c,character,195,367,58,AvatarStyles.find(avatarStyle),AvatarStage.Pose.HAPPY,frameTime,reduceMotion,loadout,clothes);c.restore();inspect=()->cosmeticOffer(item);
            }
            hero121Fit(c,kind,195,245,11,300,0xffded7f5,true,true);hero121Fit(c,name,195,276,23,302,0xfffffaff,true,true);
            drawShopCarouselControls(c,shopLookPage,total,()->{shopLookPage=(shopLookPage+total-1)%total;invalidate();},()->{shopLookPage=(shopLookPage+1)%total;invalidate();});
            fit(c,price,195,546,24,342,TEXT,true,true);fit(c,status,195,571,12,336,0xff765c8b,false,true);
            if(shopLookPage<2)fit(c,Menu121Strings.get(store.resolvedLanguage(),"draw_note"),195,596,12,336,0xff765c8b,false,true);
            modernAction(c,new RectF(24,618,366,682),Menu121Strings.get(store.resolvedLanguage(),"preview")+" →",0xffffd78e,"shop_look_preview",inspect,true);
            modernAction(c,new RectF(24,700,366,760),a("avatar")+" →",0xffe7dbf4,"shop_wardrobe",()->go("wardrobe"),true);
            modernAction(c,new RectF(24,778,366,838),Menu121Strings.get(store.resolvedLanguage(),"earn_coins")+" →",0xffd5ede0,"shop_free_gifts",()->openRewards(0),true);H=Math.max(viewportH,Menu121Layout.SHOP_CONTENT_HEIGHT);
        }else{
            hero121Fit(c,Menu121Strings.get(store.resolvedLanguage(),"shop_gold"),195,245,11,302,0xffdfd7f6,true,true);hero121Fit(c,"LumaGold",195,276,28,302,0xfffffaff,true,true);shopArt.gold(c,195,383,74,frameTime,reduceMotion);
            hero121Fit(c,displayedGold==null?m20("wallet_unknown"):z("gold_last")+": "+displayedGold,195,489,14,300,0xfffffaff,true,true);
            float y=prose(c,Menu121Strings.get(store.resolvedLanguage(),"gold_closed"),548,TEXT);y=prose(c,z("gold_note"),y+10,PremiumUi.MUTED);y=Math.max(664,y+20);
            modernAction(c,new RectF(24,y,366,y+60),a("view_wallet")+" →",0xffe3d2f3,"shop_gold_wallet",()->openCommerce(),true);y+=78;
            modernAction(c,new RectF(24,y,366,y+60),m20("energy")+" →",0xffffdce8,"shop_energy",()->openSessionEnergy(),true);y+=78;
            modernAction(c,new RectF(24,y,366,y+60),v("wardrobe")+" · LumaGold →",0xffd5ede0,"shop_gold_cosmetics",()->getContext().startActivity(new android.content.Intent(getContext(),com.androidhit.lumadrift.social.CosmeticVaultActivity.class)),true);H=Math.max(viewportH,y+170);
        }
        shopContentHeight120=H;drawFixedNavigation(c);
    }
    private void drawShopCarouselControls(Canvas c,int page,int total,Runnable previous,Runnable next){
        modernAction(c,new RectF(34,455,94,509),"‹",0xffe5d8f2,"shop_previous",previous,true);modernAction(c,new RectF(296,455,356,509),"›",0xffe5d8f2,"shop_next",next,true);
        String position=(page+1)+" / "+total;hero121Fit(c,position,195,489,12,180,0xfffffaff,true,true);
        float dots=Math.min(7,total),start=195-(dots-1)*8;for(int i=0;i<dots;i++){p.setColor(i==page%Math.max(1,(int)dots)?0xffd8fff0:0x60e8e0fa);c.drawCircle(start+i*16,505,i==page%Math.max(1,(int)dots)?3:2,p);}
        label(103,455,184,52,position+". "+m20("previous")+" / "+m20("next"));
    }
    private void drawShopLook(Canvas c,CosmeticCatalog.Item item,float y){
        boolean owned=store.ownsCosmetic(item.id),on=!store.usesOriginalCompanionCostume()&&item.id.equals(store.equippedCosmetic(item.slot));
        round(c,24,y,342,132,23,0xffeee7f6);p.setColor(blend(cosmeticColor(item),0xffffffff,.65f));c.drawOval(33,y+13,132,y+116,p);CharacterSprites.drawGarmentPreview(c,item,37,y+8,128,y+115);
        fit(c,w(item.nameKey),146,y+34,18,201,TEXT,true,false);fit(c,Menu121Strings.get(store.resolvedLanguage(),"look_only"),146,y+61,12,201,PremiumUi.MUTED,false,false);
        fit(c,on?Menu121Strings.get(store.resolvedLanguage(),"equipped"):owned?e("action_equip"):Menu121Strings.get(store.resolvedLanguage(),"coin_price",item.priceCoins),146,y+98,14,187,TEXT,true,false);icon(c,"next",347,y+97,13,TEXT);
        hit(24,y,342,132,w(item.nameKey)+", "+(on?e("equipped"):owned?e("owned"):e("to_unlock"))+", "+Menu121Strings.get(store.resolvedLanguage(),"look_only")+", "+item.priceCoins+" LumaCoins",()->cosmeticOffer(item));
    }
    private void powerOffer(String id){if(!Catalog.isPowerOffered(id)){notice(l("shield_unneeded"));return;}openItem("power",id);}
    private void eventSegments(Canvas c){
        String[] names={t("daily"),t("weekly"),u("sealed")};ScenicUi.Kind[] kinds={ScenicUi.Kind.LANTERN,ScenicUi.Kind.BOOK,ScenicUi.Kind.KEY};
        for(int i=0;i<3;i++){final int n=i;float x=24+i*116;scenic.selector(c,new RectF(x+7,101,x+45,145),0xffad9dcf,eventTab==i,kinds[i]);fit(c,names[i],x+48,132,12,64,TEXT,eventTab==i,false);int before=hits.size();hit(x,99,110,51,names[i],()->{eventTab=n;actionGeneration++;hits.clear();invalidate();});if(hits.size()>before)hits.get(before).selected=eventTab==i;}
    }
    private void drawSealedMenu(Canvas c){
        header(c,u("sealed"),u("sealed_note"));eventSegments(c);sceneWindow(c,new RectF(24,163,366,310),0xfff7f0ff);
        icon(c,"lock",55,193,25,GOLD);fit(c,u("sealed"),82,198,20,260,TEXT,true,false);wrap(c,u("sealed_rule"),44,229,300,12,skin.muted,false,18);
        for(int i=1;i<=SealedCatalog.COUNT;i++){final int level=i;float x=24+((i-1)%2)*178,y=332+((i-1)/2)*91;scenic.object(c,new RectF(x,y+8,x+51,y+65),0xffb6a1c8,false,ScenicUi.Kind.KEY);fit(c,t("stage_number",i),x+55,y+33,16,99,TEXT,true,false);fit(c,t("play")+" →",x+55,y+56,12,99,skin.accent2,true,false);hit(x,y,164,77,u("sealed")+" · "+t("stage_number",i),()->openChallenge(ChallengeCode.encodeSealed(level)));}
        fit(c,u("sealed_unlimited"),195,642,11,340,skin.accent2,true,true);
    }
    private void drawEvents(Canvas c){
        if(eventTab==2){drawSealedMenu(c);return;}
        boolean daily=eventTab==0;int count=daily?Catalog.DAILY_COUNT:Catalog.WEEKLY_COUNT,completed=daily?store.dailyCompletedCount():store.weeklyCompletedCount(),bonus=daily?100:250;
        boolean claimed=daily?store.dailyBonusClaimed():store.weeklyBonusClaimed(),complete=completed==count;
        header(c,t("events"),daily?store.dailyId():store.weeklyId());
        eventSegments(c);
        RectF hero=new RectF(24,162,366,310);p.setAlpha(255);p.setShader(new LinearGradient(24,162,366,310,new int[]{blend(skin.card,skin.accent,.24f),skin.card},null,Shader.TileMode.CLAMP));c.drawRoundRect(hero,25,25,p);p.setShader(null);
        wrap(c,t(daily?"event_goal_daily":"event_goal_weekly"),44,189,235,14,TEXT,false,19);
        mascot(c,322,209,24,Catalog.CHARACTERS[daily?6:20],complete);
        fit(c,t("event_progress",completed,count),44,234,13,270,skin.accent2,true,false);
        round(c,44,246,302,7,4,alpha(WHITE,20));if(completed>0)round(c,44,246,302f*completed/count,7,4,skin.accent2);
        long minutes=EventSchedule.remainingMinutes(System.currentTimeMillis(),!daily,TimeZone.getDefault());
        String time=minutes>=1440?t("event_time_dhm",minutes/1440,(minutes/60)%24,minutes%60):t("event_time_hm",minutes/60,minutes%60);
        fit(c,t("event_resets",time),44,278,12,302,GOLD,true,false);
        fit(c,t("event_stage_reward",daily?70:105,daily?90:135),44,298,11,302,skin.muted,false,false);
        fit(c,t("event_clock_note"),195,330,10,340,skin.muted,false,true);
        label(24,162,342,148,t(daily?"event_goal_daily":"event_goal_weekly")+" "+t("event_progress",completed,count)+". "+t("event_resets",time)+". "+t("event_stage_reward",daily?70:105,daily?90:135));
        label(24,314,342,24,t("event_clock_note"));
        int next=-1;
        for(int i=0;i<count;i++){
            final int idx=i;int stars=daily?store.dailyStars(i):store.weeklyStars(i);boolean open=daily?store.isDailyUnlocked(i):store.isWeeklyUnlocked(i);
            if(next<0&&stars==0&&open)next=i;
            float x=daily?24+i*117:i<4?24+i*88:68+(i-4)*88,y=daily?507:507+(i/4)*77,w=daily?108:78,h=daily?110:68;
            scenic.selector(c,new RectF(x+8,y+2,x+w-8,y+h-11),stars>0?0xff87bbaa:0xffc0a3ce,open&&stars==0,ScenicUi.Kind.PORTAL);

            if(daily){

                if(stars>0)icon(c,"check",x+w/2,y+32,20,skin.accent2);else if(!open)icon(c,"lock",x+w/2,y+32,18,skin.muted);else center(c,""+(i+1),x+w/2,y+39,22,TEXT,true);
                fit(c,t("stage_number",i+1),x+w/2,y+75,13,w-12,open?TEXT:skin.muted,true,true);
                for(int k=0;k<3;k++)star(c,x+w/2+(k-1)*17,y+94,6,k<stars?GOLD:alpha(skin.muted,55));
            }else{
                center(c,""+(i+1),x+w/2,y+29,21,open?TEXT:skin.muted,true);
                if(!open)icon(c,"lock",x+w-14,y+15,11,skin.muted);else if(stars>0)icon(c,"check",x+w-14,y+15,11,skin.accent2);
                for(int k=0;k<3;k++)star(c,x+w/2+(k-1)*15,y+51,5.5f,k<stars?GOLD:alpha(skin.muted,55));
            }
            String stageLabel=t("stage_number",i+1)+", "+t(stars>0?"retry":"play")+", "+stars+" "+t("stars")+(open?"":", "+t("locked"));
            hit(x,y,w,h,stageLabel,()->openEventStage(daily,idx));
        }
        sceneAction(c,a("objectives")+"  →",24,690,342,()->openRewards(daily?0:1));
        final int nextStage=next<0?0:next;final String period=daily?store.dailyId():store.weeklyId();
        objectAction(c,t(complete?"event_replay":"event_play_next",nextStage+1),24,347,342,50,PEACH,()->{if(!period.equals(daily?store.dailyId():store.weeklyId())){syncStyle();notice(a("period_changed"));return;}openEventStage(daily,nextStage);});
        float rewardY=414;scenePaper(c,new RectF(24,rewardY,366,rewardY+77),SweetUi.CREAM,true);
        fit(c,t("bonus"),42,rewardY+27,13,158,TEXT,true,false);coin(c,51,rewardY+54,9);text(c,"+"+bonus,70,rewardY+61,24,skin.accent2,true);label(24,rewardY,177,77,t("bonus")+": "+bonus+" LumaCoins");
        if(claimed){fit(c,"✓ "+m20("collected"),279,rewardY+46,14,142,PremiumUi.MUTED,true,true);label(208,rewardY+15,142,48,m20("collected"));}
        else modernAction(c,new RectF(208,rewardY+15,350,rewardY+63),t(complete?"claim":"locked"),complete?0xffffdf99:0xffeee7f7,"event_bonus_claim",()->claimEventBonus(daily,period),complete);
    }
    private void openEventStage(boolean daily,int index){
        // Recheck the current calendar period at activation, even if midnight passed after drawing.
        if(daily?store.isDailyUnlocked(index):store.isWeeklyUnlocked(index))previewLevel(1,daily?1:2,index);else notice(t("unlock_previous"));
    }
    // Legal notices retain their original English license text; user-facing actions are localized.
    @android.annotation.SuppressLint("SetTextI18n")
    private void showLegal(){
        try{
            String license;try(java.io.InputStream in=getContext().getAssets().open("LICENSE.txt")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);license=out.toString("UTF-8");}
            String notices;try(java.io.InputStream in=getContext().getAssets().open("THIRD_PARTY_NOTICES.txt")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[2048];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);notices=out.toString("UTF-8");}
            android.widget.TextView body=new android.widget.TextView(getContext());body.setText(t(BuildConfig.MODE_SANDBOX?"sandbox_privacy_text":"production_privacy_text")+"\n\n© 2026 AndroidHit. Original puzzle art, generated Aurora Atlas environment and synthesized audio.\n\n"+notices+"\n\n"+license);body.setTextSize(12);body.setPadding(30,20,30,20);body.setTextColor(WHITE);android.widget.ScrollView scroll=new android.widget.ScrollView(getContext());scroll.addView(body);
            body.append("\n\n"+t("source_code")+": https://github.com/nabz0r/AndroidHit");body.setTextColor(TEXT);body.setTextIsSelectable(true);android.text.util.Linkify.addLinks(body,android.text.util.Linkify.WEB_URLS);scroll.setBackgroundColor(0xfff9f3ff);android.app.Dialog dialog=new android.app.Dialog(getContext());sceneDialog=dialog;dialog.setContentView(scroll);dialog.setCanceledOnTouchOutside(true);dialog.setOnDismissListener(closed->{if(sceneDialog==dialog)sceneDialog=null;});dialog.show();if(dialog.getWindow()!=null)dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.9f),(int)(getResources().getDisplayMetrics().heightPixels*.8f));
        }catch(java.io.IOException ignored){notice("github.com/nabz0r/AndroidHit");}
    }
    private void drawMissions(Canvas c){
        header(c,t("missions"),meta.dayId());
        label(24,103,342,93,t("rank",meta.rank())+", "+t("xp",meta.xp())+", "+t("rank_progress",meta.rankProgress()));
        sceneWindow(c,new RectF(24,103,366,196),0xfff7f0ff);fit(c,t("rank",meta.rank()),44,135,22,300,TEXT,true,false);text(c,t("rank_progress",meta.rankProgress()),44,160,12,skin.muted,false);round(c,44,174,300,5,3,alpha(WHITE,18));round(c,44,174,300*meta.rankProgress()/120f,5,3,skin.accent2);
        String[] keys={"mission_one","mission_two","mission_three"};String[] icons={"journey","collection","events"};
        for(int i=0;i<3;i++){final int idx=i;float y=214+i*119;sceneShelf(c,new RectF(24,y,366,y+105),0xffbdadc5,false);icon(c,icons[i],51,y+28,21,skin.accent2);wrap(c,t(keys[i]),77,y+25,260,14,TEXT,false,18);text(c,t("mission_progress",meta.missionProgress(i),meta.missionTarget(i)),44,y+83,14,skin.muted,true);
            label(40,y+10,305,85,t(keys[i])+", "+t("mission_progress",meta.missionProgress(i),meta.missionTarget(i)));
            boolean claimed=meta.missionClaimed(i),ready=meta.missionComplete(i);String title=claimed?t("claimed"):ready?t("claim")+" +"+meta.missionCoins(i)+" ◈":"+"+meta.missionCoins(i)+" ◈";
            if(claimed){fit(c,"✓ "+m20("collected"),273,y+91,14,150,PremiumUi.MUTED,true,true);label(198,y+60,150,48,m20("collected"));}
            else modernAction(c,new RectF(198,y+60,348,y+108),title,0xffffdf99,"legacy_quest_"+idx,()->{try{int got=meta.claimMission(idx,store);if(got>0){syncStyle();showMenuGift(t(keys[idx]),"+"+got+" LumaCoins","");}}catch(IllegalStateException failed){notice(t("save_error"));}},ready);
        }
        float yy=579;sceneShelf(c,new RectF(24,yy,366,yy+70),0xffbdadc5,false);star(c,51,yy+32,15,meta.badgeUnlocked()?GOLD:skin.muted);fit(c,t("badge"),78,yy+27,15,260,TEXT,true,false);fit(c,t(meta.badgeUnlocked()?meta.badgeEquipped()?"equipped":"equip":"badge_desc"),78,yy+48,11,260,skin.muted,false,false);hit(24,yy,342,70,t("badge"),()->{if(meta.badgeUnlocked()){meta.setBadgeEquipped(!meta.badgeEquipped());sfx(AudioEngine.Sound.SELECT);}else notice(t("badge_desc"));});
        if(H>790)fit(c,t("days_note"),195,H-110,11,340,skin.muted,false,true);
    }
    private String journalStatus(String status){return t(PlayJournal.OBSERVED.equals(status)?"journal_observed":PlayJournal.NOT_OBSERVED_LOCAL.equals(status)?"journal_not_observed":"journal_unknown");}
    private void drawJournal(Canvas c){
        header(c,t("local_journal"),t("local_only"));sceneAction(c,"‹ "+t("back"),24,99,107,()->go("settings"));
        settingsRow(c,"local_journal",journal.isEnabled(),163,()->{journal.setEnabled(!journal.isEnabled());if(journal.isEnabled())applyPendingContinuation();if(prefs.getBoolean("session_migration_notice",false)){notice(t("moves_migration"));prefs.edit().putBoolean("session_migration_notice",false).commit();}log("session_start","version",BuildConfig.VERSION_NAME,"language",store.resolvedLanguage());});
        wrap(c,t("journal_desc"),27,245,336,14,skin.muted,false,21);
        sceneWindow(c,new RectF(24,321,366,471),0xfff7f0ff);fit(c,t("journal_sessions",journal.sessions(),journal.activeDays()),43,355,19,305,TEXT,true,false);fit(c,t("stats"),43,387,13,305,skin.accent2,true,false);
        wrap(c,t("journal_returns",journalStatus(journal.returnDay1()),journalStatus(journal.returnDay7())),43,417,300,12,skin.muted,false,19);
        objectAction(c,t("export_journal"),24,493,342,49,skin.accent2,()->{if(journal.eventCount()==0){notice(t("journal_empty"));return;}try{ShareComposer.exportJournal((Activity)getContext(),journal.exportJson(),store.resolvedLanguage());}catch(java.io.IOException|android.content.ActivityNotFoundException error){notice(t("journal_error"));}});
        sceneAction(c,t("clear_journal"),24,558,342,()->confirmInScene(t("clear_journal"),t("confirm_clear_journal"),()->{ShareComposer.clearJournalExports((Activity)getContext());journal.clear();notice(t("journal_cleared"));}));
        wrap(c,t("export_note"),195,644,323,12,skin.muted,true,18);
    }
    private void drawSettings(Canvas c){
        header(c,t("settings"),(BuildConfig.MODE_SANDBOX?"Luma Drift Lab":"Luma Drift")+" · "+BuildConfig.VERSION_NAME);
        sceneAction(c,"‹  "+t("back"),24,100,105,()->go("home"));
        settingsRow(c,"sound",store.soundEnabled(),151,()->{store.setSoundEnabled(!store.soundEnabled());syncStyle();});
        settingsRow(c,"music",store.musicEnabled(),211,()->{store.setMusicEnabled(!store.musicEnabled());syncStyle();});
        settingsRow(c,"haptics",store.hapticsEnabled(),271,()->{store.setHapticsEnabled(!store.hapticsEnabled());haptic();});
        settingsRow(c,"reduce_motion",reduceMotion,331,()->{reduceMotion=!reduceMotion||!android.animation.ValueAnimator.areAnimatorsEnabled();prefs.edit().putBoolean("reduce_motion",reduceMotion).apply();});
        text(c,t("language"),26,423,16,TEXT,true);
        for(int i=0;i<Strings.LANGUAGE_CODES.length;i++){final String code=Strings.LANGUAGE_CODES[i];float x=24+(i%3)*116,y=443+(i/3)*62;boolean on=store.language().equals(code);scenic.selector(c,new RectF(x,y+2,x+35,y+39),0xffb5a8cb,on,ScenicUi.Kind.LANGUAGE);String name=i==0?t("system"):Strings.LANGUAGE_NAMES[i];fit(c,name,x+40,y+29,12,70,on?TEXT:skin.muted,on,false);int before=hits.size();hit(x,y,110,58,name,()->{store.setLanguage(code);invalidate();});if(hits.size()>before)hits.get(before).selected=on;}
        sceneAction(c,r("relay_rule"),24,650,165,()->go("rules"));sceneAction(c,n("learn"),201,650,165,()->openTutorial(true));
        sceneAction(c,t("local_journal"),24,712,165,()->go("journal"));sceneAction(c,t("account"),201,712,165,()->openAccount());
        sceneAction(c,t("credits"),24,774,165,()->showLegal());sceneAction(c,t("missions"),201,774,165,()->go("missions"));
        sceneAction(c,t("import_challenge"),24,836,165,()->importCode());sceneAction(c,t("share_challenge"),201,836,165,()->shareBoard());
        sceneAction(c,v("friends"),24,898,342,()->openSocial());
        fit(c,t(BuildConfig.MODE_SANDBOX?"sandbox_privacy_local":"production_privacy_local"),195,996,12,338,skin.muted,false,true);H=Math.max(viewportH,1110);
    }
    private void settingsRow(Canvas c,String key,boolean on,float y,Runnable action){
        scenic.dial(c,new RectF(293,y-3,353,y+57),on?0xff85b6a6:0xffb1a8c6,on?1f:0f,false);
        scenic.object(c,new RectF(29,y+1,73,y+45),0xffa99dc5,false,key.equals("music")?ScenicUi.Kind.MUSIC:key.equals("sound")?ScenicUi.Kind.LANTERN:key.equals("reduce_motion")?ScenicUi.Kind.LEAF:ScenicUi.Kind.STARS);
        text(c,t(key),87,y+32,15,TEXT,true);hit(24,y,342,57,t(key)+": "+t(on?"on":"off"),()->{action.run();if(reduceMotion)finishScenePresentation();});
    }
    /** Exact search runs on an isolated snapshot, never in the animation or input thread. */
    private void ensureGuidance(){
        if(board==null)return;
        int remaining=moveBudget==null||moveBudget.isUnlimited()?-1:moveBudget.remaining();int[] history=board.history();int historyHash=Arrays.hashCode(history);
        if(guidanceBoard==board&&guidanceMask==board.remainingMask()&&guidanceGates==board.gateMask()&&guidanceBudget==remaining&&guidanceHistory==historyHash&&Arrays.equals(history,guidanceSavedHistory))return;
        guidanceBoard=board;guidanceMask=board.remainingMask();guidanceGates=board.gateMask();guidanceBudget=remaining;guidanceHistory=historyHash;guidanceSavedHistory=history;
        guidance=null;guidancePlan=new int[0];guidanceSafe.clear();guidancePending=true;
        final long token=++guidanceGeneration;final Board target=board;final Level level=board.level;
        if(guideWorker.isShutdown())return;
        guideWorker.execute(()->{
            if(token!=guidanceGeneration||Thread.currentThread().isInterrupted())return;
            Board snapshot=new Board(level);if(!snapshot.restoreHistory(history))return;
            Board.Guidance result=snapshot.guidance(remaining);int[] plan=snapshot.solve();HashSet<Integer> safe=new HashSet<>();
            if(result.canUseHint()){
                // V4 paths remain recoverable; Focus highlights the efficient next action, not every legal tap.
                if(level.progressionVersion>=4){if(plan!=null&&plan.length>0)safe.add(plan[0]);}
                else for(Tile tile:snapshot.legalMoves())if(snapshot.isSafeMove(tile.id))safe.add(tile.id);
            }
            if(token!=guidanceGeneration||Thread.currentThread().isInterrupted())return;
            post(()->{if(token!=guidanceGeneration||board!=target)return;guidance=result;guidancePlan=plan==null?new int[0]:plan;guidanceSafe.clear();guidanceSafe.addAll(safe);guidancePending=false;if(!pendingContinuation.isEmpty())applyPendingContinuation();invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);});
        });
    }
    private int continuationNeed(){ensureGuidance();return guidance!=null&&guidance.actionsToFinish>0?guidance.actionsToFinish:-1;}
    private void showDeadEnd(){ensureGuidance();if(guidance==null){notice(n("thinking"));return;}deadEndOpen=true;invalidate();}
    private void drawDeadEnd(Canvas c){
        scrim(c);float height=Math.min(420,viewportH-30),y=(viewportH-height)/2;sceneWindow(c,new RectF(24,y,366,y+height),PremiumUi.PAPER);
        dressedMascot(c,195,y+70,34);fit(c,v("dead_end"),195,y+151,23,300,TEXT,true,true);
        wrap(c,board.level.progressionVersion==6?(economyPolicy121?a21("undo_rule"):l("relay_undo_note")):l("retry_note"),195,y+187,294,14,PremiumUi.MUTED,true,22);
        if(hasReturn())objectAction(c,returnLabel(),44,y+height-140,302,51,PEACH,()->{deadEndOpen=false;undoMove();});else objectAction(c,restartLabel120(),44,y+height-140,302,51,PEACH,()->{deadEndOpen=false;restartRun();});
        sceneAction(c,restartLabel120(),44,y+height-75,232,()->{deadEndOpen=false;restartRun();});sceneAction(c,"×",286,y+height-75,60,()->deadEndOpen=false);
    }
    private void requestAction(int action){
        if(board==null||paused||help||won||outOfMoves()||powerSaveBlocked||flowRemaining>0)return;
        if(!Board.isGateAction(action)&&elements121!=null&&elements121.layers(action)>0){tapElement121(action);return;}
        Board.ActionPreview preview=board.previewAction(action);
        if(board.level.progressionVersion==6){actionPreview=null;movePiece(action);return;}
        if(preview.legal&&(Board.isGateAction(action)||board.level.tile(action).isSwitch())){
            pendingAction=action;actionPreview=preview;selected=Board.isGateAction(action)?-1:action;actionGeneration++;invalidate();announceForAccessibility(n("preview"));
        }else movePiece(action);
    }
    private void drawActionPreview(Canvas c){
        if(pendingAction<0||actionPreview==null)return;
        // Modal coordinates follow the visible window, independent of board/page scroll.
        c.save();c.translate(0,contentScroll);float oldScroll=drawingScroll;drawingScroll=0;hits.clear();
        round(c,0,0,390,viewportH,0,0x96463252);
        float height=Math.min(330,viewportH-16),y=Math.max(8,(viewportH-height)/2);int action=pendingAction;Board.ActionPreview preview=actionPreview;
        scenePaper(c,new RectF(24,y,366,y+height),SweetUi.CREAM,true);fit(c,n("preview"),195,y+29,20,304,TEXT,true,true);
        StringBuilder description=new StringBuilder(n("preview"));int i=0;
        for(Direction direction:Direction.values())if(((preview.openedMask|preview.closedMask)&direction.bit)!=0){
            String changed=n((preview.openedMask&direction.bit)!=0?"opens":"closes",t("direction_"+direction.name().toLowerCase(Locale.ROOT)));
            fit(c,changed,44,y+56+i++*22,14,300,TEXT,true,false);description.append(". ").append(changed);
        }
        if(i==0)fit(c,n("choose_action"),195,y+64,14,301,TEXT,false,true);
        if(height>=315)wrap(c,l("action_cost"),44,y+153,302,12,skin.muted,false,17);
        label(39,y+5,312,Math.max(125,height-120),description.toString());
        objectAction(c,Board.isGateAction(action)?n("opening",t("direction_"+Board.gateDirection(action).name().toLowerCase(Locale.ROOT))):n("confirm_move"),44,y+height-112,302,48,PEACH,()->{pendingAction=-1;actionPreview=null;movePiece(action);});
        sceneAction(c,n("cancel_preview"),44,y+height-54,302,()->{pendingAction=-1;actionPreview=null;selected=-1;});
        drawingScroll=oldScroll;c.restore();
    }
    private void drawPlay(Canvas c){
        if(board==null){go("adventure");return;}ensureGuidance();boolean relay=board.level.progressionVersion==6;
        scenic.object(c,new RectF(20,56,68,104),0xffb7a6cb,false,ScenicUi.Kind.PAUSE);hit(20,56,48,48,t("pause"),()->setPaused(true));
        fit(c,mode==5?x("expedition"):mode==0?t("level_number",levelIndex):mode==3?t("remix")+" "+levelIndex:t(mode==1?"daily":mode==2?"weekly":"friend_challenge"),195,79,22,210,TEXT,true,true);
        fit(c,mode==5?x("step",eventIndex+1,ExpeditionCatalog.STAGES):mode==0||mode==3?worldName(levelIndex):mode==4?friendCode:t("stage_number",eventIndex+1),195,101,12,220,PremiumUi.MUTED,false,true);
        scenic.object(c,new RectF(322,56,370,104),0xff9fafd0,false,ScenicUi.Kind.BOOK);hit(322,56,48,48,t("how_to_play"),()->setHelp(true));
        LearningGuide.Context coach=lesson(board);
        float battleOffset=42+(battleEnabled()?battleRailHeight():0)+(arcadeEnabled121()?arcadeRailHeight121():0);
        if(battleEnabled())drawBattleDock(c);
        if(arcadeEnabled121())drawFocus121(c,132+(battleEnabled()?battleRailHeight():0));
        fit(c,r("puzzle_goal",board.remainingCount()),24,101+battleOffset,18,288,TEXT,true,false);if(!battleEnabled())dressedMascot(c,344,87,12);
        sweet.progress(c,new RectF(24,118+battleOffset,366,124+battleOffset),1f-board.remainingCount()/(float)board.level.tiles.size(),SweetUi.MINT);
        boolean low=moveBudget!=null&&!moveBudget.isUnlimited()&&moveBudget.remaining()<=3;
        PlaySceneLayout scene=playSceneLayout;
        if(moveBudget!=null){
            String budgetLabel=moveBudget.isUnlimited()?t("moves_unlimited"):t("moves_left",moveBudget.remaining(),moveBudget.total());
            String count=moveBudget.isUnlimited()?"∞":moveBudget.remaining()+" / "+moveBudget.total();
            round(c,scene.budgetRect.left-5,scene.budgetRect.top-4,scene.budgetRect.width()+10,scene.budgetRect.height()+6,15,low?0xffffd4c7:0xffd9f1e8);
            fit(c,vr("moves"),scene.budgetRect.centerX(),scene.budgetRect.top+13,12,scene.budgetRect.width(),PremiumUi.MUTED,true,true);
            fit(c,count,scene.budgetRect.centerX(),scene.budgetRect.bottom-1,25,scene.budgetRect.width(),low?0xffae5873:TEXT,true,true);
            label(scene.budgetRect.left,scene.budgetRect.top,scene.budgetRect.width(),scene.budgetRect.height(),budgetLabel);
            float clockX=303,clockTop=scene.budgetRect.top;
            fit(c,vr("time"),clockX,clockTop+16,12,126,PremiumUi.MUTED,false,true);
            fit(c,VictoryLayout.clock(elapsed()),clockX,scene.budgetRect.bottom-1,19,126,TEXT,true,true);
            label(240,clockTop,126,scene.budgetRect.height(),vr("time")+" "+VictoryLayout.clock(elapsed())+". "+vr("clock_note"));
        }
        float boardW=scene.boardWidth;cell=boardW/board.level.size;bx=scene.boardX;by=scene.boardY;
        sceneShelf(c,new RectF(bx-13,by-13,bx+boardW+13,by+boardW+13),PremiumUi.PAPER,true);
        for(int row=0;row<board.level.size;row++)for(int col=0;col<board.level.size;col++){
            round(c,bx+col*cell+3,by+row*cell+3,cell-6,cell-6,12,0x48e3d5ef);p.setColor(alpha(WHITE,16));c.drawCircle(bx+(col+.5f)*cell,by+(row+.5f)*cell,1.5f,p);
        }
        drawGates(c,boardW);drawBarriers(c);
        if(selected>=0&&board.isPresent(selected))drawRay(c,board.level.tile(selected));
        for(Tile tile:board.remainingTiles()){
            float x=bx+(tile.col+.5f)*cell,y=by+(tile.row+.5f)*cell;
            if(!reduceMotion&&tile.id==shakeId&&frameTime<shakeUntil)x+=(float)Math.sin((shakeUntil-frameTime)*.06)*4;
            boolean lit=tile.id==coachId||tile.id==hintId&&frameTime<hintUntil||frameTime<visionUntil&&board.canMove(tile.id)||frameTime<focusUntil&&safeHighlights.contains(tile.id)||frameTime<consequenceUntil&&newlyFreed.contains(tile.id);
            drawTile(c,tile,x,y,cell-8,lit);if(blockedAt121>0&&frameTime-blockedAt121<2300&&(tile.id==blockedPiece121||newlyFreed.contains(tile.id)))stroke(c,new RectF(x-cell*.46f,y-cell*.46f,x+cell*.46f,y+cell*.46f),12,0xffc04159,3);
            if(elements121!=null&&elements121.layers(tile.id)>0)living121.shell(c,x,y,cell-5,elements121.kind(tile.id).ordinal(),elements121.layers(tile.id),frameTime,reduceMotion);if(tile.id==hintId&&frameTime<hintUntil){float pulse=reduceMotion?1f:.6f+.4f*(float)Math.sin(frameTime*.009);stroke(c,new RectF(x-cell*.47f,y-cell*.47f,x+cell*.47f,y+cell*.47f),13,alpha(GOLD,(int)(150+105*pulse)),3);star(c,x,y-cell*.62f,8+3*pulse,GOLD);}if(board.level.isKey(tile.id))drawKeyBadge121(c,x-cell*.35f,y-cell*.35f,Math.max(10,cell*.19f),sealedKeyNumber(tile.id));
            if(frameTime<trailUntil)for(int k=0;k<trail.length;k++)if(trail[k]==tile.id){round(c,x-cell*.39f,y-cell*.4f,19,19,7,GOLD);center(c,""+(k+1),x-cell*.39f+9.5f,y-cell*.4f+14,11,INK,true);}
            final int id=tile.id;
            String description=(elements121!=null&&elements121.layers(tile.id)>0?elementLabel121(tile.id)+". ":"")+(board.level.isKey(tile.id)?u("sealed_key",sealedKeyNumber(tile.id))+", ":"")+t("piece_description",tile.row+1,tile.col+1,t("direction_"+tile.direction.name().toLowerCase(Locale.ROOT)))+", "+t(board.canMove(id)?"gate_open":"blocked");
            if(frameTime<focusUntil&&safeHighlights.contains(id))description+=", "+t("power_safe");
            if(frameTime<trailUntil)for(int k=0;k<trail.length;k++)if(trail[k]==id)description+=", "+t("power_step",k+1);
            if(tile.switchMask!=0){description+=", "+t("switch")+":";for(Direction target:Direction.values())if((tile.switchMask&target.bit)!=0)description+=" "+t("direction_"+target.name().toLowerCase(Locale.ROOT));}
            hit(bx+tile.col*cell,by+tile.row*cell,cell,cell,description,()->requestAction(id));
        }
        Iterator<Flight> it=flights.iterator();while(it.hasNext()){
            Flight f=it.next();float u=(frameTime-f.at)/(reduceMotion?180f:460f);if(u<0)continue;if(u>=1){it.remove();continue;}float d=reduceMotion?0:(u*u)*330;
            c.saveLayerAlpha(0,0,390,H,(int)((1-u)*255));drawTile(c,f.tile,f.x+f.tile.direction.dc*d,f.y+f.tile.direction.dr*d,cell-8,false);c.restore();
            for(int i=0;i<4;i++){float tail=d-i*12;if(tail>0)star(c,f.x+f.tile.direction.dc*tail,f.y+f.tile.direction.dr*tail,3*(1-u),alpha(f.color,(int)(100*(1-u))));}
        }
        if(!reduceMotion&&frameTime<successUntil){float elapsed=1-(successUntil-frameTime)/600f;int a=(int)(160*(1-elapsed));p.setColor(alpha(skin.accent2,a));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(successX,successY,8+elapsed*30,p);p.setStyle(Paint.Style.FILL);for(int k=0;k<6;k++){double angle=k*Math.PI/3;star(c,successX+(float)Math.cos(angle)*(10+elapsed*28),successY+(float)Math.sin(angle)*(10+elapsed*28),3*(1-elapsed),alpha(GOLD,a));}}
        if(guidance!=null&&guidance.status==Board.PositionStatus.DEAD_END&&!paused&&!won&&!outOfMoves()){sceneAura(c,new RectF(30,by+boardW-42,360,by+boardW-4),0xffd9a1ba,frameTime,true);fit(c,v("path_warning"),195,by+boardW-17,12,312,GOLD,true,true);hit(30,by+boardW-42,330,38,v("dead_end"),()->showDeadEnd());}
        String feedback=frameTime<toastUntil?toast:guidance!=null&&guidance.status==Board.PositionStatus.DEAD_END?v("path_warning"):relay?l(coach.hudKey):low?l("last_moves",moveBudget.remaining()):l(coach.hudKey);
        boolean blockedVisible=blockedAt121>0&&frameTime-blockedAt121<2300;
        if(blockedVisible){round(c,scene.feedbackRect.left,scene.feedbackTop,scene.feedbackRect.width(),scene.feedbackHeight,14,0xffffd9d7);fit(c,"✕  "+a21(blockedCost121==0?"blocked_free":"blocked_cost",blockedCost121),195,scene.feedbackTop+27,17,322,0xff9c3049,true,true);}
        else twoLines(c,feedback,scene.feedbackRect.left,scene.feedbackTop,scene.feedbackRect.width(),12,PremiumUi.MUTED);
        label(scene.feedbackRect.left,scene.feedbackTop,scene.feedbackRect.width(),scene.feedbackHeight,blockedVisible?a21(blockedCost121==0?"blocked_free":"blocked_cost",blockedCost121):feedback);
        if(scene.compactActions){
            String undoCaption=t("undo")+(moveBudget.policyVersion()==MoveBudget.DELIBERATE_POLICY_VERSION?"\n×"+moveBudget.undoRemaining(undos):"");
            compactPlayAction(c,scene.undoRect,undoCaption,"↶  "+returnLabel(),ScenicUi.Kind.UNDO,()->undoMove());
            compactPlayAction(c,scene.restartRect,t("restart"),"↻  "+t("restart"),ScenicUi.Kind.RETRY,()->{setPaused(true);restartConfirm=true;});
            compactPlayAction(c,scene.powersRect,mode==5?x("route"):mode==4?t("share_challenge"):r("powers"),mode==5?x("route"):mode==4?t("share_challenge"):r("powers"),mode==5?ScenicUi.Kind.COMPASS:mode==4?ScenicUi.Kind.MAIL:ScenicUi.Kind.SATCHEL,()->{if(mode==5)go("expedition");else if(mode==4)shareBoard();else powerTrayOpen=true;});
        }else{
            playAction(c,scene.undoRect,"↶  "+returnLabel(),()->undoMove());
            playAction(c,scene.restartRect,"↻  "+t("restart"),()->{setPaused(true);restartConfirm=true;});
            if(mode==5){playAction(c,scene.powersRect,x("route"),()->go("expedition"));}
            else if(mode==4){playAction(c,scene.powersRect,t("share_challenge"),()->shareBoard());}
            else{
            int i=0;for(Catalog.BoosterItem item:Catalog.BOOSTERS){final String id=item.id;if(!store.boosterUnlocked(id)||id.equals("shield")&&moveBudget.rejectsAreFree())continue;if(i>=3)break;PlaySceneLayout.Rect slot=scene.powerGrid[i++];float x=slot.left,y=slot.top;boolean active=powerActive(id);
                sceneShelf(c,new RectF(x,y,slot.right,slot.bottom),active?PremiumUi.MINT:PremiumUi.PAPER,false);shopArt.power(c,id,x+24,y+26,19,frameTime,reduceMotion);fit(c,"×"+store.boosterStock(id),x+72,y+29,13,44,TEXT,true,true);fit(c,t(item.nameKey),x+53,y+55,12,96,TEXT,true,true);hit(x,y,slot.width(),slot.height(),t(item.nameKey),()->useItem(id));
            }
            // The tray remains reachable even before the first power is unlocked.
            playAction(c,scene.powersMoreRect,r("powers")+"  →",()->{collectionTab=3;inventoryFilter=0;powerTrayOpen=true;});
            }
        }
        if(battleEnabled()&&battleEffectAt>0)CompanionBattleScene.drawSkillEffect(c,new RectF(bx,by,bx+boardW,by+boardW),battleEffectColor,frameTime-battleEffectAt,reduceMotion,battleEffect.ordinal(),successX,successY);
        if(won)hits.clear();
        if(pendingAction>=0&&!paused&&!outOfMoves()&&!won)drawActionPreview(c);
        // Overlays are anchored to the visible window, including after reaching
        // the compact action row by scrolling the puzzle scene.
        c.save();c.translate(0,contentScroll);float oldDrawingScroll=drawingScroll,oldHeight=H;drawingScroll=0;H=viewportH;
        round(c,0,0,390,106,0,0xfffbf7ff);drawPlayWalletHud120(c);hit(0,0,390,42,"LumaCoins, LumaGold, "+sessionEnergyLabel(),()->{});if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="play_wallet";
        scenic.object(c,new RectF(20,53,68,101),0xffb7a6cb,false,ScenicUi.Kind.PAUSE);motionHit(new RectF(20,53,68,101),t("pause"),"play_pause",()->setPaused(true));
        scenic.object(c,new RectF(322,53,370,101),0xff9fafd0,false,ScenicUi.Kind.BOOK);motionHit(new RectF(322,53,370,101),t("how_to_play"),"play_help",()->setHelp(true));
        fit(c,t("level_number",levelIndex),195,63,12,228,PremiumUi.MUTED,true,true);
        String fixedMoves=moveBudget.isUnlimited()?t("moves_unlimited"):a21("remaining",moveBudget.remaining());
        fit(c,fixedMoves,195,87,21,232,low?0xffa43b52:TEXT,true,true);
        label(76,43,238,63,fixedMoves+". "+(moveBudget.isUnlimited()?"":a21("used_total",moveBudget.used(),moveBudget.total())));
        if(outOfMoves()&&!paused&&!won){ensureGuidance();if(moveBudget.policyVersion()!=MoveBudget.FOCUSED_RELAY_POLICY_VERSION&&guidance!=null&&guidance.status==Board.PositionStatus.DEAD_END)drawDeadEnd(c);else drawOutOfMoves(c);}
        if(paused)drawPause(c);
        if(deadEndOpen&&!paused&&!won)drawDeadEnd(c);
        if(powerTrayOpen&&!paused&&!won)drawPowerTray(c);
        if(!powerConfirmation.isEmpty()&&!paused&&!won)drawPowerConfirmation(c);
        if(powerSaveBlocked)drawSaveRetry(c);else if(won&&frameTime>=winAt)drawWin(c);
        H=oldHeight;drawingScroll=oldDrawingScroll;c.restore();
    }
    private void playAction(Canvas c,PlaySceneLayout.Rect area,String caption,Runnable action){
        objectAction(c,caption,area.left,area.top,area.width(),area.height(),PEACH,action);
    }
    private void compactPlayAction(Canvas c,PlaySceneLayout.Rect area,String caption,String description,ScenicUi.Kind kind,Runnable action){
        float artSize=42,center=area.centerX();
        scenic.object(c,new RectF(center-artSize/2,area.top,center+artSize/2,area.top+artSize),0xffaaa1cd,pressed!=null&&pressed.name.equals(description),kind);
        android.text.StaticLayout words=twoLineLayout(caption,area.width()-6,12,TEXT,true);
        c.save();c.translate(area.left+3,area.top+artSize+4);words.draw(c);c.restore();
        hit(area.left,area.top,area.width(),area.height(),description,action);
    }
    private int directionColor(Direction d){switch(d){case UP:return 0xff91e5cc;case RIGHT:return 0xffffb398;case DOWN:return 0xffceb3f7;default:return 0xffa4cefa;}}
    private void arrow(Canvas c,float x,float y,Direction d,float size,int color){
        c.save();c.translate(x,y);c.rotate(d.ordinal()*90);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(2,size*.21f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path q=new Path();q.moveTo(0,size*.7f);q.lineTo(0,-size*.7f);q.moveTo(-size*.53f,-size*.15f);q.lineTo(0,-size*.72f);q.lineTo(size*.53f,-size*.15f);c.drawPath(q,p);p.setStyle(Paint.Style.FILL);c.restore();
    }
    private void drawTile(Canvas c,Tile tile,float x,float y,float size,boolean lit){
        sweet.tile(c,new RectF(x-size/2,y-size/2,x+size/2,y+size/2),tile.direction,directionColor(tile.direction),tile.isSwitch(),false,lit,frameTime,reduceMotion);
        arrow(c,x,y,tile.direction,size*.36f,0xfffbfcff);arrow(c,x,y,tile.direction,size*.29f,0xff302542);
        if(tile.isSwitch()){
            int index=0;for(Direction direction:Direction.values())if((tile.switchMask&direction.bit)!=0){float xx=x+size*.32f,yy=y-size*.31f+index++*size*.31f;
                p.setColor(0xfffff9ff);c.drawCircle(xx,yy,size*.17f,p);arrow(c,xx,yy,direction,size*.12f,TEXT);
            }
        }
    }
    private void drawGates(Canvas c,float width){
        for(Direction direction:Direction.values()){
            boolean open=board.isGateOpen(direction);float x=playSceneLayout.gateX[direction.ordinal()],y=playSceneLayout.gateY[direction.ordinal()];
            boolean highlighted=actionPreview!=null&&((actionPreview.openedMask|actionPreview.closedMask)&direction.bit)!=0||hintId==Board.gateAction(direction)&&frameTime<hintUntil||frameTime<focusUntil&&safeHighlights.contains(Board.gateAction(direction))||frameTime<consequenceUntil&&(consequenceGateMask&direction.bit)!=0;
            if(!open&&board.supportsManualGates()){
                round(c,x-23,y-23,46,46,14,0xffffecce);stroke(c,new RectF(x-23,y-23,x+23,y+23),14,0xffc58c36,1.4f);
                icon(c,"lock",x,y-7,15,0xff77572d);center(c,"−1",x,y+16,11,0xff77572d,true);
            }else sweet.gate(c,x,y,13,direction,open,highlighted,frameTime,reduceMotion);
            if(highlighted&&board.supportsManualGates())stroke(c,new RectF(x-24,y-24,x+24,y+24),14,skin.accent2,2);
            if(actionPreview!=null&&((actionPreview.openedMask|actionPreview.closedMask)&direction.bit)!=0){
                int newColor=(actionPreview.openedMask&direction.bit)!=0?0xff327a69:0xffb44469;
                icon(c,(actionPreview.openedMask&direction.bit)!=0?"check":"lock",x+direction.dc*15,y+direction.dr*15,16,newColor);
            }
            String desc=t(open?"gate_open":"gate_closed")+" · "+t("direction_"+direction.name().toLowerCase(Locale.ROOT));
            if(!open&&board.supportsManualGates())desc+=" · "+n("opening",t("direction_"+direction.name().toLowerCase(Locale.ROOT)));
            if(frameTime<trailUntil)for(int step=0;step<trail.length;step++)if(trail[step]==Board.gateAction(direction)){
                round(c,x+9,y-24,20,20,7,GOLD);center(c,""+(step+1),x+19,y-10,12,TEXT,true);desc+=", "+t("power_step",step+1);
            }
            if(hintId==Board.gateAction(direction)&&frameTime<hintUntil)desc+=", "+n("hint_gate");
            final String label=desc;PlaySceneLayout.Rect target=playSceneLayout.gateTargets[direction.ordinal()];
            int before=hits.size();hit(target.left,target.top,target.width(),target.height(),desc,()->{if(!open&&board.supportsManualGates())requestAction(Board.gateAction(direction));else notice(label);});
            if(hits.size()>before)hits.get(before).gate=direction.ordinal();
        }
    }
    private void drawKeyBadge121(Canvas c,float x,float y,float r,int number){
        p.setColor(0xffffdd78);c.drawCircle(x,y,r,p);p.setColor(0xff6d481a);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(2,r*.18f));c.drawCircle(x-r*.24f,y-r*.22f,r*.26f,p);c.drawLine(x-r*.06f,y-r*.02f,x+r*.43f,y+r*.47f,p);c.drawLine(x+r*.23f,y+r*.27f,x+r*.40f,y+r*.10f,p);c.drawLine(x+r*.39f,y+r*.43f,x+r*.55f,y+r*.27f,p);p.setStyle(Paint.Style.FILL);
        round(c,x+r*.3f,y-r*1.05f,r*1.15f,r*1.1f,r*.35f,0xff775124);fit(c,String.valueOf(number),x+r*.88f,y-r*.26f,Math.max(10,r*.82f),r*.95f,0xffffffff,true,true);
    }
    private int sealedKeyNumber(int tileId){ArrayList<Integer> keys=new ArrayList<>();for(Barrier barrier:board.level.barriers)if(!keys.contains(barrier.keyTileId))keys.add(barrier.keyTileId);return keys.indexOf(tileId)+1;}
    private void drawBarriers(Canvas c){for(Barrier wall:board.level.barriers){float x=bx+(wall.col+.5f)*cell,y=by+(wall.row+.5f)*cell;boolean active=board.isBarrierActive(wall);if(!active){stroke(c,new RectF(x-cell*.4f,y-cell*.4f,x+cell*.4f,y+cell*.4f),10,alpha(GOLD,25),1);continue;}round(c,x-cell*.44f,y-cell*.44f,cell*.88f,cell*.88f,11,0xffffdf99);stroke(c,new RectF(x-cell*.44f,y-cell*.44f,x+cell*.44f,y+cell*.44f),11,0xffa47124,2.4f);icon(c,"lock",x,y-3,cell*.42f,0xff795020);fit(c,String.valueOf(sealedKeyNumber(wall.keyTileId)),x,y+cell*.34f,13,cell*.7f,0xff795020,true,true);String caption=u("sealed_wall",sealedKeyNumber(wall.keyTileId));hit(x-cell/2,y-cell/2,cell,cell,caption,()->notice(caption));}}
    private void drawRay(Canvas c,Tile tile){
        float x=bx+(tile.col+.5f)*cell,y=by+(tile.row+.5f)*cell;boolean valid=board.canMove(tile.id);int color=valid?0xff79529e:0xffb9496e;
        float width=cell*board.level.size;
        float endX=tile.direction.dc==0?x:tile.direction.dc>0?bx+width:bx;
        float endY=tile.direction.dr==0?y:tile.direction.dr>0?by+width:by;
        p.setColor(alpha(color,180));p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);p.setPathEffect(new DashPathEffect(new float[]{4,6},frameTime%10));c.drawLine(x,y,endX,endY,p);p.setPathEffect(null);p.setStyle(Paint.Style.FILL);
    }
    private void movePiece(int id){
        if(board==null||won||paused||help||!running||powerSaveBlocked||flowRemaining>0&&!flowExecuting||!Board.isGateAction(id)&&!board.isPresent(id)||outOfMoves())return;
        if(hasUnsettledEarnedContinuation()){applyPendingContinuation();return;}
        if(!Board.isGateAction(id)&&elements121!=null&&elements121.layers(id)>0&&!flowExecuting){tapElement121(id);return;}
        if(Board.isGateAction(id)&&!board.canPerformAction(id))return;
        actionGeneration++;int beforeBudget121=moveBudget.used();
        boolean rejected=!board.canPerformAction(id);
        boolean protectedBlock=rejected&&!moveBudget.rejectsAreFree()&&(shieldCharges>0||gearGrace>0);
        if(protectedBlock){if(shieldCharges>0)shieldCharges--;else gearGrace--;}
        else if(!moveBudget.rejectsAreFree()&&!moveBudget.consumeAction())return;
        HashSet<Integer> previouslyFree=new HashSet<>();for(Tile candidate:board.legalMoves())previouslyFree.add(candidate.id);
        Tile tile=board.level.tile(id);Board.MoveResult move=moveBudget.rejectsAreFree()?moveBudget.attempt(board,id):board.performAction(id);if(move==null)return;selected=-1;
        if(!move.success){
            blockedAt121=SystemClock.uptimeMillis();blockedCost121=Math.max(0,moveBudget.used()-beforeBudget121);blockedPiece121=id;
            exitChain121.correction();moveStreak=0;puzzleReaction.blocked(SystemClock.uptimeMillis());shakeId=id;shakeUntil=SystemClock.uptimeMillis()+300;sfx(AudioEngine.Sound.BLOCKED);haptic();if(!persistMove())return;
            LearningGuide.Feedback reason=LearningGuide.blockedFeedback(board,id);consequenceGateMask=reason.focusGate==null?0:reason.focusGate.bit;newlyFreed.clear();if(reason.blockingTileId>=0)newlyFreed.add(reason.blockingTileId);consequenceUntil=SystemClock.uptimeMillis()+3000;
            if(outOfMoves())exhausted();else{toast="";toastUntil=0;announceForAccessibility(l(reason.key,reason.args)+". "+a21(blockedCost121==0?"blocked_free":"blocked_cost",blockedCost121));}return;
        }
        newlyFreed.clear();for(Tile candidate:board.legalMoves())if(!previouslyFree.contains(candidate.id))newlyFreed.add(candidate.id);
        consequenceGateMask=move.previousGateMask^move.gateMask;consequenceUntil=SystemClock.uptimeMillis()+1500;
        if(!newlyFreed.isEmpty())notice(l("clear_path",newlyFreed.size()));
        if(tile!=null){if(elements121!=null)elements121.clear(tile.id);if(!flowExecuting)exitChain121.exit(tile.id);}
        moveStreak++;if(tile!=null){puzzleReaction.success(SystemClock.uptimeMillis());if(puzzleReaction.streak()%3==0){notice(en20("chain",puzzleReaction.streak()));sfx(AudioEngine.Sound.COIN);}}successX=tile==null?195:bx+(tile.col+.5f)*cell;successY=tile==null?by+150:by+(tile.row+.5f)*cell;successUntil=SystemClock.uptimeMillis()+600;
        if(tile==null||tile.isSwitch()||board.level.isKey(tile.id))gatePulseUntil=SystemClock.uptimeMillis()+700;
        safeHighlights.clear();trailUntil=focusUntil=0;hintId=-1;
        coachId=mode==0&&levelIndex==1&&board.moves()<2?board.hint():-1;
        if(tile!=null)flights.add(new Flight(tile,SystemClock.uptimeMillis(),bx+(tile.col+.5f)*cell,by+(tile.row+.5f)*cell,directionColor(tile.direction)));
        if(tile!=null&&battleEnabled()){CompanionBattle.State credited=battleState.creditExit(tile.id);if(credited!=null)battleState=credited;}
        sfx(tile==null||tile.isSwitch()||board.level.isKey(tile.id)?AudioEngine.Sound.GATE:AudioEngine.Sound.MOVE);haptic();if(!persistMove())return;
        ensureGuidance();if(move.solved)finishLevel();else if(outOfMoves())exhausted();
    }
    private boolean persistMove(){if(saveSession()||saveSession())return true;powerSaveBlocked=true;actionGeneration++;stopTimer();notice(t("commerce_save_error"));return false;}
    private void reconcileUndo121(){
        GameStore.UndoPurchase121 pending=store.pendingUndo121();if(pending==null)return;
        boolean applied=pending.requestId.equals(prefs.getString("last_paid_undo_v121",""))||pending.requestId.equals(expeditionPrefs.getString("last_paid_undo_v121",""));
        if(applied)store.completeUndo121(pending.requestId);else store.cancelUndo121(pending.requestId);
    }
    private void undoMove(){
        if(board==null||won||paused||help||!running||powerSaveBlocked||flowRemaining>0||!board.canUndo()||moveBudget.undoRemaining(undos)==0)return;
        if(!prepareAbandon())return;
        if(!economyPolicy121||undos<EconomyCurve121.freeUndos()){applyUndo121("");return;}
        int paid=undos-EconomyCurve121.freeUndos()+1,cost=EconomyCurve121.undoPrice(levelIndex,paid);
        confirmInScene(a21("undo_price",cost),a21("undo_confirm",cost,store.coins()),()->{
            String request=UUID.randomUUID().toString();if(!store.reserveUndo121(request,levelIndex,paid)){notice(a21("undo_funds"));return;}applyUndo121(request);
        });
    }
    private void applyUndo121(String paidReceipt){
        if(board==null||won||paused||help||!running||powerSaveBlocked||flowRemaining>0)return;
        if(moveBudget.undoRemaining(undos)==0){notice(l("undo_exhausted"));return;}
        if(!board.canUndo())return;
        if(!prepareAbandon())return;actionGeneration++;
        if(moveBudget.managesUndo()){
            if(!moveBudget.undo(board,undos))return;
        }else{if(!moveBudget.consumeAction()||!board.undo())return;}
        if(!paidReceipt.isEmpty())lastPaidUndo121=paidReceipt;
        exitChain121.correction();moveStreak=0;puzzleReaction.reset();undos++;hintId=-1;pendingAction=-1;actionPreview=null;trailUntil=focusUntil=0;safeHighlights.clear();flights.clear();newlyFreed.clear();consequenceUntil=0;sfx(AudioEngine.Sound.UNDO);
        if(!persistMove())return;if(!paidReceipt.isEmpty()&&!store.completeUndo121(paidReceipt)){powerSaveBlocked=true;return;}ensureGuidance();if(!outOfMoves()&&screen.equals("play")&&activeStarted==0)activeStarted=SystemClock.uptimeMillis();
    }
    private boolean powerActive(String id){long now=effectsPausedAt>0?effectsPausedAt:SystemClock.uptimeMillis();return id.equals("hint")?hintId>=0&&now<hintUntil:id.equals("vision")?now<visionUntil:id.equals("focus")?now<focusUntil:id.equals("trail")?now<trailUntil:id.equals("shield")?shieldCharges>0:flowRemaining>0;}
    private void useItem(String id){
        if(board==null||won||paused||help||!running||mode==4||outOfMoves()||powerSaveBlocked)return;
        Catalog.BoosterItem item=Catalog.booster(id);if(item==null)return;
        if(id.equals("shield")&&moveBudget.rejectsAreFree()){notice(l("shield_unneeded"));return;}
        ensureGuidance();if(guidance==null){notice(n("thinking"));return;}if(guidance.status==Board.PositionStatus.DEAD_END){showDeadEnd();return;}if(guidance.status==Board.PositionStatus.NEEDS_ACTIONS){notice(v("not_enough_moves"));return;}
        if(!store.boosterUnlocked(id)){notice(t("power_unlock",item.unlockLevel));return;}
        if(powerActive(id)||powerGate.isBusy()){notice(u("power_busy"));return;}
        if(store.boosterStock(id)<=0){powerOffer(id);return;}
        powerConfirmation=id;actionGeneration++;invalidate();
    }
    private void drawPowerTray(Canvas c){
        scrim(c);float height=Math.min(434,viewportH-24),y=(viewportH-height)/2;sceneWindow(c,new RectF(20,y,370,y+height),PremiumUi.PAPER);fit(c,r("powers"),195,y+43,24,300,TEXT,true,true);
        int i=0;for(Catalog.BoosterItem item:Catalog.BOOSTERS){final String id=item.id;if(id.equals("shield")&&moveBudget.rejectsAreFree())continue;float x=34+(i%3)*110,yy=y+67+(i/3)*133;i++;boolean on=store.boosterUnlocked(id);sceneShelf(c,new RectF(x,yy,x+102,yy+120),on?PremiumUi.LILAC:PremiumUi.PAPER,false);shopArt.power(c,id,x+51,yy+37,26,frameTime,reduceMotion);fit(c,t(item.nameKey),x+51,yy+81,12,94,TEXT,true,true);fit(c,on?"×"+store.boosterStock(id):t("power_level",item.unlockLevel),x+51,yy+104,12,94,PremiumUi.MUTED,false,true);hit(x,yy,102,120,t(item.nameKey),()->{powerTrayOpen=false;useItem(id);});}
        sceneAction(c,t("close"),44,y+height-63,302,()->powerTrayOpen=false);
    }
    private void drawPowerConfirmation(Canvas c){
        Catalog.BoosterItem item=Catalog.booster(powerConfirmation);if(item==null){powerConfirmation="";return;}String id=powerConfirmation;
        scrim(c);float height=Math.min(440,viewportH-30),y=(viewportH-height)/2;sceneWindow(c,new RectF(24,y,366,y+height),PremiumUi.PAPER);
        sceneStage(c,new RectF(109,y+21,281,y+169),PremiumUi.MINT);shopArt.power(c,id,195,y+96,56,frameTime,reduceMotion);
        fit(c,t(item.nameKey),195,y+204,25,300,TEXT,true,true);wrap(c,t(item.descriptionKey),195,y+235,288,14,PremiumUi.MUTED,true,21);
        fit(c,u("power_cost",store.boosterStock(id)),195,y+height-135,12,302,TEXT,false,true);
        objectAction(c,u("power_confirm"),44,y+height-113,302,50,PEACH,()->{powerConfirmation="";activatePower(id);});
        sceneAction(c,t("cancel"),44,y+height-54,302,()->{powerConfirmation="";});
    }
    /** Inventory escrow is confirmed only after the effect and request are durably saved. */
    private void activatePower(String id){
        if(board==null||won||paused||help||!running||mode==4||outOfMoves()||powerSaveBlocked||!store.boosterUnlocked(id))return;
        if(!prepareAbandon())return;
        if(id.equals("shield")&&moveBudget.rejectsAreFree()){notice(l("shield_unneeded"));return;}
        ensureGuidance();if(guidance==null){notice(n("thinking"));return;}if(!guidance.canUseHint()){notice(v(guidance.status==Board.PositionStatus.DEAD_END?"path_warning":"not_enough_moves"));return;}
        int next=guidance.hintTileId;if(!id.equals("vision")&&!id.equals("shield")&&next<0){notice(t("no_safe_move"));return;}
        int steps=Math.min(PowerUsePolicy.FLOW_MAX_MOVES,guidancePlan.length);
        if(id.equals("flow")&&moveBudget.remaining()<steps){notice(t("flow_need_moves",steps));return;}
        long now=SystemClock.uptimeMillis();if(!powerGate.tryBegin(id,powerActive(id),now)){notice(u("power_busy"));return;}
        String request=UUID.randomUUID().toString();boolean saved=false,reserved=false;
        int oldHints=hintsUsed,oldHint=hintId,oldShield=shieldCharges;long oldHintTime=hintUntil,oldVision=visionUntil,oldFocus=focusUntil,oldTrailTime=trailUntil;
        int[] oldTrail=trail.clone(),oldHistory=board.history();HashSet<Integer> oldSafe=new HashSet<>(safeHighlights);MoveBudget oldBudget=moveBudget.copy();String oldRequest=lastPowerRequest;
        try{
            reserved=store.reserveBoosterUse(id,request);if(!reserved){notice(t("no_boosters"));return;}
            hintsUsed++;lastPowerRequest=request;
            if(id.equals("hint")){hintId=next;hintUntil=now+PowerUsePolicy.durationMillis(id);}
            else if(id.equals("vision"))visionUntil=now+PowerUsePolicy.durationMillis(id);
            else if(id.equals("shield"))shieldCharges=PowerUsePolicy.SHIELD_CHARGES;
            else if(id.equals("focus")){safeHighlights.clear();safeHighlights.addAll(guidanceSafe);focusUntil=now+PowerUsePolicy.durationMillis(id);}
            else if(id.equals("trail")){int[] solution=guidancePlan;trail=Arrays.copyOf(solution,Math.min(PowerUsePolicy.TRAIL_STEPS,solution.length));trailUntil=now+PowerUsePolicy.durationMillis(id);}
            else if(id.equals("flow")){if(!moveBudget.consumeAction()||!board.performAction(next).success)throw new IllegalStateException("Flow first move failed");flowRemaining=steps-1;hintId=-1;safeHighlights.clear();trailUntil=focusUntil=0;}
            saved=saveSession()||saveSession();if(!saved)throw new IllegalStateException("Power effect save failed");
            if(!store.completeBoosterUse(id,request))throw new IllegalStateException("Power completion missing");
            sfx(AudioEngine.Sound.HINT);log("power_used","item",id,"mode",""+mode);haptic();
            if(board.isSolved())finishLevel();else if(id.equals("flow"))resumeFlow();
        }catch(IllegalStateException failed){
            if(!saved){board.restoreHistory(oldHistory);moveBudget=oldBudget;hintsUsed=oldHints;hintId=oldHint;hintUntil=oldHintTime;visionUntil=oldVision;focusUntil=oldFocus;trailUntil=oldTrailTime;trail=oldTrail;shieldCharges=oldShield;safeHighlights.clear();safeHighlights.addAll(oldSafe);flowRemaining=0;lastPowerRequest=oldRequest;
                if(saveSession()||saveSession()){try{store.cancelBoosterUse(id,request);}catch(IllegalStateException blocked){powerSaveBlocked=true;}}
                else powerSaveBlocked=true;
            }else powerSaveBlocked=true;
            notice(t("commerce_save_error"));
        }finally{if(!id.equals("flow")||flowRemaining==0)powerGate.finish(id,SystemClock.uptimeMillis());invalidate();}
    }
    private void resumeFlow(){
        if(flowScheduledGeneration==actionGeneration||flowRemaining<=0||powerSaveBlocked||!running||paused||help||!screen.equals("play")||board==null||won)return;
        final long token=actionGeneration;flowScheduledGeneration=token;final Board target=board;
        postDelayed(()->{if(flowScheduledGeneration==token)flowScheduledGeneration=-1;if(token!=actionGeneration||target!=board||!running||paused||help||!screen.equals("play")||won||powerSaveBlocked)return;
            ensureGuidance();if(guidancePending){resumeFlow();return;}int safe=guidancePlan.length==0?-1:guidancePlan[0];if(safe<0||outOfMoves()){flowRemaining=0;powerGate.finish("flow",SystemClock.uptimeMillis());saveSession();return;}
            flowRemaining--;flowExecuting=true;try{movePiece(safe);}finally{flowExecuting=false;}
            if(powerSaveBlocked){if(flowRemaining==0)powerGate.finish("flow",SystemClock.uptimeMillis());return;}
            if(flowRemaining>0&&!won)resumeFlow();else{flowRemaining=0;powerGate.finish("flow",SystemClock.uptimeMillis());saveSession();}invalidate();
        },430);
    }
    private void reconcilePowerReservation(){
        try{store.retryPowerCommit();GameStore.PendingBoosterUse pending=store.pendingBoosterUse();if(pending==null)return;
            if(pending.requestId.equals(lastPowerRequest))store.completeBoosterUse(pending.id,pending.requestId);else store.cancelBoosterUse(pending.id,pending.requestId);
        }catch(IllegalStateException blocked){powerSaveBlocked=true;}
    }
    private long effectRemaining(long until){return Math.max(0,until-(effectsPausedAt>0?effectsPausedAt:SystemClock.uptimeMillis()));}
    private void freezeEffects(){if(effectsPausedAt==0)effectsPausedAt=SystemClock.uptimeMillis();}
    private void thawEffects(){if(effectsPausedAt==0||paused||help||!screen.equals("play"))return;long delta=Math.max(0,SystemClock.uptimeMillis()-effectsPausedAt);hintUntil+=delta;visionUntil+=delta;focusUntil+=delta;trailUntil+=delta;effectsPausedAt=0;}
    private static String joinIds(int[] ids){StringBuilder text=new StringBuilder();for(int id:ids){if(text.length()>0)text.append(',');text.append(id);}return text.toString();}
    private static String joinIds(Set<Integer> ids){int[] values=new int[ids.size()];int i=0;for(int id:ids)values[i++]=id;Arrays.sort(values);return joinIds(values);}
    private static int[] parseIds(String text,int max){try{if(text.isEmpty())return new int[0];String[] split=text.split(",");if(split.length>max)return new int[0];int[] ids=new int[split.length];for(int i=0;i<ids.length;i++){ids[i]=Integer.parseInt(split[i]);if(ids[i]<0||ids[i]>=68)return new int[0];}return ids;}catch(RuntimeException invalid){return new int[0];}}
    private boolean outOfMoves(){return moveBudget!=null&&moveBudget.isExhausted()&&board!=null&&!board.isSolved();}
    private void exhausted(){actionGeneration++;stopTimer();flights.clear();log("moves_exhausted","mode",""+mode,"level",""+levelIndex,"used",""+moveBudget.used());saveSession();announceForAccessibility(t("moves_exhausted"));invalidate();}
    private Level challengeLevel(ChallengeCode code){return code.resolve();}
    private void resetMoveRun(){
        economyPolicy121=board.level.progressionVersion==6&&(mode==0||mode==5);lastPaidUndo121="";if(economyPolicy121)store.activateEconomy121();
        elements121=ElementalShell121.create(board.level,mode,levelIndex);exitChain121=new ExitChain121();
        battleState=CompanionBattle.State.start(store.companionSquad());battleSelected=-1;battleEffectAt=0;
        if(!pendingContinuation.isEmpty())com.androidhit.lumadrift.commerce.CommerceActivity.acknowledgeContinuationReward(getContext(),pendingContinuation);
        moveBudget=board.level.progressionVersion==6?MoveBudget.start(mode==5?0:mode,board.level):MoveBudget.startDeliberate(mode==5?0:mode,board.level);flowRemaining=0;powerGate.cancel();lastPowerRequest="";effectsPausedAt=0;runId=UUID.randomUUID().toString();pendingContinuation=lastAppliedContinuation="";shieldCharges=0;gearGrace=0;focusUntil=trailUntil=0;trail=new int[0];safeHighlights.clear();newlyFreed.clear();consequenceUntil=0;
    }
    private boolean prepareAbandon(){
        if(powerSaveBlocked){notice(t("commerce_save_error"));return false;}
        if(hasUnsettledEarnedContinuation()){
            applyPendingContinuation();return false;
        }
        return true;
    }
    private boolean hasUnsettledEarnedContinuation(){
        return !pendingContinuation.isEmpty()&&!pendingContinuation.equals(lastAppliedContinuation)
                &&((pendingContinuation.startsWith("g:")&&store.hasGoldSpent(pendingContinuation))
                ||(pendingContinuation.startsWith("a:")&&com.androidhit.lumadrift.commerce.CommerceActivity.hasContinuationReward(getContext(),pendingContinuation)));
    }
    private void restartRun(){if(!prepareAbandon())return;String energyRun=reserveSessionEnergy(mode,levelIndex);if(energyRun==null)return;moveStreak=0;puzzleReaction.reset();actionGeneration++;board.restart();resetMoveRun();runId=energyRun;activeElapsed=0;activeStarted=0;undos=0;hintsUsed=0;coachId=mode==0&&levelIndex==1?board.hint():-1;hintId=-1;visionUntil=0;flights.clear();setPaused(false);restartConfirm=false;if(!saveSession())powerSaveBlocked=true;invalidate();}
    private void continueWithGold(){
        if(moveBudget==null||!moveBudget.supportsEarnedContinuation())return;
        if(!outOfMoves()||!moveBudget.canExtend()||continuationNeed()<1)return;
        if(!pendingContinuation.isEmpty()&&pendingContinuation.startsWith("a:")){
            if(com.androidhit.lumadrift.commerce.CommerceActivity.hasContinuationReward(getContext(),pendingContinuation)){applyPendingContinuation();return;}
            com.androidhit.lumadrift.commerce.CommerceActivity.acknowledgeContinuationReward(getContext(),pendingContinuation);
        }
        pendingContinuation="g:"+runId+":"+(moveBudget.extensions()+1);
        if(!saveSession()){notice(t("commerce_save_error"));return;}
        try{store.spendGoldOnce(pendingContinuation,MoveBudget.GOLD_EXTENSION_COST);if(!store.hasGoldSpent(pendingContinuation)){notice(t("not_enough"));return;}applyPendingContinuation();}catch(IllegalStateException failed){notice(t("commerce_save_error"));}
    }
    private void continueWithAd(){
        if(moveBudget==null||!moveBudget.supportsEarnedContinuation())return;
        if(!outOfMoves()||!moveBudget.canExtend()||continuationNeed()<1)return;
        if(pendingContinuation.startsWith("g:")&&store.hasGoldSpent(pendingContinuation)){applyPendingContinuation();return;}
        pendingContinuation="a:"+runId+":"+(moveBudget.extensions()+1);
        if(!saveSession()){notice(t("commerce_save_error"));return;}
        getContext().startActivity(com.androidhit.lumadrift.commerce.CommerceActivity.continuationIntent(getContext(),pendingContinuation).putExtra(com.androidhit.lumadrift.commerce.CommerceActivity.EXTRA_CONTINUATION_MOVES,moveBudget.extensionActions(continuationNeed())));
    }
    private void applyPendingContinuation(){
        if(board==null||moveBudget==null||pendingContinuation.isEmpty())return;
        String request=pendingContinuation;
        if(request.equals(lastAppliedContinuation)){
            if(!saveSession()){notice(t("commerce_save_error"));return;}
            if(com.androidhit.lumadrift.commerce.CommerceActivity.acknowledgeContinuationReward(getContext(),request)){pendingContinuation="";saveSession();}return;
        }
        if(!request.matches("[ag]:"+runId+":\\d{1,2}"))return;
        int ordinal=Integer.parseInt(request.substring(request.lastIndexOf(':')+1));
        if(ordinal!=moveBudget.extensions()+1||moveBudget.extensions()>=MoveBudget.MAX_EXTENSIONS)return;
        boolean earned;
        if(request.startsWith("g:")){
            if(!store.hasGoldSpent(request))return;
            try{store.spendGoldOnce(request,MoveBudget.GOLD_EXTENSION_COST);earned=true;}catch(IllegalStateException failed){notice(t("commerce_save_error"));return;}
        }else earned=com.androidhit.lumadrift.commerce.CommerceActivity.hasContinuationReward(getContext(),request);
        if(!earned)return;
        MoveBudget before=moveBudget,candidate=moveBudget.copy();if(!candidate.settleEarnedExtension(ordinal,continuationNeed()))return;
        String previous=lastAppliedContinuation;moveBudget=candidate;lastAppliedContinuation=request;
        if(!saveSession()){moveBudget=before;lastAppliedContinuation=previous;notice(t("commerce_save_error"));return;}
        log("moves_extended","source",request.startsWith("g:")?"gold":"rewarded_ad","extra",""+(candidate.total()-before.total()));
        com.androidhit.lumadrift.commerce.CommerceActivity.acknowledgeContinuationReward(getContext(),request);pendingContinuation="";saveSession();
        if(screen.equals("play")&&running&&!paused&&!help)activeStarted=SystemClock.uptimeMillis();notice(t("moves_added",candidate.total()-before.total()));invalidate();
    }
    private void drawOutOfMoves(Canvas c){
        if(moveBudget.policyVersion()==MoveBudget.FOCUSED_RELAY_POLICY_VERSION){drawFocusedOutOfMoves(c);return;}
        if(moveBudget.rejectsAreFree()){drawAttemptFailed(c);return;}
        scrim(c);float y=Math.max(24,H/2-290);scenePaper(c,new RectF(24,y,366,y+585),SweetUi.CREAM,true);
        sweet.mascot(c,195,y+57,29,frameTime,reduceMotion,SweetUi.THINKING);
        fit(c,t("moves_exhausted"),195,y+114,25,300,TEXT,true,true);
        wrap(c,hasReturn()?l(board!=null&&board.level.progressionVersion==6?"relay_undo_note":"undo_note"):l("retry_note"),195,y+148,291,14,skin.muted,true,21);
        String finalBudget=t("moves_left",moveBudget.remaining(),moveBudget.total());fit(c,finalBudget,195,y+202,15,290,TEXT,true,true);label(44,y+181,302,30,finalBudget);
        if(hasReturn()&&moveBudget.refundsUndo())objectAction(c,returnLabel(),44,y+226,302,51,PEACH,()->undoMove());
        else objectAction(c,restartLabel120(),44,y+226,302,51,PEACH,()->restartRun());
        int need=continuationNeed(),extra=moveBudget.extensionActions(need);
        if(moveBudget.canExtend()&&need>0){
            sceneAction(c,t("moves_gold",extra,MoveBudget.GOLD_EXTENSION_COST),44,y+295,302,()->continueWithGold());
            sceneAction(c,t("moves_ad",extra),44,y+356,302,()->continueWithAd());
        }else fit(c,guidancePending?n("thinking"):t("moves_cap"),195,y+325,13,290,skin.muted,false,true);
        sceneAction(c,restartLabel120(),44,y+427,145,()->restartRun());sceneAction(c,t("exit"),201,y+427,145,()->{saveSession();go("home");});
        fit(c,t("moves_retries",moveBudget.extensions(),MoveBudget.MAX_EXTENSIONS),195,y+516,12,302,skin.muted,false,true);
        fit(c,t("moves_test_only"),195,y+555,12,300,skin.muted,false,true);
    }
    private void drawFocusedOutOfMoves(Canvas c){
        scrim(c);float height=Math.min(520,viewportH-16),y=(viewportH-height)/2;scenePaper(c,new RectF(20,y,370,y+height),SweetUi.CREAM,true);
        drawCompanion(c,character,195,y+63,31,AvatarStyles.find(avatarStyle),AvatarStage.Pose.THINK,frameTime,reduceMotion,loadout,presentedCosmetics());
        fit(c,t("moves_exhausted"),195,y+126,24,320,TEXT,true,true);
        fit(c,t("moves_left",moveBudget.remaining(),moveBudget.total()),195,y+157,15,320,PremiumUi.MUTED,false,true);
        int need=continuationNeed(),extra=moveBudget.extensionActions(need);boolean available=moveBudget.canExtend()&&need>0;
        if(available){
            fit(c,t("moves_retries",moveBudget.extensions(),MoveBudget.MAX_EXTENSIONS),195,y+189,12,320,PremiumUi.MUTED,false,true);
            objectAction(c,t("moves_ad",extra),36,y+216,318,52,SweetUi.MINT,()->continueWithAd());if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="moves_continue_ad";
            objectAction(c,t("moves_gold",extra,MoveBudget.GOLD_EXTENSION_COST),36,y+280,318,52,SweetUi.LILAC,()->continueWithGold());if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="moves_continue_gold";
        }else wrap(c,guidancePending?n("thinking"):guidance!=null&&guidance.status==Board.PositionStatus.DEAD_END?v("path_warning"):t("moves_cap"),195,y+214,294,15,TEXT,true,23);
        objectAction(c,restartLabel120(),36,y+height-123,318,52,PEACH,()->restartRun());if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="moves_restart";
        objectAction(c,t("exit"),36,y+height-59,318,48,SweetUi.LILAC,()->{saveSession();goRoot("adventure");});
    }
    private void drawAttemptFailed(Canvas c){
        scrim(c);float y=Math.max(24,H/2-230);hits.clear();
        scenePaper(c,new RectF(24,y,366,y+460),SweetUi.CREAM,true);
        fit(c,t("moves_exhausted"),195,y+47,25,300,TEXT,true,true);
        wrap(c,l("run_failed_note",board.remainingCount()),195,y+89,292,15,TEXT,true,22);
        wrap(c,l("retry_note"),44,y+145,302,13,skin.muted,false,19);
        objectAction(c,restartLabel120(),44,y+245,302,52,PEACH,()->restartRun());
        if(hasReturn())sceneAction(c,returnLabel(),44,y+316,302,()->undoMove());
        else fit(c,l("undo_exhausted"),195,y+345,12,302,skin.muted,false,true);
        sceneAction(c,t("home"),44,y+388,302,()->{saveSession();goRoot("home");});
    }
    private String eventPeriod="";
    private void finishLevel(){
        if(won||board==null||!board.isSolved())return;
        stopTimer();resultStars=JourneyExperience.stars(moveBudget);
        try{
            VictoryReceipt receipt=readVictory();
            if(receipt==null||!receipt.matches(runId,mode,levelIndex,eventIndex,eventPeriod))receipt=VictoryReceipt.pending(runId,mode,levelIndex,eventIndex,eventPeriod,resultStars,store.coins(),meta.xp(),activeElapsed,moveBudget.used(),moveBudget.isUnlimited()?0:moveBudget.total(),undos,character.id);
            // Persist the baseline before any award. Interrupted idempotent grants
            // then recover their exact durable deltas instead of reporting zero.
            if(!victoryPreferences().edit().putString("receipt",receipt.encode()).commit())throw new IllegalStateException("Victory receipt baseline unavailable");
            if(receipt.ready){publishVictory(receipt,true);powerSaveBlocked=!saveSession();return;}
            if(mode==0)reward=store.completeLevel(levelIndex,resultStars,economyPolicy121);
            else if(mode==1)reward=store.completeDaily(eventPeriod,eventIndex,resultStars);
            else if(mode==2)reward=store.completeWeekly(eventPeriod,eventIndex,resultStars);
            else if(mode==3)reward=store.completeRemix(levelIndex,resultStars);else if(mode==5){if(store.completeExpeditionStage(eventPeriod,runId,levelIndex,resultStars)==null)throw new IllegalStateException("Expedition stage receipt refused");reward=0;}else reward=0;
            if(mode!=4&&mode!=5)reward+=store.claimAvatarVictoryBonus(mode,mode==1||mode==2?eventIndex:levelIndex,eventPeriod);
            boolean badgeBefore=meta.badgeUnlocked();xpReward=mode==5?0:meta.recordWin(mode,mode==1||mode==2?eventIndex:levelIndex,resultStars,eventPeriod);
            receipt=receipt.settle(store.coins(),meta.xp());
            if(!victoryPreferences().edit().putString("receipt",receipt.encode()).commit())throw new IllegalStateException("Victory receipt result unavailable");
            publishVictory(receipt,false);syncStyle();
            if(!badgeBefore&&meta.badgeUnlocked())notice(t("badge_unlocked"));
            log("level_complete","mode",""+mode,"level",""+levelIndex,"event_index",""+eventIndex,"period",eventPeriod,"stars",""+resultStars,"powers",""+hintsUsed,"undos",""+undos,"play_ms",""+activeElapsed);
            sfx(AudioEngine.Sound.WIN);powerSaveBlocked=!saveSession();announceForAccessibility(t("victory")+", "+resultStars+" "+t("stars")+", +"+reward+" LumaCoins");
        }catch(IllegalStateException failure){won=false;powerSaveBlocked=true;saveSession();notice(t("commerce_save_error"));}
    }
    private void publishVictory(VictoryReceipt receipt,boolean restored){
        victoryResult=receipt;resultStars=receipt.stars;reward=receipt.coins;xpReward=receipt.xp;activeElapsed=receipt.elapsedMs;activeStarted=0;
        screen="play";won=true;paused=help=false;flowRemaining=0;powerGate.cancel();contentScroll=0;
        winAt=SystemClock.uptimeMillis()+(restored?-2000:reduceMotion?0:350);
    }
    private void leaveVictory(Runnable action){
        if(powerSaveBlocked){notice(t("commerce_save_error"));return;}
        if(!victoryPreferences().edit().remove("receipt").commit()){notice(t("commerce_save_error"));return;}
        victoryResult=null;action.run();
    }
    private void drawSaveRetry(Canvas c){scrim(c);float y=H/2-130;scenic.windowModal(c,new RectF(24,y,366,y+260),0xfff9f2ff);wrap(c,t("commerce_save_error"),195,y+54,290,17,TEXT,true,25);objectAction(c,t("retry"),44,y+143,302,49,skin.accent2,()->{powerSaveBlocked=!saveSession();if(!powerSaveBlocked){reconcileUndo121();reconcilePowerReservation();if(!powerSaveBlocked){if(board.isSolved())finishLevel();else resumeFlow();}}});}
    private boolean restartConfirm=false,deadEndOpen=false,powerTrayOpen=false;
    private String powerConfirmation="";
    private void scrim(Canvas c){round(c,0,0,390,H,0,0x80524a69);hits.clear();}
    private void drawPause(Canvas c){
        scrim(c);float y=H/2-192;scenic.windowModal(c,new RectF(24,y,366,y+384),0xfff9f2ff);mascot(c,195,y+74,33,character,false);
        center(c,t(restartConfirm?"restart":"paused"),195,y+137,25,TEXT,true);
        if(restartConfirm){wrap(c,t("confirm_restart"),195,y+168,280,13,skin.muted,true,18);
            objectAction(c,restartLabel120(),44,y+224,302,49,PEACH,()->{restartRun();});
            sceneAction(c,t("cancel"),44,y+291,302,()->{setPaused(false);restartConfirm=false;});
        }else{
            objectAction(c,t("resume"),44,y+174,302,49,PEACH,()->setPaused(false));
            sceneAction(c,t("how_to_play"),44,y+239,302,()->setHelp(true));
            sceneAction(c,t("exit"),44,y+299,302,()->{saveSession();goRoot("adventure");});
        }
    }
    private void victoryButton120(Canvas c,PlaySceneLayout.Rect area,String caption,int color,String id,Runnable action){modernAction(c,new RectF(area.left,area.top,area.right,area.bottom),caption,color,id,action,true);}
    private void drawWin(Canvas c){
        hits.clear();int gifts=readyGiftCount120();VictoryLayout area=new VictoryLayout(viewportH,minimumTextSize(),battleMinimumTouch(),gifts>0);
        p.setShader(new LinearGradient(0,0,390,area.height,new int[]{0xfffff2da,0xfff4edff,0xffe6f7ef},null,Shader.TileMode.CLAMP));c.drawRect(0,0,390,area.height,p);p.setShader(null);
        long age=Math.max(0,frameTime-winAt);int shown=VictoryLayout.displayedStars(resultStars,age,reduceMotion);
        for(int k=0;k<12;k++){float xx=22+(k*79%346),yy=25+(k*113%Math.max(80,(int)area.height-80));float pulse=reduceMotion?1:.75f+.25f*(float)Math.sin(age*.002+k);star(c,xx,yy,3*pulse,alpha(k%2==0?GOLD:0xffb4d8ca,100));}
        scenic.object(c,new RectF(15,55,63,103),0xffbba7d9,false,ScenicUi.Kind.RETURN);hit(15,55,48,48,vr("map"),()->leaveVictory(()->goRoot(mode==5?"expedition":"adventure")));if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="victory_back";
        fit(c,t("victory"),195,area.titleY,29,245,TEXT,true,true);
        for(int k=0;k<3;k++){float pop=reduceMotion?1:Math.max(.65f,Math.min(1.12f,(age-180-k*250)/180f));star(c,143+k*52,area.starsY,18*(k<shown?pop:1),k<shown?GOLD:0xffddd5e9);}
        Catalog.CharacterItem actor=victoryResult==null?character:Catalog.character(victoryResult.avatarId);if(actor==null)actor=character;
        if(area.avatarRadius>=24){
            sceneAura(c,new RectF(195-area.avatarRadius*1.55f,area.avatarY-area.avatarRadius*1.25f,195+area.avatarRadius*1.55f,area.avatarY+area.avatarRadius*1.25f),0xffe8d3f0,frameTime,true);
            drawCompanion(c,actor,195,area.avatarY,area.avatarRadius,AvatarStyles.find(avatarStyle),AvatarStage.Pose.WIN,frameTime,reduceMotion,loadout,presentedCosmetics());
            float bubbleY=area.avatarY-area.avatarRadius*.88f;round(c,230,bubbleY-28,139,37,18,0xfffffaf0);fit(c,vr("nice"),299,bubbleY-4,14,125,TEXT,true,true);
        }
        int spent=victoryResult==null?moveBudget.used():victoryResult.used,total=victoryResult==null?moveBudget.total():victoryResult.total;
        String moves=moveBudget.isUnlimited()?"∞":spent+" / "+total;
        fit(c,vr("moves")+" · "+moves,112,area.metricsY,14,174,TEXT,true,true);
        fit(c,vr("time")+" · "+VictoryLayout.clock(activeElapsed),286,area.metricsY,14,174,TEXT,true,true);
        float progress=VictoryLayout.rewardProgress(age,reduceMotion);int shownCoins=Math.round(reward*progress),shownXp=Math.round(xpReward*progress);
        round(c,0,0,390,42,0,0xfffbf7ff);drawPlayWalletHud120(c,victoryResult==null?store.coins():victoryResult.beforeCoins+shownCoins);
        if(mode==5){fit(c,x("step",eventIndex+1,ExpeditionCatalog.STAGES)+" · "+x("route_saved"),195,area.rewardY-10,17,340,TEXT,true,true);}
        else{coin(c,56,area.rewardY-15,11);fit(c,"+"+shownCoins+" LumaCoins",165,area.rewardY-7,22,218,TEXT,true,true);fit(c,"+"+shownXp+" XP",312,area.rewardY-7,16,92,TEXT,true,true);}
        fit(c,reward==0&&xpReward==0&&mode!=5?vr("replay"):vr("saved"),195,area.rewardY+14,12,340,PremiumUi.MUTED,false,true);
        label(24,area.metricsY-24,342,area.rewardY-area.metricsY+60,t("victory")+", "+resultStars+" "+t("stars")+", "+vr("moves")+" "+moves+", "+VictoryLayout.clock(activeElapsed)+", +"+reward+" LumaCoins, +"+xpReward+" XP");
        if(area.gifts!=null){victoryButton120(c,area.gifts,"✦ "+vr("gifts",gifts)+"  →",0xffffe1ac,"victory_gifts",()->leaveVictory(()->openRewards(3)));if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="victory_gifts";}
        victoryButton120(c,area.next,(mode==4?t("retry"):t("next"))+"  →",0xffbde8d8,"victory_next",()->leaveVictory(()->{
            if(mode==5)goRoot("expedition");
            else if(mode==0&&levelIndex<BalancedCatalog.LEVEL_COUNT)start(levelIndex+1,0,0);
            else if(mode==3&&levelIndex<BalancedCatalog.REMIX_COUNT)start(levelIndex+1,3,0);
            else if(mode==1&&eventIndex<2&&eventPeriod.equals(store.dailyId()))start(1,1,eventIndex+1);
            else if(mode==2&&eventIndex<6&&eventPeriod.equals(store.weeklyId()))start(1,2,eventIndex+1);
            else if(mode==4)openChallenge(friendCode);else goRoot("adventure");
        }));if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="victory_next";
        victoryButton120(c,area.map,(mode==5?x("route"):vr("map")),0xffeee7f7,"victory_map",()->leaveVictory(()->goRoot(mode==5?"expedition":"adventure")));if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="victory_map";
        victoryButton120(c,area.shop,vr("shop")+"  →",0xffe7d6f7,"victory_shop",()->leaveVictory(()->goRoot("shop")));if(!hits.isEmpty())hits.get(hits.size()-1).semanticId="victory_shop";
    }
    private void drawHelp(Canvas c){
        if(board!=null&&moveBudget!=null&&moveBudget.policyVersion()==MoveBudget.FOCUSED_RELAY_POLICY_VERSION){
            scrim(c);float height=Math.min(510,viewportH-16),y=(viewportH-height)/2;sceneWindow(c,new RectF(20,y,370,y+height),PremiumUi.PAPER);
            LearningGuide.Context rule=lesson(board);fit(c,l(rule.titleKey),195,y+48,22,310,TEXT,true,true);
            twoLines(c,l(rule.descriptionKey,rule.descriptionArgs),36,y+77,318,14,TEXT);
            wrap(c,vr("undo_rule"),195,y+174,302,14,TEXT,true,22);
            twoLines(c,vr("score_rule",JourneyExperience.twoStarLimit(moveBudget)-moveBudget.minimumActions()),36,y+337,318,14,PremiumUi.MUTED);
            label(36,y+66,318,327,l(rule.descriptionKey,rule.descriptionArgs)+" "+vr("undo_rule")+" "+vr("score_rule",JourneyExperience.twoStarLimit(moveBudget)-moveBudget.minimumActions()));
            objectAction(c,t("got_it"),36,y+height-70,318,52,PEACH,()->setHelp(false));return;
        }
        scrim(c);float height=Math.min(510,viewportH-32),y=(viewportH-height)/2;sceneWindow(c,new RectF(24,y,366,y+height),PremiumUi.PAPER);
        LearningGuide.Context rule=lesson(board);dressedMascot(c,195,y+73,34);fit(c,l(rule.titleKey),195,y+151,22,300,TEXT,true,true);
        wrap(c,l(rule.descriptionKey,rule.descriptionArgs),195,y+186,294,15,TEXT,true,23);
        if(board.level.progressionVersion==6)wrap(c,(economyPolicy121?a21("undo_rule"):l("relay_undo_note")),195,y+295,294,13,PremiumUi.MUTED,true,21);
        objectAction(c,t("got_it"),44,y+height-78,302,54,PEACH,()->setHelp(false));
    }
    @Override public boolean onTouchEvent(MotionEvent event){try{return handleTouch121(event);}catch(GameStore.LocalSaveException failure){blockLocalSave();return true;}}
    private boolean handleTouch121(MotionEvent event){
        int eventAction=event.getActionMasked();
        if(!running)return true;
        if(sceneActionsBlocked()){
            sceneInputDiscarded=eventAction!=MotionEvent.ACTION_UP&&eventAction!=MotionEvent.ACTION_CANCEL;pressed=null;selected=-1;gesturePiece=gestureGate=-1;gestureGuardian=false;rootSwipe.cancel();return true;
        }
        if(sceneInputDiscarded){if(eventAction==MotionEvent.ACTION_UP||eventAction==MotionEvent.ACTION_CANCEL)sceneInputDiscarded=false;return true;}
        if(eventAction==MotionEvent.ACTION_POINTER_UP&&pinchDistance>0){pinchDistance=0;sceneInputDiscarded=true;pressed=null;rootSwipe.cancel();return true;}
        if(event.getPointerCount()>1){
            rootSwipe.cancel();pressed=null;selected=-1;gesturePiece=gestureGate=-1;gestureGuardian=false;
            if(screen.equals("home")&&sceneConfirmAction==null&&!localSaveBlocked){
                float dx=event.getX(1)-event.getX(0),dy=event.getY(1)-event.getY(0),distance=(float)Math.hypot(dx,dy);
                if(pinchDistance<=0){pinchDistance=Math.max(1,distance);pinchZoom=homeScene.cameraZoom();}
                else if(eventAction==MotionEvent.ACTION_MOVE){homeScene.setCamera(pinchZoom*distance/pinchDistance,homeScene.cameraPanX(),homeScene.cameraPanY());invalidate();}
            }else sceneInputDiscarded=true;
            return true;
        }
        float x=(event.getX()-ox)/scale,y=(event.getY()-top)/scale;
        if(eventAction==MotionEvent.ACTION_DOWN){
            downX=x;downY=y;pinchDistance=0;homePanning=false;homeDragPanX=homeScene.cameraPanX();homeDragPanY=homeScene.cameraPanY();scrollAtDown=contentScroll;scrolling=false;pressed=null;gesturePiece=-1;gestureGate=-1;gestureGuardian=false;
            for(int i=hits.size()-1;i>=0;i--)if(hits.get(i).action!=null&&hits.get(i).r.contains(x,y)){pressed=hits.get(i);break;}
            Board target=null;float left=bx,up=by,width=board==null?300:cell*board.level.size;
            if(sceneConfirmAction==null&&!localSaveBlocked&&screen.equals("play")&&!paused&&!help&&!won&&powerConfirmation.isEmpty()&&!deadEndOpen&&!powerTrayOpen&&!outOfMoves()&&pendingAction<0)target=board;
            else if(sceneConfirmAction==null&&!localSaveBlocked&&screen.equals("tutorial")&&!tutorial.complete()){target=tutorial.board();left=tutorialBoardLeft;up=tutorialBoardTop;width=tutorialBoardWidth;}
            // The fixed wallet owns this visible band even if a short window
            // scrolls a board cell behind it. Never begin a hidden-piece swipe.
            if(screen.equals("play")&&y<106)target=null;
            if(target!=null){float yy=y+contentScroll,unit=width/target.level.size;
                if(x>=left&&x<left+width&&yy>=up&&yy<up+width)for(Tile tile:target.remainingTiles())if(tile.row==(int)((yy-up)/unit)&&tile.col==(int)((x-left)/unit)){gesturePiece=tile.id;selected=tile.id;if(target.level.progressionVersion==6)actionPreview=target.previewAction(tile.id);break;}
            }
            // Touch ownership follows the topmost actual visible hit target, never guessed geometry.
            if(pressed!=null){gestureGate=pressed.gate;if(!localSaveBlocked&&screen.equals("guardian")&&pressed.guardianPiece>=0){gesturePiece=pressed.guardianPiece;gestureGuardian=true;}}
            boolean worldPan=screen.equals("home")&&downY>=homeSceneTop+menuHudInset&&downY<homeToolbarTop+menuHudInset;
            rootSwipe.begin(x,y,rootIndex()>=0&&pressed==null&&sceneConfirmAction==null&&!localSaveBlocked&&!homeDecorating&&!worldPan);
            invalidate();return true;
        }
        if(eventAction==MotionEvent.ACTION_MOVE){
            if(menuGiftAt>0)return true;
            if(rootSwipe.move(x,y)){pressed=null;selected=-1;scrolling=false;invalidate();return true;}
            if(sceneConfirmAction==null&&screen.equals("home")&&(pressed==null||pressed.homeItem||pressed.action==null)&&downY>=homeSceneTop+menuHudInset&&downY<homeToolbarTop+menuHudInset&&homeScene.cameraZoom()>1.01f&&(homePanning||Math.hypot(x-downX,y-downY)>18)){
                homePanning=true;pressed=null;homeScene.setCamera(homeScene.cameraZoom(),homeDragPanX+(x-downX)/homeSceneScale,homeDragPanY+(y-downY)/homeSceneScale);invalidate();return true;
            }
            if(gesturePiece<0&&gestureGate<0&&layout!=null&&maximumScroll()>0&&Math.abs(y-downY)>=22&&Math.abs(y-downY)>Math.abs(x-downX)){
                scrolling=true;pressed=null;selected=-1;contentScroll=clampScroll(scrollAtDown+downY-y);invalidate();
            }return true;
        }
        if(eventAction==MotionEvent.ACTION_UP){
            SceneTransition.RootSwipe.Result rootResult=rootSwipe.end(x,y);
            if(rootResult!=SceneTransition.RootSwipe.Result.NONE){pressed=null;selected=-1;scrolling=false;changeRoot(rootResult);performClick();return true;}
            Hit target=pressed;pressed=null;int piece=gesturePiece;gesturePiece=-1;selected=-1;float dx=x-downX,dy=y-downY;float distance=(float)Math.hypot(dx,dy);
            if(screen.equals("home")&&target!=null&&(target.name.equals(r("zoom_in"))||target.name.equals(r("zoom_out")))&&distance<22){target.action.run();performClick();}
            else if(sceneConfirmAction==null&&!localSaveBlocked&&screen.equals("home")&&!homePanning&&!scrolling&&distance<22&&y<homeSceneTop+homeSceneHeight+menuHudInset&&homePointer(x,y+contentScroll-menuHudInset,target!=null&&target.r.contains(x,y)?target:null)){performClick();}
            else if(homePanning){homePanning=false;performClick();}
            else if(gestureGate>=0&&!scrolling&&distance<40){Direction gate=Direction.values()[gestureGate];gestureGate=-1;if(screen.equals("tutorial"))practiceGate(gate);else if(board!=null&&!board.isGateOpen(gate)){if(board.supportsManualGates())requestAction(Board.gateAction(gate));else notice(l("relay_gate_touch"));}performClick();}
            else if(gestureGuardian&&piece>=0&&!scrolling){Direction direction=Math.abs(dx)>Math.abs(dy)?dx>0?Direction.RIGHT:Direction.LEFT:dy>0?Direction.DOWN:Direction.UP;GuardianEncounter.Piece selectedPiece=guardian==null?null:guardian.piece(piece);if(distance<22||selectedPiece!=null&&selectedPiece.direction==direction){guardianMove(piece);performClick();}else notice(tt("wrong_direction"));}
            else if(!scrolling&&piece>=0&&distance>=22){
                Direction direction=Math.abs(dx)>Math.abs(dy)?dx>0?Direction.RIGHT:Direction.LEFT:dy>0?Direction.DOWN:Direction.UP;
                Board source=screen.equals("tutorial")?tutorial.board():board;Tile tile=source==null?null:source.level.tile(piece);
                if(tile!=null&&direction==tile.direction){sfx(AudioEngine.Sound.TAP);if(screen.equals("tutorial"))practicePiece(piece,direction);else requestAction(piece);performClick();}
                else notice(tt("wrong_direction"));
            }else if(!scrolling&&target!=null&&target.action!=null&&target.r.contains(x,y)&&distance<22){sfx(AudioEngine.Sound.TAP);target.action.run();performClick();}
            scrolling=false;invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);return true;
        }
        if(eventAction==MotionEvent.ACTION_CANCEL){rootSwipe.cancel();pinchDistance=0;pressed=null;selected=-1;if(pendingAction<0)actionPreview=null;gesturePiece=-1;gestureGate=-1;gestureGuardian=false;scrolling=false;invalidate();return true;}return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
    @Override public boolean onKeyDown(int key,KeyEvent e){if(sceneActionsBlocked()){if(key==KeyEvent.KEYCODE_BACK&&e.getRepeatCount()==0){back();}return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN||key==KeyEvent.KEYCODE_DPAD_RIGHT){focused=(focused+1)%Math.max(1,hits.size());invalidate();return true;}if(key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_LEFT){focused=(focused-1+hits.size())%Math.max(1,hits.size());invalidate();return true;}if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){if(e.getRepeatCount()==0&&focused>=0&&focused<hits.size()&&hits.get(focused).action!=null)hits.get(focused).action.run();return true;}return super.onKeyDown(key,e);}
    private void accessibilityEvent(int id,int type){AccessibilityEvent event=AccessibilityEvent.obtain(type);event.setPackageName(getContext().getPackageName());event.setClassName("android.widget.Button");event.setSource(this,id);if(id>=0&&id<hits.size())event.setContentDescription(hits.get(id).name);getParent().requestSendAccessibilityEvent(this,event);}
    @Override public boolean onHoverEvent(MotionEvent e){if(sceneActionsBlocked()){hovered=-1;return true;}AccessibilityManager am=(AccessibilityManager)getContext().getSystemService(Context.ACCESSIBILITY_SERVICE);if(!am.isTouchExplorationEnabled())return super.onHoverEvent(e);float x=(e.getX()-ox)/scale,y=(e.getY()-top)/scale;int id=-1;for(int i=hits.size()-1;i>=0;i--)if(hits.get(i).r.contains(x,y)){id=i;break;}if(e.getAction()==MotionEvent.ACTION_HOVER_EXIT)id=-1;if(id!=hovered){if(hovered>=0)accessibilityEvent(hovered,AccessibilityEvent.TYPE_VIEW_HOVER_EXIT);hovered=id;if(id>=0)accessibilityEvent(id,AccessibilityEvent.TYPE_VIEW_HOVER_ENTER);}return true;}
    @Override public AccessibilityNodeProvider getAccessibilityNodeProvider(){return new AccessibilityNodeProvider(){
        @Override public AccessibilityNodeInfo createAccessibilityNodeInfo(int id){
            if(id==HOST_VIEW_ID){AccessibilityNodeInfo info=AccessibilityNodeInfo.obtain(LumaView.this);onInitializeAccessibilityNodeInfo(info);info.setContentDescription("Luma Drift · "+screenTitle(screen));if(layout!=null&&maximumScroll()>0){info.setScrollable(true);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);}if(!sceneActionsBlocked()){
                if(screen.equals("home")){info.addAction(new AccessibilityNodeInfo.AccessibilityAction(0x01170001,r("zoom_in")));info.addAction(new AccessibilityNodeInfo.AccessibilityAction(0x01170002,r("zoom_out")));info.addAction(new AccessibilityNodeInfo.AccessibilityAction(0x01170003,d("overview")));}
                int root=rootIndex();if(root>0)info.addAction(new AccessibilityNodeInfo.AccessibilityAction(0x01170004,screenTitle(rootPlaces[root-1])));if(root>=0&&root<rootPlaces.length-1)info.addAction(new AccessibilityNodeInfo.AccessibilityAction(0x01170005,screenTitle(rootPlaces[root+1])));
                for(int i=0;i<hits.size();i++)info.addChild(LumaView.this,i);
            }return info;}
            if(sceneActionsBlocked()||id<0||id>=hits.size())return null;Hit h=hits.get(id);AccessibilityNodeInfo info=AccessibilityNodeInfo.obtain();info.setSource(LumaView.this,id);info.setParent(LumaView.this);info.setPackageName(getContext().getPackageName());info.setClassName(h.action==null?"android.widget.TextView":"android.widget.Button");info.setContentDescription(h.name);info.setText(h.name);if(!h.semanticId.isEmpty())info.setViewIdResourceName(getContext().getPackageName()+":id/"+h.semanticId);info.setSelected(h.selected);info.setClickable(h.action!=null);info.setEnabled(true);info.setFocusable(true);info.setVisibleToUser(true);if(h.action!=null)info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_ACCESSIBILITY_FOCUS);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLEAR_ACCESSIBILITY_FOCUS);info.setAccessibilityFocused(focused==id);Rect r=new Rect((int)(ox+h.r.left*scale),(int)(top+h.r.top*scale),(int)(ox+h.r.right*scale),(int)(top+h.r.bottom*scale));info.setBoundsInParent(r);int[] loc=new int[2];getLocationOnScreen(loc);r.offset(loc[0],loc[1]);info.setBoundsInScreen(r);return info;
        }
        @Override public boolean performAction(int id,int action,Bundle args){
            if(sceneActionsBlocked())return false;
            if(id==HOST_VIEW_ID){
                if(screen.equals("home")&&sceneConfirmAction==null){if(action==0x01170001||action==0x01170002){homeScene.setCamera(homeScene.cameraZoom()+(action==0x01170001?.2f:-.2f),homeScene.cameraPanX(),homeScene.cameraPanY());invalidate();return true;}if(action==0x01170003){homeScene.resetOverview();invalidate();return true;}}
                if(rootIndex()>=0&&sceneConfirmAction==null&&(action==0x01170004||action==0x01170005)){changeRoot(action==0x01170004?SceneTransition.RootSwipe.Result.RIGHT:SceneTransition.RootSwipe.Result.LEFT);return true;}
            }
            if(id==HOST_VIEW_ID&&layout!=null&&(action==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD||action==AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)){contentScroll=clampScroll(contentScroll+(action==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD?1:-1)*viewportH*.65f);invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_SCROLLED);sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);return true;}if(id<0||id>=hits.size())return false;if(action==AccessibilityNodeInfo.ACTION_CLICK){final Hit target=hits.get(id);if(target.action==null)return false;final long token=actionGeneration;post(()->{if(running&&!sceneActionsBlocked()&&token==actionGeneration){target.action.run();invalidate();sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);}});return true;}if(action==AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS){focused=id;accessibilityEvent(id,AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED);invalidate();return true;}if(action==AccessibilityNodeInfo.ACTION_CLEAR_ACCESSIBILITY_FOCUS){focused=-1;invalidate();return true;}return false;}
    };}
}
