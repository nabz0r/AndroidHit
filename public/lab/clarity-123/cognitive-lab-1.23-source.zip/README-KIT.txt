Luma Drift 1.23 synthetic local study; no human evidence.

From the extracted root, Java 17 and Python3 are required:
  bash scripts/test-cognitive-lab-v123.sh
  python3 scripts/verify-cognitive-lab-v123.py --require-current-source
  bash scripts/run-cognitive-lab-v123.sh --profiles 100 --repetitions 20 --seed 2026103002 --output /tmp/luma-new-run
Use spaces after option names (for example --profiles 100). Never overwrite the bundled run.
Open public/lab/clarity-123/index.html offline for the report. Optional home/ZIP links require network.
LumaView.java is actual source context only, not compiled by this driver. This is not an Android build kit or qualification of rendering.
104 oracle boards are separate from 8000 limited-perception trajectories.
